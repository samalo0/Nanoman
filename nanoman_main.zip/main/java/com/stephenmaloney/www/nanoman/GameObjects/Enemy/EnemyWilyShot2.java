package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteStatic;
import com.stephenmaloney.www.nanoman.R;

public class EnemyWilyShot2 extends SpriteStatic {
    private final EnemyWilyWeakness mParent;

    private float angle;

    EnemyWilyShot2(Resources resources, EnemyWilyWeakness parent) {
        super(resources, R.drawable.gameobject_enemy_wily_shot, 0, 0, 10, 10);
        mParent = parent;
        mPlayerDamage = 25;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject instanceof Player);
    }

    void init(int x, int y) {
        mX = x;
        mY = y;
        updateBoundingBox();

        mVelocityX = -.05f;
        mVelocityY = .05f;

        angle = (float)(Math.PI * 3/2f);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseShot(this);
        }

        angle -= elapsedMillis / 150f;
        final double adderX = 2 * Math.cos(angle);
        final double adderY = 2 * Math.sin(angle);

        final double distanceX = mVelocityX * elapsedMillis + mXFractional + adderX;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY= mVelocityY * elapsedMillis + mYFractional + adderY;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;

        updateBoundingBox();
    }
}
