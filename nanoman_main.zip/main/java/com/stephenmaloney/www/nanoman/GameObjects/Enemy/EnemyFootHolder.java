package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EnemyFootHolder extends SpriteAnimatedMirrored {
    public final static String TYPE = "EnemyFootHolder";

    private final static float VELOCITY_X = .025f;
    private final static float VELOCITY_Y = .015f;

    private final Rect mBounds;
    private int mDirectionY;
    private int mRandomTimer = 0;
    private int mShotTimer = 0;

    private final List<EnemyFootHolderShot> mShots = new ArrayList<>();
    private final static int SHOT_LIMIT = 2;

    public EnemyFootHolder(Resources resources, HashMap<String, String> properties) {
        super(0, 0, 24, 8);

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;
        updateBoundingBox();

        mFacingLeftAdjustmentX = 24;

        mBounds = new Rect(mX - (3 * Tile.SIZE), mY - (2 * Tile.SIZE), mX + (3 * Tile.SIZE), mY + (2 * Tile.SIZE));

        final String color = properties.get("Color");
        switch(color) {
            case "Green":
                mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_foot_holder_green, null));
                for(int i = 0; i < SHOT_LIMIT; i++) mShots.add(new EnemyFootHolderShot(resources, R.drawable.gameobject_enemy_shot_green, i, this));
                break;
            default:
                mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_foot_holder_orange, null));
                for(int i = 0; i < SHOT_LIMIT; i++) mShots.add(new EnemyFootHolderShot(resources, R.drawable.gameobject_enemy_shot_orange, i, this));
                break;
        }
        mDirection = Math.random() > .5? 1 : -1;
        mDirectionY = Math.random() > .5? 1 : -1;
        mVelocityX = mDirection * VELOCITY_X;
        mVelocityY = mDirectionY * VELOCITY_Y;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(GameEngine.isObjectVisible(mBoundingBox)) {
            mSpriteAnimation.onUpdate(elapsedMillis);

            mShotTimer += elapsedMillis;
            if(mShotTimer > 15000) {
                mShotTimer = 0;
                while (!mShots.isEmpty()) {
                    final EnemyFootHolderShot shot = mShots.remove(0);
                    shot.init(mX, mY, gameEngine);
                    gameEngine.addGameObject(shot);
                }
            }
        }

        mRandomTimer += elapsedMillis;
        if(mRandomTimer > 10000) {
            mRandomTimer = 0;
            mDirection = Math.random() > .5? 1 : -1;
            mDirectionY = Math.random() > .5? 1 : -1;
            mVelocityX = mDirection * VELOCITY_X;
            mVelocityY = mDirectionY * VELOCITY_Y;
        }

        double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY= mVelocityY * elapsedMillis + mYFractional;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;

        updateBoundingBox();

        if(mBoundingBox.left < mBounds.left) {
            mDirection = 1;
            mVelocityX = mDirection * VELOCITY_X;
        }
        else if(mBoundingBox.right > mBounds.right) {
            mDirection = -1;
            mVelocityX = mDirection * VELOCITY_X;
        }

        if(mBoundingBox.top < mBounds.top) {
            mDirectionY = 1;
            mVelocityY = mDirectionY * VELOCITY_Y;
        }
        else if(mBoundingBox.bottom > mBounds.bottom) {
            mDirectionY = -1;
            mVelocityY = mDirectionY * VELOCITY_Y;
        }
    }

    void releaseShot(EnemyFootHolderShot shot) {
        mShots.add(shot);
    }
}
