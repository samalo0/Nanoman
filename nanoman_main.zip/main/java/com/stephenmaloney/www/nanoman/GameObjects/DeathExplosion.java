package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

public class DeathExplosion extends SpriteAnimated {
    public final static int BOUNDING_BOX_SIZE_X = 16;
    public final static int BOUNDING_BOX_SIZE_Y = 16;
    public final static int BOUNDING_BOX_OFFSET_X = 0;
    public final static int BOUNDING_BOX_OFFSET_Y = 0;

    private final static float VELOCITY_FAST = .1f;
    private final static float VELOCITY_SLOW = .05f;

    public DeathExplosion(Resources resources, int drawableId, int position) {
        super(BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(drawableId, null));

        switch(position) {
            case 0:
                mVelocityY = 0;
                mVelocityX = VELOCITY_FAST;
                break;
            case 1:
                mVelocityY = 0;
                mVelocityX = VELOCITY_SLOW;
                break;
            case 2:
                mVelocityY = 0;
                mVelocityX = VELOCITY_FAST * -1;
                break;
            case 3:
                mVelocityY = 0;
                mVelocityX = VELOCITY_SLOW * -1;
                break;
            case 4:
                mVelocityY = VELOCITY_FAST;
                mVelocityX = 0;
                break;
            case 5:
                mVelocityY = VELOCITY_SLOW;
                mVelocityX = 0;
                break;
            case 6:
                mVelocityY = VELOCITY_FAST * -1;
                mVelocityX = 0;
                break;
            case 7:
                mVelocityY = VELOCITY_SLOW * -1;
                mVelocityX = 0;
                break;
            case 8:
                mVelocityY = VELOCITY_FAST;
                mVelocityX = VELOCITY_FAST;
                break;
            case 9:
                mVelocityY = VELOCITY_SLOW;
                mVelocityX = VELOCITY_SLOW;
                break;
            case 10:
                mVelocityY = VELOCITY_FAST * -1;
                mVelocityX = VELOCITY_FAST;
                break;
            case 11:
                mVelocityY = VELOCITY_SLOW * -1;
                mVelocityX = VELOCITY_SLOW;
                break;
            case 12:
                mVelocityY = VELOCITY_FAST;
                mVelocityX = VELOCITY_FAST * -1;
                break;
            case 13:
                mVelocityY = VELOCITY_SLOW;
                mVelocityX = VELOCITY_SLOW * -1;
                break;
            case 14:
                mVelocityY = VELOCITY_FAST * -1;
                mVelocityX = VELOCITY_FAST * -1;
                break;
            case 15:
                mVelocityY = VELOCITY_SLOW * -1;
                mVelocityX = VELOCITY_SLOW * -1;
                break;
        }
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    public void init(int x, int y) {
        mX = x;
        mY = y;
        updateBoundingBox();
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
        }

        final double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY= mVelocityY * elapsedMillis + mYFractional;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;
        updateBoundingBox();

        mSpriteAnimation.onUpdate(elapsedMillis);
    }
}
