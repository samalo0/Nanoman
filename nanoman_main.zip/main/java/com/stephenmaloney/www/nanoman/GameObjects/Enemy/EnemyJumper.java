package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

public class EnemyJumper extends SpriteFrameAnimation {
    private final static int BOUNDING_BOX_SIZE_JUMPING_Y = 19;
    private final static int BOUNDING_BOX_SIZE_LANDED_Y = 10;

    private final static int STATE_LANDED = 0;
    private final static int STATE_JUMP_RISING = 1;
    private final static int STATE_JUMP_FALLING = 2;
    private int mState = STATE_LANDED;

    private final static int LAND_MILLIS = 200;
    private final static int RISE_MILLIS = 150;
    private int mStateTimer;

    private final static int DISTANCE_SHORT = 48;
    private final static float VELOCITY_SHORT_X = .05f;
    private final static float VELOCITY_FAR_X = .1f;
    private final static float VELOCITY_Y = -.2f;

    private final Explosion mExplosion;
    private final EnemyJumperSpawn mParent;

    private boolean mHurtOrDead = false;

    public EnemyJumper(Resources resources, String color, EnemyJumperSpawn parent) {
        super(0, 0, 14, BOUNDING_BOX_SIZE_LANDED_Y, 2);

        mParent = parent;

        if(color != null && color.equals("Blue")) {
            mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_jumper_blue_landed);
            mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_jumper_blue_jumping);
        }
        else {
            mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_jumper_landed);
            mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_jumper_jumping);
        }

        mPlayerDamage = 20;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    void init(int x, int y) {
        mHurtOrDead = false;

        mState = STATE_LANDED;
        mFrame = 0;
        mStateTimer = 0;

        mX = x;
        mY = y;
        mBoundingBox.set(0, 0, 14, BOUNDING_BOX_SIZE_LANDED_Y);
        updateBoundingBox();

        mVelocityY = 0;
        mVelocityX = 0;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts) {

            mHurtOrDead = true;

            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

            gameEngine.removeGameObject(this);
            mParent.releaseJumper();

            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseJumper();
        }

        switch(mState) {
            case STATE_LANDED:
                // delay to jump
                mStateTimer += elapsedMillis;
                if(mStateTimer >= LAND_MILLIS) {
                    mStateTimer = 0;
                    mState = STATE_JUMP_RISING;
                    mFrame = 1;

                    mBoundingBox.set(0, 0, 14, BOUNDING_BOX_SIZE_JUMPING_Y);
                    mY -= BOUNDING_BOX_SIZE_JUMPING_Y - BOUNDING_BOX_SIZE_LANDED_Y;
                    updateBoundingBox();

                    // jump towards player
                    final int absoluteDistance = Math.abs(gameEngine.mPlayer.mBoundingBox.centerX() - mBoundingBox.centerX());
                    mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX() ? 1 : -1;
                    // jump right
                    if(absoluteDistance > DISTANCE_SHORT) mVelocityX = VELOCITY_FAR_X * mDirection;
                    else mVelocityX = VELOCITY_SHORT_X * mDirection;
                    mVelocityY = VELOCITY_Y;

                    mJustLanded = false;
                }
                break;
            case STATE_JUMP_RISING:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= RISE_MILLIS) {
                    mStateTimer = 0;
                    mState = STATE_JUMP_FALLING;
                }
                else {
                    final int absoluteDistance = Math.abs(gameEngine.mPlayer.mBoundingBox.centerX() - mBoundingBox.centerX());
                    if(absoluteDistance > DISTANCE_SHORT) mVelocityX = VELOCITY_FAR_X * mDirection;
                    else mVelocityX = VELOCITY_SHORT_X * mDirection;

                    gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);
                    gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);
                }
                break;
            case STATE_JUMP_FALLING:
                mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
                if(mVelocityY > GameEngine.TERMINAL_VELOCITY) mVelocityY = GameEngine.TERMINAL_VELOCITY;

                gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);
                gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

                if(mJustLanded) {
                    mState = STATE_LANDED;
                    mFrame = 0;
                    mVelocityY = 0;
                    mVelocityX = 0;
                    mBoundingBox.set(0, 0, 14, BOUNDING_BOX_SIZE_LANDED_Y);
                    mY += BOUNDING_BOX_SIZE_JUMPING_Y - BOUNDING_BOX_SIZE_LANDED_Y;
                    updateBoundingBox();
                }
                break;
        }
    }
}
