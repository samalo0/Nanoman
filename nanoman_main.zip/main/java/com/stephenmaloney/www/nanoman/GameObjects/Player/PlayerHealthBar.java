package com.stephenmaloney.www.nanoman.GameObjects.Player;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.VerticalDisplayBar;
import com.stephenmaloney.www.nanoman.R;

class PlayerHealthBar extends VerticalDisplayBar {
    public final static int HEALTH_MAX = 100;
    private final static int SEGMENTS = 25;
    private final static int BAR_LEFT = 24;
    private final static int BAR_TOP = 24;

    PlayerHealthBar(Resources resources) {
        super(resources, R.drawable.gameobject_vertical_display_bar_tan_segment, HEALTH_MAX, SEGMENTS, BAR_LEFT, BAR_TOP);
    }
}
