package com.stephenmaloney.www.nanoman.GameObjects;


import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.List;

public class DeathExplosionSet {
    private final List<DeathExplosion> mDeathExplosions = new ArrayList<>();
    private final static int DEATH_EXPLOSION_LIMIT = 16;

    public DeathExplosionSet(Resources resources) {
        for (int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) mDeathExplosions.add(new DeathExplosion(resources, R.drawable.animation_enemy_death, i));
    }

    public void addGameObjects(int centerX, int centerY, GameEngine gameEngine) {
        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) {
            DeathExplosion exp = mDeathExplosions.get(i);
            exp.init(centerX, centerY);
            gameEngine.addGameObject(exp);
        }
    }
}
