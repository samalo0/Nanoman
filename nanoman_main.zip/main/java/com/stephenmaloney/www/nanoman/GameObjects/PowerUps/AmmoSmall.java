package com.stephenmaloney.www.nanoman.GameObjects.PowerUps;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteStatic;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class AmmoSmall extends SpriteStatic {
    private final static int BOUNDING_BOX_SIZE_X = 12;
    private final static int BOUNDING_BOX_SIZE_Y = 8;
    private final static int BOUNDING_BOX_OFFSET_X = 0;
    private final static int BOUNDING_BOX_OFFSET_Y = 0;

    private final static int POSITION_OFFSET_X = 2;
    private final static int POSITION_OFFSET_Y = 8;

    public final static String TYPE = "AmmoSmall";

    public final static int AMMO = 10;

    private final boolean mRandomSpawn;
    private int mTimeoutTimer = 0;

    public AmmoSmall(Resources resources, HashMap<String, String> properties) {
        super(resources, R.drawable.gameobject_ammo_small, BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        // get starting x, y position (adjust x by one since the large health is 14 pixels wide, centering it)
        mX = (Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2) + POSITION_OFFSET_X;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) + POSITION_OFFSET_Y;
        updateBoundingBox();

        mRandomSpawn = false;
    }

    public AmmoSmall(Resources resources, int centerX, int centerY) {
        super(resources, R.drawable.gameobject_ammo_small, BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        mX = centerX - (BOUNDING_BOX_SIZE_X >> 1);
        mY = centerY - (BOUNDING_BOX_SIZE_Y >> 1);
        updateBoundingBox();

        mVelocityY = -.2f;
        mRandomSpawn = true;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        // check in player object
        return false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!mRandomSpawn) return;

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        if(mVelocityY > GameEngine.TERMINAL_VELOCITY) mVelocityY = GameEngine.TERMINAL_VELOCITY;
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

        mTimeoutTimer += elapsedMillis;
        if(mTimeoutTimer >= GameEngine.RANDOM_SPAWN_TIMEOUT) {
            gameEngine.removeGameObject(this);
        }
    }
}
