package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.DeathExplosion;
import com.stephenmaloney.www.nanoman.GameObjects.Dust;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.HealthLarge;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.WeaponPickup;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.Teleport;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricity;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EnemyElecman extends SpriteAnimatedMirroredWeapons {
    public final static String TYPE = "EnemyElecman";

    private final static float WALK_VELOCITY = .07f;
    private final static float JUMP_VELOCITY = -.32f;
    private final static float HURT_VELOCITY = .1f;

    private final static int ANIMATION_STAND = 0;
    private final static int ANIMATION_HURT = 1;
    private final static int ANIMATION_WALK = 2;
    private final static int ANIMATION_WAVE = 3;
    private final static int ANIMATION_THROW = 4;
    private final static int ANIMATION_JUMP = 5;
    private int mStateAnimation = ANIMATION_STAND;

    private final static int STATE_CONTINUE_FOR_TIME = 0;
    private final static int STATE_START_JUMP = 1;
    private final static int STATE_START_THROW = 2;
    private final static int STATE_START_WALK_BACK = 3;
    private final static int STATE_START_WALK_FORWARD = 4;
    private final static int STATE_START_WAVE = 5;
    private final static int STATE_STUNNED = 6;
    private int mState = STATE_START_WAVE;
    private int mStateNext;
    private int mStateTimer;

    private boolean mHurtOrDead = false;
    private final static int HURT_MILLIS = 1500;
    private int mHurtTimer;
    private final static int HURT_BLINK_MILLIS = 40;
    private int mHurtBlinkTimer;
    private final static int HURT_EXPLOSION_MILLIS = 250;
    private int mHurtExplosionTimer;
    private boolean mVisible = true;

    private final static int BOMB_DAMAGE = 16;
    private final static int CUTTER_DAMAGE = 28;
    private final static int FIRE_DAMAGE = 8;
    private final static int GUTS_DAMAGE = 16;
    private final static int PSHOT_DAMAGE = 4;

    private final EnemyHealthBar mHealthBar;
    private boolean mHealthBarAdded = false;

    private final List<DeathExplosion> mDeathExplosions = new ArrayList<>();
    private final static int DEATH_EXPLOSION_LIMIT = 16;

    private final WeaponPickup mWeaponPickup;

    private final List<WeaponElectricity> mWeaponElectricity = new ArrayList<>();
    private final static int WEAPON_ELECTRICITY_LIMIT = 1;

    private final boolean mDropsWeapon;
    private final Teleport mTeleport;

    public EnemyElecman(Resources resources, HashMap<String, String> properties) {
        super(resources, 8, 2, 14, 24);

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) - 8;
        updateBoundingBox();

        mDirection = properties.get("Direction").equals("1") ? 1 : -1;

        // check if enemy drops his weapon or adds teleport on death
        final String dropsWeapon = properties.get("DropsWeapon");
        mDropsWeapon = dropsWeapon == null || Boolean.parseBoolean(dropsWeapon);
        if(mDropsWeapon) mTeleport = null;
        else {
            HashMap<String, String> teleportProperties = new HashMap<>();
            teleportProperties.put("PositionX", "80");
            teleportProperties.put("PositionY", "56");
            teleportProperties.put("DestinationX", "80");
            teleportProperties.put("DestinationY", "41");
            mTeleport = new Teleport(teleportProperties);
        }

        mSpriteAnimation.addState(ANIMATION_STAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_elecman_stand, null));
        mSpriteAnimation.addState(ANIMATION_HURT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_hurt, null));
        mSpriteAnimation.addState(ANIMATION_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_elecman_walk, null));
        mSpriteAnimation.addState(ANIMATION_WAVE, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_elecman_wave, null));
        mSpriteAnimation.addState(ANIMATION_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_elecman_throw, null));
        mSpriteAnimation.addState(ANIMATION_JUMP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_elecman_jump, null));

        // set up death explosions
        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) mDeathExplosions.add(new DeathExplosion(resources, R.drawable.animation_enemy_death, i));
        for(int i = 0; i < WEAPON_ELECTRICITY_LIMIT; i++) mWeaponElectricity.add(new WeaponElectricity(resources, this));
        mHealthBar = new EnemyHealthBar(resources);
        mWeaponPickup = new WeaponPickup(resources, Player.WEAPON_ELECTRICITY);

        mFacingLeftAdjustmentX = 29;
        mPlayerDamage = 16;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead &&
                (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));

    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot) mHealthBar.remove(PSHOT_DAMAGE);
        else if(otherObject instanceof WeaponCutter) mHealthBar.remove(CUTTER_DAMAGE);
        else if(otherObject instanceof WeaponFireHorizontal || otherObject instanceof WeaponFireSpinner) mHealthBar.remove(FIRE_DAMAGE);
        else if(otherObject instanceof WeaponBomb) mHealthBar.remove(BOMB_DAMAGE);
        else if(otherObject instanceof WeaponGuts) mHealthBar.remove(GUTS_DAMAGE);
        else if(otherObject instanceof WeaponIce) {
            mState = STATE_STUNNED;
            mVelocityX = ((WeaponIce) otherObject).mDirection * HURT_VELOCITY;
        }

        if(mHealthBar.isEmpty()) onDeath(gameEngine);
        else onHurt(otherObject.mDirection, gameEngine);
    }

    private void onDeath(GameEngine gameEngine) {
        mHurtOrDead = true;

        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) {
            DeathExplosion exp = mDeathExplosions.get(i);
            exp.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(exp);
        }

        if(mDropsWeapon) {
            mWeaponPickup.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mWeaponPickup);
        }
        else {
            gameEngine.addGameObject(mTeleport);
            gameEngine.addGameObject(new HealthLarge(gameEngine.getResources(), mBoundingBox.centerX(), mBoundingBox.centerY()));
        }

        gameEngine.removeGameObject(mHealthBar);
        gameEngine.removeGameObject(this);

        gameEngine.soundPlay(GameEngine.GameSound.PLAYER_DEATH);
        gameEngine.musicPause();
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mVisible) super.onDraw(canvas);
    }

    private void onHurt(int direction, GameEngine gameEngine) {
        mVelocityX = direction * HURT_VELOCITY;
        mHurtOrDead = true;
        mHurtTimer = 0;
        mHurtBlinkTimer = 0;
        mState = STATE_CONTINUE_FOR_TIME;
        mStateTimer = HURT_EXPLOSION_MILLIS;

        // create dust
        dustAdd(gameEngine);

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if (!GameEngine.isObjectVisible(mBoundingBox)) {
            if (mHealthBarAdded) {
                mHealthBarAdded = false;
                gameEngine.removeGameObject(mHealthBar);
            }
            return;
        }

        if (!mHealthBarAdded) {
            mHealthBarAdded = true;
            gameEngine.addGameObject(mHealthBar);
            gameEngine.musicPlayLooped(R.raw.music_boss_theme);
        }
        
        if(mHurtOrDead) {
            mHurtTimer += elapsedMillis;
            if(mHurtTimer >= HURT_MILLIS) {
                mHurtOrDead = false;
                mVisible = true;
                mHurtBlinkTimer = 0;
                mHurtExplosionTimer = 0;
                if(mSpriteAnimation.mState == ANIMATION_HURT) mSpriteAnimation.setState(mStateAnimation, true);
            }
            else {
                mHurtBlinkTimer += elapsedMillis;
                if(mHurtBlinkTimer >= HURT_BLINK_MILLIS) {
                    mHurtBlinkTimer = 0;
                    mVisible = !mVisible;
                }
                mHurtExplosionTimer += elapsedMillis;
                if(mHurtExplosionTimer >= HURT_EXPLOSION_MILLIS) {
                    mHurtExplosionTimer = 0;
                    if(mSpriteAnimation.mState == ANIMATION_HURT) {
                        mSpriteAnimation.setState(mStateAnimation, true);
                    }
                    else {
                        mStateAnimation = mSpriteAnimation.mState;
                        mSpriteAnimation.setState(ANIMATION_HURT, true);
                    }
                }
            }
        }
        
        switch(mState) {
            case STATE_CONTINUE_FOR_TIME:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0 && (mOnGround || mStateNext == STATE_START_THROW)) mState = mStateNext;
                break;
            case STATE_START_JUMP:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;
                mVelocityX = WALK_VELOCITY * mDirection;
                mVelocityY = JUMP_VELOCITY;
                mSpriteAnimation.setState(ANIMATION_JUMP, true);
                mState = STATE_CONTINUE_FOR_TIME;
                mStateNext = STATE_START_THROW;
                mStateTimer = 300;
                break;
            case STATE_START_THROW:
                if(!mWeaponElectricity.isEmpty()) {
                    mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;
                    mSpriteAnimation.setState(ANIMATION_THROW, true);

                    final WeaponElectricity weaponElectricity = mWeaponElectricity.remove(0);

                    if(mDirection == 1) weaponElectricity.init(mBoundingBox.right, mBoundingBox.top - 8, mDirection);
                    else weaponElectricity.init(mBoundingBox.left - 34, mBoundingBox.top - 8, mDirection);
                    weaponElectricity.addGameObjects(gameEngine);
                }
                mState = STATE_CONTINUE_FOR_TIME;
                mStateNext = STATE_START_WALK_BACK;
                mStateTimer = 300;
                break;
            case STATE_START_WALK_BACK:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;
                mVelocityX = WALK_VELOCITY * mDirection * -1;
                mSpriteAnimation.setState(ANIMATION_WALK, true);
                mState = STATE_CONTINUE_FOR_TIME;
                mStateNext = STATE_START_WALK_FORWARD;
                mStateTimer = 300;
                break;
            case STATE_START_WALK_FORWARD:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;
                mVelocityX = WALK_VELOCITY * mDirection;
                mSpriteAnimation.setState(ANIMATION_WALK, true);
                mState = STATE_CONTINUE_FOR_TIME;
                mStateNext = STATE_START_JUMP;
                mStateTimer = 500;
                break;
            case STATE_START_WAVE:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;
                mVelocityX = 0;
                mSpriteAnimation.setState(ANIMATION_WAVE, true);
                mState = STATE_CONTINUE_FOR_TIME;
                mStateNext = STATE_START_WALK_BACK;
                mStateTimer = 750;
                break;
            case STATE_STUNNED:
                mVelocityX = 0;
                mSpriteAnimation.setState(ANIMATION_STAND, true);
                mState = STATE_CONTINUE_FOR_TIME;
                mStateNext = STATE_START_WALK_BACK;
                mStateTimer = 1500;
                break;
        }

        gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

        mSpriteAnimation.onUpdate(elapsedMillis);
    }

    @Override
    public void weaponElectricityRelease(WeaponElectricity weaponElectricity) {
        mWeaponElectricity.add(weaponElectricity);
    }
}
