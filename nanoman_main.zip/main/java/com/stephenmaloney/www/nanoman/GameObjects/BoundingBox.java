package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Rect;

public class BoundingBox {
    public int mOffsetX;
    public int mOffsetY;
    public int mSizeX;
    public int mSizeY;

    public Rect mRect;

    public BoundingBox(int offsetX, int offsetY, int sizeX, int sizeY) {
        mOffsetX = offsetX;
        mOffsetY = offsetY;
        mSizeX = sizeX;
        mSizeY = sizeY;

        mRect = new Rect(offsetX, offsetY, sizeX + offsetX, sizeY + offsetY);
    }
}