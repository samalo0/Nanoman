package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.DeathExplosion;
import com.stephenmaloney.www.nanoman.GameObjects.DeathExplosionSet;
import com.stephenmaloney.www.nanoman.GameObjects.Dust;
import com.stephenmaloney.www.nanoman.GameObjects.Gate;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.WeaponPickup;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public class EnemyBombman extends SpriteAnimatedMirroredWeapons {
    public final static String TYPE = "EnemyBombman";
    private final static float HURT_VELOCITY = .1f;
    private final static float VELOCITY_X = .07f;
    private final static float JUMP_VELOCITY = -.45f;

    private final Bitmap[] mBitmaps = new Bitmap[8];
    private int mFrame = 0;
    private int mOldFrame = 0;

    private final static int STATE_INIT = 0;
    private final static int STATE_START_TOSS_BOMB_UP = 1;
    private final static int STATE_WAIT_FOR_BOMB_DROP = 2;
    private final static int STATE_REDIRECT = 3;
    private final static int STATE_CONTINUE_FOR_TIME = 4;
    private final static int STATE_STUNNED = 5;
    private final static int STATE_WAIT_FOR_LANDING = 6;
    private final static int STATE_START_THROW_BOMB = 7;
    private int mState = STATE_INIT;
    private int mStateNext = STATE_REDIRECT;
    private int mStateTimer = 0;

    private final WeaponPickup mWeaponPickup;

    private final EnemyHealthBar mHealthBar;
    private boolean mHealthBarAdded = false;

    private boolean mHurtOrDead = false;
    private final static int HURT_MILLIS = 1500;
    private int mHurtTimer;
    private final static int HURT_BLINK_MILLIS = 40;
    private int mHurtBlinkTimer;
    private final static int HURT_EXPLOSION_MILLIS = 250;
    private int mHurtExplosionTimer;
    private boolean mVisible = true;

    private final static int PSHOT_DAMAGE = 8;
    private final static int CUTTER_DAMAGE = 8;
    private final static int FIRE_DAMAGE = 20;
    private final static int ELECTRICITY_DAMAGE = 4;

    private final List<WeaponBomb> mBombs = new ArrayList<>();
    private final static int BOMB_LIMIT = 2;
    private WeaponBomb mCurrentBomb;

    private final boolean mDropsWeapon;
    private final Gate mGate;
    private boolean mGateVisible = false;

    private final DeathExplosionSet mDeathExplosionSet;

    public EnemyBombman(Context context, HashMap<String, String> properties) {
        super(context.getResources(), 9, 0, 14, 24);

        final Resources resources = context.getResources();

        // get position of enemy - must be placed next to a floor
        final int x = Integer.parseInt(properties.get("PositionX"));
        final int y = Integer.parseInt(properties.get("PositionY"));

        // convert to pixels, and move up a little so that bombman is standing on the floor
        mX = x << Tile.SIZE_POW_2;
        mY = (y << Tile.SIZE_POW_2) - 8;
        updateBoundingBox();

        mDirection = Integer.parseInt(properties.get("Direction"));

        // check if bombman drops his weapon or removes a gate on death
        final String dropsWeapon = properties.get("DropsWeapon");
        mDropsWeapon = dropsWeapon == null || Boolean.parseBoolean(dropsWeapon);

        if(!mDropsWeapon) {
            HashMap<String, String> props = new HashMap<>();
            props.put("Orientation", "Horizontal");
            props.put("Width", "1");
            props.put("Length", "3");
            props.put("PassDirection", "-1");
            props.put("Drawable", "tile_wily2_gate_horiz");
            props.put("PositionX", Integer.toString(x - 1));
            props.put("PositionY", Integer.toString(y + 1));
            mGate = new Gate(context, props);
        }
        else mGate = null;

        mBitmaps[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bombman_hand_down);
        mBitmaps[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bombman_hand_up);
        mBitmaps[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bombman_ready_to_throw);
        mBitmaps[3] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bombman_throw);
        mBitmaps[4] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bombman_jump_back);
        mBitmaps[5] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bombman_jump_forward);
        mBitmaps[6] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bombman_jump_up);
        mBitmaps[7] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_hit);

        mHealthBar = new EnemyHealthBar(resources);

        mWeaponPickup = new WeaponPickup(resources, Player.WEAPON_BOMB);

        for (int i = 0; i < BOMB_LIMIT; i++) mBombs.add(new WeaponBomb(resources, this, true));

        mFacingLeftAdjustmentX = 32;

        mPlayerDamage = 24;

        mDeathExplosionSet = new DeathExplosionSet(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if (otherObject instanceof WeaponPShot) mHealthBar.remove(PSHOT_DAMAGE);
        else if (otherObject instanceof WeaponCutter) mHealthBar.remove(CUTTER_DAMAGE);
        else if (otherObject instanceof WeaponFireHorizontal || otherObject instanceof WeaponFireSpinner) mHealthBar.remove(FIRE_DAMAGE);
        else if (otherObject instanceof WeaponElectricityHorizontal || otherObject instanceof WeaponElectricityVertical) mHealthBar.remove(ELECTRICITY_DAMAGE);
        else if(otherObject instanceof WeaponIce) {
            mState = STATE_STUNNED;
            mVelocityX = ((WeaponIce) otherObject).mDirection * HURT_VELOCITY;
        }

        if(mHealthBar.isEmpty()) onDeath(gameEngine);
        else onHit(otherObject.mDirection, gameEngine);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(!GameEngine.isObjectVisible(mBoundingBox) || !mVisible) return;

        mMatrix.reset();
        if (mDirection == -1) {
            mMatrix.postScale(-1, 1);
            mMatrix.postTranslate(mFacingLeftAdjustmentX, 0);
        }
        mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);
        canvas.drawBitmap(mBitmaps[mFrame], mMatrix, GameView.mPaint);
    }

    private void onDeath(GameEngine gameEngine) {
        mHurtOrDead = true;

        mDeathExplosionSet.addGameObjects(mBoundingBox.centerX(), mBoundingBox.centerY(), gameEngine);

        if(mDropsWeapon) {
            mWeaponPickup.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mWeaponPickup);
        }
        else {
            mGate.unlock(gameEngine);
            gameEngine.removeGameObject(mGate);
        }

        gameEngine.removeGameObject(mHealthBar);
        gameEngine.removeGameObject(this);

        gameEngine.soundPlay(GameEngine.GameSound.PLAYER_DEATH);
        if(mDropsWeapon) gameEngine.musicPause();
        else gameEngine.musicPlayLooped(R.raw.music_wily_stage2);
    }

    private void onHit(int direction, GameEngine gameEngine) {
        mHurtOrDead = true;
        mHurtTimer = 0;
        mHurtBlinkTimer = 0;
        mState = STATE_CONTINUE_FOR_TIME;
        mStateTimer = HURT_EXPLOSION_MILLIS;
        mVelocityX = direction * HURT_VELOCITY;

        // create dust
        dustAdd(gameEngine);

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            if (mHealthBarAdded) {
                mHealthBarAdded = false;
                gameEngine.removeGameObject(mHealthBar);
            }
            return;
        }

        if (!mHealthBarAdded) {
            mHealthBarAdded = true;
            gameEngine.addGameObject(mHealthBar);
            gameEngine.musicPlayLooped(R.raw.music_boss_theme);
        }

        if(!mDropsWeapon && !mGateVisible) {
            mGateVisible = true;
            mGate.lock(gameEngine);
            gameEngine.addGameObject(mGate);
        }

        if(mHurtOrDead) {
            mHurtTimer += elapsedMillis;
            if(mHurtTimer >= HURT_MILLIS) {
                mHurtOrDead = false;
                mVisible = true;
                mHurtBlinkTimer = 0;
                mHurtExplosionTimer = 0;
                if(mFrame == 7) mFrame = mOldFrame;
            }
            else {
                mHurtBlinkTimer += elapsedMillis;
                if(mHurtBlinkTimer >= HURT_BLINK_MILLIS) {
                    mHurtBlinkTimer = 0;
                    mVisible = !mVisible;
                }
                mHurtExplosionTimer += elapsedMillis;
                if(mHurtExplosionTimer >= HURT_EXPLOSION_MILLIS) {
                    mHurtExplosionTimer = 0;
                    if(mFrame == 7) mFrame = mOldFrame;
                    else {
                        mOldFrame = mFrame;
                        mFrame = 7;
                    }
                }
            }
        }

        switch(mState) {
            case STATE_INIT:
                // initialize bomb for showboating
                mCurrentBomb = mBombs.remove(0);
                mCurrentBomb.init(mBoundingBox.right - 6, mBoundingBox.top - 8, mDirection, 0, 0);
                mCurrentBomb.mVelocityX = 0;
                mCurrentBomb.mVelocityY = -.4f;
                gameEngine.addGameObject(mCurrentBomb);

                mState = STATE_START_TOSS_BOMB_UP;
                mStateTimer = 0;
                return;
            case STATE_START_TOSS_BOMB_UP:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 100) {
                    mStateTimer = 0;
                    mState = STATE_WAIT_FOR_BOMB_DROP;
                    mFrame = 1;
                }
                return;
            case STATE_WAIT_FOR_BOMB_DROP:
                mCurrentBomb.mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
                mCurrentBomb.mY += mBombs.get(0).mVelocityY * elapsedMillis;
                if(mCurrentBomb.mY >= (mY - 8)) {
                    mCurrentBomb.mY = mY - 8;
                    mState = STATE_CONTINUE_FOR_TIME;
                    mStateNext = STATE_REDIRECT;
                    mStateTimer = 400;
                    mFrame = 0;
                }
                return;
            case STATE_REDIRECT:
                if(!mBombs.isEmpty() && !mCurrentBomb.isCarried()) {
                    // pull out a bomb if possible
                    mCurrentBomb = mBombs.remove(0);
                    if(mDirection == 1) mCurrentBomb.init(mBoundingBox.right - 6, mBoundingBox.top - 8, mDirection, 0, 0);
                    else mCurrentBomb.init(mBoundingBox.left - 10, mBoundingBox.top - 8, mDirection, 0, 0);

                    gameEngine.addGameObject(mCurrentBomb);
                }

                final int absoluteDistanceToPlayer = Math.abs(gameEngine.mPlayer.mBoundingBox.centerX() - mBoundingBox.centerX());
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX() ? 1 : -1;

                if(mCurrentBomb.isCarried()) {
                    // throw bomb
                    mState = STATE_START_THROW_BOMB;
                    mFrame = 2;
                    mVelocityX = 0;
                    if(mDirection == 1) {
                        mCurrentBomb.mX = mBoundingBox.right - 6;
                        mCurrentBomb.mY = mBoundingBox.top - 8;
                    }
                    else {
                        mCurrentBomb.mX = mBoundingBox.left - 10;
                        mCurrentBomb.mY = mBoundingBox.top - 8;
                    }
                }
                else if(absoluteDistanceToPlayer < 48 && mOnGround) {
                    // jump away
                    mState = STATE_WAIT_FOR_LANDING;
                    mVelocityX = VELOCITY_X * mDirection * -1;
                    mVelocityY = JUMP_VELOCITY;
                    mFrame = 4;
                }
                else if(mOnGround) {
                    // jump towards
                    mState = STATE_WAIT_FOR_LANDING;
                    mVelocityX = VELOCITY_X * mDirection;
                    mVelocityY = JUMP_VELOCITY;
                    mFrame = 5;
                }
                break;
            case STATE_WAIT_FOR_LANDING:
                if(mOnGround) {
                    mState = STATE_CONTINUE_FOR_TIME;
                    mStateNext = STATE_REDIRECT;
                    mStateTimer = 200;
                    mFrame = 0;
                    mVelocityX = 0;
                }
                break;
            case STATE_START_THROW_BOMB:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 100) {
                    mFrame = 3;

                    final int dist = Math.abs(gameEngine.mPlayer.mBoundingBox.centerX() - mBoundingBox.centerX());
                    mCurrentBomb.mVelocityX = .1f * mDirection * dist/96f;

                    mCurrentBomb.triggerWaitToBlow();
                    mState = STATE_CONTINUE_FOR_TIME;
                    mStateNext = STATE_REDIRECT;
                    mStateTimer = 750;
                }
                break;
            case STATE_CONTINUE_FOR_TIME:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) mState = mStateNext;
                break;
            case STATE_STUNNED:
                mVelocityX = 0;
                mFrame = 0;
                mState = STATE_CONTINUE_FOR_TIME;
                mStateNext = STATE_REDIRECT;
                mStateTimer = 1500;
                break;
        }

        gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

        updateBombPosition();
    }

    private void updateBombPosition() {
        if(mCurrentBomb.isCarried()) {
            if(mDirection == 1) {
                mCurrentBomb.mX = mBoundingBox.right - 6;
                mCurrentBomb.mY = mBoundingBox.top - 8;
            }
            else {
                mCurrentBomb.mX = mBoundingBox.left - 10;
                mCurrentBomb.mY = mBoundingBox.top - 8;
            }
        }
    }

    @Override
    public void weaponBombRelease(WeaponBomb weaponBomb) {
        mBombs.add(weaponBomb);
    }
}
