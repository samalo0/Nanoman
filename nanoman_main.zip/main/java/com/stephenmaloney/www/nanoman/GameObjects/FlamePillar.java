package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public class FlamePillar extends SpriteAnimated {
    public final static String TYPE = "FlamePillar";

    private final static int STATE_OFF = 0;
    private final static int STATE_ON = 1;
    private int mState = STATE_OFF;
    private int mStateTimer;

    private final int mOffTime;
    private final int mOnTime;
    private int mDrawY;

    private final Bitmap mBitmapClip;
    private final Canvas mCanvasClip;

    FlamePillar(Resources resources, HashMap<String, String> properties) {
        super(0, 0, 16, 16);

        // up from bottom is -1, down from top is 1
        mDirection = Integer.parseInt(properties.get("Direction"));

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2);
        updateBoundingBox();

        // mX and mY are static location for the clip bitmap
        if(mDirection == -1) {
            mY -= 47;
            mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_flame_pillar_bottom, null));
        }
        else mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_flame_pillar_top, null));

        mPlayerDamage = Integer.parseInt(properties.get("Damage"));

        mOffTime = Integer.parseInt(properties.get("OffTime"));
        mOnTime = Integer.parseInt(properties.get("OnTime"));

        mStateTimer = mOffTime;

        mBitmapClip = Bitmap.createBitmap(15, 63, Bitmap.Config.ARGB_8888);
        mCanvasClip = new Canvas(mBitmapClip);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        if(mState == STATE_ON) {
            mMatrix.reset();
            mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);
            canvas.drawBitmap(mBitmapClip, mMatrix, GameView.mPaint);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        mSpriteAnimation.onUpdate(elapsedMillis);

        switch(mState) {
            case STATE_OFF:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= mOffTime) {
                    mStateTimer = 0;
                    mState = STATE_ON;
                }
                break;
            case STATE_ON:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= mOnTime) {
                    mStateTimer = 0;
                    mState = STATE_OFF;

                    if(mDirection == 1) mBoundingBox.set(mX + 2, mY - Tile.SIZE + 2, mX + 13, mY - 2);
                    else mBoundingBox.set(mX + 2, mY + 65, mX + 13, mY + 61 + Tile.SIZE);
                }
                else {
                    final float halfTime = mOnTime >> 1;
                    final int oldY = mDrawY;

                    if (mDirection == 1) {
                        if (mStateTimer <= halfTime) mDrawY = (int) (mStateTimer / halfTime * 63 - 63);
                        else mDrawY = (int) ((1 - ((mStateTimer - halfTime) / halfTime)) * 63 - 63);

                        mBoundingBox.set(mX, mY, mX + 15, mY + mDrawY + 63);
                    } else {
                        if (mStateTimer <= halfTime) mDrawY = (int) (63 - ((mStateTimer / halfTime) * 63));
                        else mDrawY = (int) (((mStateTimer - halfTime) / halfTime) * 63);

                        mBoundingBox.set(mX, mY + mDrawY, mX + 15, mY + 63);
                    }

                    if(oldY != mDrawY) {
                        mBitmapClip.eraseColor(Color.TRANSPARENT);
                        mCanvasClip.drawBitmap(mSpriteAnimation.getBitmap(), 0, mDrawY, GameView.mPaint);
                    }
                }
                break;
        }
    }
}
