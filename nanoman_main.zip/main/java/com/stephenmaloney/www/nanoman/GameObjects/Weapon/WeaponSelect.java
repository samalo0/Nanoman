package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LightingColorFilter;
import android.graphics.Paint;
import android.graphics.Typeface;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.HorizontalDisplayBar;
import com.stephenmaloney.www.nanoman.GameObjects.Player.PlayerAmmoBars;
import com.stephenmaloney.www.nanoman.R;

public class WeaponSelect extends GameObject {
    private final static int mWidth = 96;
    private final static int mHeight = 160;

    private final static int mLeft = GameView.VIEW_WIDTH_DIV_2 - (WeaponSelect.mWidth >> 1);
    private final static int mTop = GameView.VIEW_HEIGHT_DIV_2 - (WeaponSelect.mHeight >> 1);

    private final static int mTextSize = 14;

    private final Canvas mCanvas;
    private final Bitmap mBitmap;
    private final Bitmap mBackgroundBitmap;
    private final Paint mPaint = new Paint();

    private int mSelection = 7;
    private final static int mSelectionLocationX = 14;
    private final int[] mSelectionLocationY = new int[8];
    private final static String[] mSelectionText = {"B", "C", "E", "F", "G", "I", "M", "P"};

    public boolean[] mSelectionPresent = {false, false, false, false, false, false, false, true};

    public final HorizontalDisplayBar[] mHorizontalAmmoBars = new HorizontalDisplayBar[7];

    public final static int DEFAULT_LIVES = 2;
    public int mLives = DEFAULT_LIVES;

    private boolean mBlock = false;

    public WeaponSelect(Resources resource) {
        mBitmap = Bitmap.createBitmap(mWidth, mHeight, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);
        mPaint.setTextSize(mTextSize);
        mPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));

        mBackgroundBitmap = BitmapFactory.decodeResource(resource, R.drawable.gameobject_weapon_select);

        for(int i = 0; i < 8; i++) mSelectionLocationY[i] = 24 + i * 17;

        mHorizontalAmmoBars[0] = new HorizontalDisplayBar(resource, R.drawable.gameobject_horizontal_display_bar_green_segment, 100, 25, mSelectionLocationX + 16, mSelectionLocationY[0] - 10);
        mHorizontalAmmoBars[1] = new HorizontalDisplayBar(resource, R.drawable.gameobject_horizontal_display_bar_gray_segment, 100, 25, mSelectionLocationX + 16, mSelectionLocationY[1] - 10);
        mHorizontalAmmoBars[2] = new HorizontalDisplayBar(resource, R.drawable.gameobject_horizontal_display_bar_grayyellow_segment, 100, 25, mSelectionLocationX + 16, mSelectionLocationY[2] - 10);
        mHorizontalAmmoBars[3] = new HorizontalDisplayBar(resource, R.drawable.gameobject_horizontal_display_bar_red_segment, 100, 25, mSelectionLocationX + 16, mSelectionLocationY[3] - 10);
        mHorizontalAmmoBars[4] = new HorizontalDisplayBar(resource, R.drawable.gameobject_horizontal_display_bar_orange_segment, 100, 25, mSelectionLocationX + 16, mSelectionLocationY[4] - 10);
        mHorizontalAmmoBars[5] = new HorizontalDisplayBar(resource, R.drawable.gameobject_horizontal_display_bar_blue_segment, 100, 25, mSelectionLocationX + 16, mSelectionLocationY[5] - 10);
        mHorizontalAmmoBars[6] = new HorizontalDisplayBar(resource, R.drawable.gameobject_horizontal_display_bar_blueblue_segment, 100, 25, mSelectionLocationX + 16, mSelectionLocationY[6] - 10);

        redraw();
    }

    @Override
    public void onDraw(Canvas canvas) {
        canvas.drawBitmap(mBitmap, mLeft, mTop, GameView.mPaint);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(gameEngine.mInputController.mDirectionY == 0) {
            mBlock = false;
        }
        else if(gameEngine.mInputController.mDirectionY == 1 && !mBlock) {
            mBlock = true;
            do {
                mSelection++;
                if(mSelection > 7) mSelection = 0;
            } while(!mSelectionPresent[mSelection]);

            gameEngine.mPlayer.setSelectedWeapon(mSelection);
            redraw();
            gameEngine.soundPlay(GameEngine.GameSound.MENU_SELECTION);
        }
        else if(gameEngine.mInputController.mDirectionY == -1 && !mBlock) {
            mBlock = true;
            do {
                mSelection--;
                if(mSelection < 0) mSelection = 7;
            } while(!mSelectionPresent[mSelection]);

            gameEngine.mPlayer.setSelectedWeapon(mSelection);
            redraw();
            gameEngine.soundPlay(GameEngine.GameSound.MENU_SELECTION);
        }
    }

    public void redraw() {
        mCanvas.drawBitmap(mBackgroundBitmap, 0, 0, mPaint);

        for(int i = 0; i < 7; i++) if(mSelectionPresent[i]) mHorizontalAmmoBars[i].onDraw(mCanvas);

        mPaint.setColor(Color.BLACK);
        mCanvas.drawText(Integer.toString(mLives), 69, mHeight - 15, mPaint);
        for(int i = 0; i < 8; i++) if(mSelectionPresent[i]) mCanvas.drawText(mSelectionText[i], mSelectionLocationX + 1, mSelectionLocationY[i] + 1, mPaint);

        mPaint.setColor(Color.WHITE);
        mCanvas.drawText(Integer.toString(mLives), 68, mHeight - 16, mPaint);

        for(int i = 0; i < 8; i++) {
            if(mSelection == i) {
                mPaint.setColor(Color.WHITE);
                mCanvas.drawText(mSelectionText[i], mSelectionLocationX, mSelectionLocationY[i], mPaint);
            }
            else if(mSelectionPresent[i]) {
                mPaint.setColor(Color.argb(0xFF, 54, 90, 122));
                mCanvas.drawText(mSelectionText[i], mSelectionLocationX, mSelectionLocationY[i], mPaint);
            }
        }
    }

    public void refillAll() {
        final int size = mHorizontalAmmoBars.length;
        for(int i = 0; i < size; i++) mHorizontalAmmoBars[i].add(PlayerAmmoBars.AMMO_MAX);
    }

    @Override
    public void startGame(GameEngine gameEngine) {
    }
}
