package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class Tile {
    public final static int SIZE = 16;
    public final static int SIZE_POW_2 = 4;

    boolean mClimb;
    boolean mDeath;
    boolean mIce;
    boolean mNoScroll;
    boolean mSolid;
    boolean mWater;

    Bitmap mBitmap;
    String mDrawableName;

    public Tile(Context context, String drawableName) {
        mClimb = false;
        mDeath = false;
        mNoScroll = false;
        mSolid = true;
        mIce = false;
        mWater = false;

        mDrawableName = drawableName;

        mBitmap = BitmapFactory.decodeResource(context.getResources(), context.getResources().getIdentifier(drawableName, "drawable", context.getPackageName()));
    }
}
