package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Canvas;
import android.graphics.Matrix;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;

public abstract class SpriteAnimatedMirrored extends Sprite {
    protected final SpriteAnimationDrawable mSpriteAnimation = new SpriteAnimationDrawable();
    protected int mFacingLeftAdjustmentX = 0;

    public SpriteAnimatedMirrored(int boundingBoxOffsetX, int boundingBoxOffSetY, int boundingBoxSizeX, int boundingBoxSizeY) {
        super(boundingBoxOffsetX, boundingBoxOffSetY, boundingBoxSizeX, boundingBoxSizeY);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        GameView.mMatrix.reset();
        if (mDirection == -1) {
            GameView.mMatrix.postScale(-1, 1);
            GameView.mMatrix.postTranslate(mFacingLeftAdjustmentX, 0);
        }
        GameView.mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);

        canvas.drawBitmap(mSpriteAnimation.getBitmap(), GameView.mMatrix, GameView.mPaint);
    }
}
