package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.List;

public class EnemyBubbleRobotDrone extends SpriteFrameAnimation {
    private final static float VELOCITY = .06f;

    private int mFrameTimer = 0;

    private final List<EnemyBubbleRobotShot> mShots = new ArrayList<>();
    private final static int SHOT_LIMIT = 3;
    private int mShotTimer = 0;

    private final static int STATE_CHECK_X_GREATER_START = 0;
    private final static int STATE_CHECK_Y_GREATER_START = 1;
    private final static int STATE_CHECK_X_LESS_START = 2;
    private final static int STATE_CHECK_Y1_CLOCKWISE = 3;
    private final static int STATE_CHECK_Y1_COUNTERCLOCKWISE = 4;
    private final static int STATE_CHECK_X1_CLOCKWISE = 5;
    private final static int STATE_CHECK_X1_COUNTERCLOCKWISE = 6;
    private final static int STATE_CHECK_X2_CLOCKWISE = 7;
    private final static int STATE_CHECK_X2_COUNTERCLOCKWISE = 8;
    private final static int STATE_CHECK_Y2_CLOCKWISE = 9;
    private final static int STATE_CHECK_Y2_COUNTERCLOCKWISE = 10;
    private int mState;

    private final EnemyBubbleRobot mParent;

    private final int mStartX, mStartY;

    private int mHealth;

    private boolean mDead = false;

    private float mVelocity;

    private final Explosion mExplosion;

    EnemyBubbleRobotDrone(Resources resources, Rect playerLocation, int x, int y, EnemyBubbleRobot parent) {
        super(0, 0, 64, 64, 3);
        mParent = parent;
        mStartX = x;
        mStartY = y;

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bubble_robot1);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bubble_robot2);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bubble_robot3);

        mPlayerDamage = 20;

        for(int i = 0; i < SHOT_LIMIT; i++) mShots.add(new EnemyBubbleRobotShot(resources, playerLocation, this));

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mDead &&
                (otherObject instanceof WeaponPShot
                        || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                        || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    void init(float velocity_multiplier) {
        mVelocity = velocity_multiplier * VELOCITY;

        mXFractional = 0;
        mYFractional = 0;

        final double randomValue = Math.random();
        if(randomValue < .33) {
            mX = GameView.mViewPort.left;
            mY = mStartY;
            mVelocity = velocity_multiplier * VELOCITY;
            mVelocityX = mVelocity;
            mVelocityY = 0;
            mState = STATE_CHECK_X_GREATER_START;
        }
        else if(randomValue < .66) {
            mX = GameView.mViewPort.right - 1;
            mY = mStartY;
            mVelocityX = -mVelocity;
            mVelocityY = 0;
            mState = STATE_CHECK_X_LESS_START;
        }
        else {
            mX = mStartX;
            mY = GameView.mViewPort.top;
            mVelocityX = 0;
            mVelocityY = mVelocity;
            mState = STATE_CHECK_Y_GREATER_START;
        }
        updateBoundingBox();

        mHealth = 10;
        mShotTimer = (int)(Math.random() * 3000);
        mDead = false;
        mFrame = 0;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mDead) return;

        if(otherObject instanceof WeaponPShot) {
            mHealth--;
            if(mHealth <= 0) onDeath(gameEngine);
            else gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
        else if(otherObject instanceof WeaponBomb || otherObject instanceof WeaponGuts) onDeath(gameEngine);
    }

    private void onDeath(GameEngine gameEngine) {
        mDead = true;

        mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
        gameEngine.addGameObject(mExplosion);

        gameEngine.removeGameObject(this);
        mParent.releaseDrone();
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        // blow up the bubble
        if(mFrame < 2) {
            mFrameTimer += elapsedMillis;
            if(mFrameTimer > 200) {
                mFrameTimer = 0;
                mFrame++;
            }
        }

        mShotTimer -= elapsedMillis;
        if(mShotTimer <= 0 && !mShots.isEmpty()) {
            mShotTimer = (int)(Math.random() * 3000);
            final EnemyBubbleRobotShot shot = mShots.remove(0);
            shot.init(mBoundingBox.centerX(), mBoundingBox.centerY(), gameEngine);
            gameEngine.addGameObject(shot);
        }

        final double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY = mVelocityY * elapsedMillis + mYFractional;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;
        updateBoundingBox();

        switch(mState) {
            case STATE_CHECK_X_GREATER_START:
                if(mX >= (GameView.mViewPort.left + Tile.SIZE)) {
                    final double randomValue = Math.random();
                    if(randomValue < .5) {
                        mState = STATE_CHECK_Y1_CLOCKWISE;
                        mVelocityX = 0;
                        mVelocityY = -mVelocity;
                    }
                    else {
                        mState = STATE_CHECK_Y1_COUNTERCLOCKWISE;
                        mVelocityX = 0;
                        mVelocityY = mVelocity;
                    }
                }
                break;
            case STATE_CHECK_Y_GREATER_START:
                if(mY >= (GameView.mViewPort.top + (Tile.SIZE << 1))) {
                    final double randomValue = Math.random();
                    if(randomValue < .5) {
                        mState = STATE_CHECK_X1_CLOCKWISE;
                        mVelocityX = mVelocity;
                        mVelocityY = 0;
                    }
                    else {
                        mState = STATE_CHECK_X1_COUNTERCLOCKWISE;
                        mVelocityX = -mVelocity;
                        mVelocityY = 0;
                    }
                }
                break;
            case STATE_CHECK_X_LESS_START:
                if(mX <= (GameView.mViewPort.right - (Tile.SIZE * 5))) {
                    final double randomValue = Math.random();
                    if (randomValue < .5) {
                        mState = STATE_CHECK_Y2_CLOCKWISE;
                        mVelocityX = 0;
                        mVelocityY = mVelocity;
                    } else {
                        mState = STATE_CHECK_Y2_COUNTERCLOCKWISE;
                        mVelocityX = 0;
                        mVelocityY = -mVelocity;
                    }
                }
                break;
            case STATE_CHECK_Y1_CLOCKWISE:
                if(mY <= (GameView.mViewPort.top + (Tile.SIZE << 1))) {
                    mState = STATE_CHECK_X1_CLOCKWISE;
                    mVelocityX = mVelocity;
                    mVelocityY = 0;
                }
                break;
            case STATE_CHECK_Y1_COUNTERCLOCKWISE:
                if(mY >= (GameView.mViewPort.top + (Tile.SIZE << 3))) {
                    mState = STATE_CHECK_X2_COUNTERCLOCKWISE;
                    mVelocityX = mVelocity;
                    mVelocityY = 0;
                }
                break;
            case STATE_CHECK_X1_CLOCKWISE:
                if(mX >= (GameView.mViewPort.right - (Tile.SIZE * 5))) {
                    mState = STATE_CHECK_Y2_CLOCKWISE;
                    mVelocityX = 0;
                    mVelocityY = mVelocity;
                }
                break;
            case STATE_CHECK_X1_COUNTERCLOCKWISE:
                if(mX <= (GameView.mViewPort.left + Tile.SIZE)) {
                    mState = STATE_CHECK_Y1_COUNTERCLOCKWISE;
                    mVelocityX = 0;
                    mVelocityY = mVelocity;
                }
                break;
            case STATE_CHECK_X2_CLOCKWISE:
                if(mX <= (GameView.mViewPort.left + Tile.SIZE)) {
                    mState = STATE_CHECK_Y1_CLOCKWISE;
                    mVelocityX = 0;
                    mVelocityY = -mVelocity;
                }
                break;
            case STATE_CHECK_X2_COUNTERCLOCKWISE:
                if(mX >= (GameView.mViewPort.right - (Tile.SIZE * 5))) {
                    mState = STATE_CHECK_Y2_COUNTERCLOCKWISE;
                    mVelocityX = 0;
                    mVelocityY = -mVelocity;
                }
                break;
            case STATE_CHECK_Y2_CLOCKWISE:
                if(mY >= (GameView.mViewPort.bottom - (Tile.SIZE * 7))) {
                    mState = STATE_CHECK_X2_CLOCKWISE;
                    mVelocityX = -mVelocity;
                    mVelocityY = 0;
                }
                break;
            case STATE_CHECK_Y2_COUNTERCLOCKWISE:
                if(mY <= (GameView.mViewPort.top + (Tile.SIZE << 1))) {
                    mState = STATE_CHECK_X1_COUNTERCLOCKWISE;
                    mVelocityX = -mVelocity;
                    mVelocityY = 0;
                }
                break;
        }
    }

    void releaseShot(EnemyBubbleRobotShot shot) {
        mShots.add(shot);
    }
}
