package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimated;
import com.stephenmaloney.www.nanoman.R;

public class EnemyBomberShot extends SpriteAnimated {
    private final static int[] OFFSET_X = {-16, -8, 8, 16};
    private final static int[] OFFSET_Y = {-6, 0, 0, -6};
    private final static float VELOCITY_X = .09f;

    private static final int STATE_FALLING = 0;
    private static final int STATE_EXPLODING = 1;
    private int mState = STATE_FALLING;

    private final EnemyBomberSpawn mParent;
    private final int mIndex;

    private final Rect mBoundingBoxShot = new Rect(0, 0, 8, 6);
    private final Rect mBoundingBoxExplosion = new Rect(0, 0, 16, 16);

    EnemyBomberShot(Resources resources, int resource_id, int index, EnemyBomberSpawn parent) {
        super(0, 0, 8, 6);

        mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(resource_id, null));
        mSpriteAnimation.addState(1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_explosion, null));

        mParent = parent;
        mIndex = index;

        switch(mIndex) {
            case 0:
                mDirection = -1;
                mVelocityX = VELOCITY_X * mDirection * 1.5f;
                break;
            case 1:
                mDirection = -1;
                mVelocityX = VELOCITY_X * mDirection;
                break;
            case 2:
                mDirection = 1;
                mVelocityX = VELOCITY_X * mDirection;
                break;
            case 3:
                mDirection = 1;
                mVelocityX = VELOCITY_X * mDirection * 1.5f;
                break;
        }

        mPlayerDamage = 24;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    void init(int x, int y) {
        mX = x + OFFSET_X[mIndex];
        mXFractional = 0;
        mY = y + OFFSET_Y[mIndex];
        mYFractional = 0;
        mVelocityY = 0;
        mBoundingBox.set(mBoundingBoxShot);
        updateBoundingBox();

        mOnGround = false;

        mState = STATE_FALLING;
        mSpriteAnimation.setState(0, true);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        switch(mState) {
            case STATE_FALLING:
                gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

                mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
                if(mVelocityY > GameEngine.TERMINAL_VELOCITY) mVelocityY = GameEngine.TERMINAL_VELOCITY;

                gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

                if(mOnGround) {
                    mState = STATE_EXPLODING;
                    mSpriteAnimation.setState(1, true);
                    mBoundingBox.set(mBoundingBoxExplosion);
                    mX -= 4;
                    mY -= 5;
                    updateBoundingBox();

                    gameEngine.soundPlay(GameEngine.GameSound.EXPLOSION);
                }
                break;
            case STATE_EXPLODING:
                mSpriteAnimation.onUpdate(elapsedMillis);
                if(mSpriteAnimation.mOneShotFired) {
                    gameEngine.removeGameObject(this);
                    mParent.releaseEnemyBomberShot(this);
                }
                break;
        }
    }
}
