package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.R;

class EnemyRobotShot extends EnemyShot {
    private final static float VELOCITY_X = .15f;

    private final EnemyRobotHead mParent;

    EnemyRobotShot(Resources resources, EnemyRobotHead parent) {
        super(resources, R.drawable.gameobject_enemy_shot_green);

        mParent = parent;
    }

    void init(int x, int y, int direction, GameEngine gameEngine) {
        mX = x;
        mY = y;
        mXFractional = 0;
        mYFractional = 0;
        updateBoundingBox();

        mDirection = direction;

        mVelocityX = mDirection * VELOCITY_X;

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_SHOOT);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseShot();
            return;
        }

        super.onUpdate(elapsedMillis, gameEngine);
    }
}
