package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirrored;
import com.stephenmaloney.www.nanoman.R;

public class EnemyScissors extends SpriteAnimatedMirrored {
    private final static float VELOCITY_X = .05f;
    private final static float VELOCITY_X_FAR = .1f;
    private final static float VELOCITY_Y = -.2f;

    private final EnemyScissorsSpawn mParent;

    EnemyScissors(Resources resources, EnemyScissorsSpawn parent) {
        super(0, 0, 16, 20);

        mParent = parent;

        mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_scissors, null));
        mFacingLeftAdjustmentX = 16;

        mPlayerDamage = 12;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    void init(int x, int y, int direction, boolean far, GameEngine gameEngine) {
        mX = x;
        mY = y;
        mXFractional = 0;
        mYFractional = 0;
        updateBoundingBox();

        mDirection = direction;
        if(far) mVelocityX = VELOCITY_X_FAR * mDirection;
        else mVelocityX = VELOCITY_X * mDirection;

        mVelocityY = VELOCITY_Y;

        gameEngine.soundPlay(GameEngine.GameSound.SCISSORS);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseScissors(this);
            return;
        }

        mSpriteAnimation.onUpdate(elapsedMillis);
        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;

        final double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY= mVelocityY * elapsedMillis + mYFractional;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;

        updateBoundingBox();
    }
}
