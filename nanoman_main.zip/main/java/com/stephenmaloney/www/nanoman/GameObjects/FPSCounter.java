package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;

public class FPSCounter extends GameObject {
    private final Paint mPaint = new Paint();
    private final static int TEXT_WIDTH = 50;
    private final static int TEXT_HEIGHT = 25;

    private long mTotalMillis = 0;
    private int mDraws = 0;

    private final Bitmap mBitmap;
    private final Canvas mCanvas;

    public FPSCounter() {
        mPaint.setTextAlign(Paint.Align.CENTER);
        mPaint.setTextSize(TEXT_HEIGHT >> 1);

        mBitmap = Bitmap.createBitmap(TEXT_WIDTH, TEXT_HEIGHT, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);
    }

    @Override
    public void onDraw(Canvas canvas) {
        canvas.drawBitmap(mBitmap, 0, GameView.VIEW_HEIGHT - TEXT_HEIGHT, GameView.mPaint);
        mDraws++;
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mTotalMillis += elapsedMillis;
        if(mTotalMillis > 1000) {
            final String mFpsText = mDraws * 1000 / mTotalMillis + " fps";
            mTotalMillis = 0;
            mDraws = 0;

            mPaint.setColor(Color.BLACK);
            mCanvas.drawRect(0, 0, TEXT_WIDTH, TEXT_HEIGHT, mPaint);
            mPaint.setColor(Color.WHITE);
            mCanvas.drawText(mFpsText, TEXT_WIDTH / 2, TEXT_HEIGHT /2, mPaint);
        }
    }

    @Override
    public void startGame(GameEngine gameEngine) {
        mTotalMillis = 0;
    }
}
