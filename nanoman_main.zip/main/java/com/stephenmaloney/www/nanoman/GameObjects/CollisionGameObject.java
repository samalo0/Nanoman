package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

public abstract class CollisionGameObject extends GameObject {
    // position
    public int mX = 0;
    public double mXFractional = 0;
    public int mY = 0;
    public double mYFractional = 0;
    public int mDirection = 1;

    // damage to player on collision
    public int mPlayerDamage = 0;

    // bounding box
    public final Rect mBoundingBox = new Rect(-1, -1, -1, -1);
    protected int mBoundingBoxOffsetX;
    protected int mBoundingBoxOffsetY;

    public CollisionGameObject(int boundingBoxOffsetX, int boundingBoxOffsetY, int boundingBoxSizeX, int boundingBoxSizeY) {
        mBoundingBoxOffsetX = boundingBoxOffsetX;
        mBoundingBoxOffsetY = boundingBoxOffsetY;
        mBoundingBox.set(boundingBoxOffsetX, boundingBoxOffsetY, boundingBoxOffsetX + boundingBoxSizeX, boundingBoxOffsetY + boundingBoxSizeY);
    }

    public abstract boolean checkCollision(CollisionGameObject otherObject);

    public abstract void onCollision(GameEngine gameEngine, CollisionGameObject otherObject);

    public void updateBoundingBox() {
        mBoundingBox.offsetTo(mX + mBoundingBoxOffsetX, mY + mBoundingBoxOffsetY);
    }
}
