package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.BoundingBox;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimationMirrored;
import com.stephenmaloney.www.nanoman.R;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public class WeaponElectricityHorizontal extends SpriteFrameAnimationMirrored {
    public final SpriteAnimatedMirroredWeapons mParent;

    private final static float VELOCITY_X = .15f;

    private final static int FRAME_MILLIS = 50;
    private final static int FRAMES = 7;
    private int frameTimer = 0;

    private BoundingBox[] mBoundingBoxes = new BoundingBox[7];

    private final WeaponElectricity mWeaponElectricityParent;

    WeaponElectricityHorizontal(Resources resources, WeaponElectricity weaponElectricityParent, SpriteAnimatedMirroredWeapons parent) {
        super(0, 0, 0, 0, 7, 32);

        mParent = parent;

        mWeaponElectricityParent = weaponElectricityParent;

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.weapon_electricity1);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.weapon_electricity2);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.weapon_electricity3);
        mFrames[3] = BitmapFactory.decodeResource(resources, R.drawable.weapon_electricity4);
        mFrames[4] = BitmapFactory.decodeResource(resources, R.drawable.weapon_electricity5);
        mFrames[5] = BitmapFactory.decodeResource(resources, R.drawable.weapon_electricity6);
        mFrames[6] = BitmapFactory.decodeResource(resources, R.drawable.weapon_electricity7);

        mBoundingBoxes[0] = new BoundingBox(0, 0, 32, 40);
        mBoundingBoxes[1] = new BoundingBox(0, 0, 38, 40);
        mBoundingBoxes[2] = new BoundingBox(0, 4, 38, 32);
        mBoundingBoxes[3] = new BoundingBox(0, 4, 32, 32);
        mBoundingBoxes[4] = new BoundingBox(0, 0, 32, 40);
        mBoundingBoxes[5] = new BoundingBox(0, 4, 30, 32);
        mBoundingBoxes[6] = new BoundingBox(0, 0, 32, 40);

        mFrame = 0;
        mBoundingBox.set(mBoundingBoxes[0].mRect);

        mPlayerDamage = 25;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject != mParent);
    }

    void init(int x, int y, int direction) {
        mXFractional = 0;
        mYFractional = 0;
        mX = x;
        mY = y;
        updateBoundingBox();

        mDirection = direction;
        mVelocityX = VELOCITY_X * direction;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {}

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mWeaponElectricityParent.releaseHorizontal();
            return;
        }

        frameTimer += elapsedMillis;
        if(frameTimer >= FRAME_MILLIS) {
            frameTimer = 0;
            if(mFrame == (FRAMES - 1)) mFrame = 0;
            else mFrame++;

            mBoundingBox.set(mBoundingBoxes[mFrame].mRect);
        }

        final double dX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) dX;
        mXFractional = dX % 1;
        updateBoundingBox();
    }

    @Override
    public void updateBoundingBox() {
        mBoundingBox.offsetTo(mX + mBoundingBoxes[mFrame].mOffsetX, mY + mBoundingBoxes[mFrame].mOffsetY);
    }
}
