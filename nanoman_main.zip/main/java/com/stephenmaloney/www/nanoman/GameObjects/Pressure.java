package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

import java.util.HashMap;

class Pressure extends GameObject {
    public final static String TYPE = "Pressure";
    private final static float VELOCITY_X = .07f;

    private final Rect mBoundingBox;
    private final float mVelocityX;

    private boolean mPlayedSound = false;

    Pressure(HashMap<String, String> properties) {
        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;
        mBoundingBox = new Rect(x, y, x + Tile.SIZE, y + Tile.SIZE);

        final int direction = Integer.parseInt(properties.get("Direction"));
        mVelocityX = VELOCITY_X * direction;
    }

    @Override
    public void onDraw(Canvas canvas) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.mPlayer.mPushVelocity = mVelocityX;
            if(!mPlayedSound) {
                mPlayedSound = true;
                gameEngine.soundPlay(GameEngine.GameSound.WATER_RUSH);
            }
        }
        else if(mPlayedSound) mPlayedSound = false;
    }
}
