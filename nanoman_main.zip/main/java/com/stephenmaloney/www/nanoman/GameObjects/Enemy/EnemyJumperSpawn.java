package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class EnemyJumperSpawn extends GameObject {
    public final static String TYPE = "EnemyJumper";

    private final Rect mBoundingBox;

    private final static int STATE_SPAWN_ON_SIGHT = 0;
    private final static int STATE_WAIT_FOR_SCROLL_AWAY = 1;
    private int mState = STATE_SPAWN_ON_SIGHT;

    private final EnemyJumper mJumper;
    private boolean mJumperReleased = true;

    public EnemyJumperSpawn(Resources resources, HashMap<String, String> properties) {
        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) + 6;
        mBoundingBox = new Rect(x, y, x + 10, y + 10);

        final String color = properties.get("Color");
        mJumper = new EnemyJumper(resources, color, this);
    }

    @Override
    public void onDraw(Canvas canvas) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) { //GameView.mViewPort.contains(mBoundingBox)) {
            if(mState == STATE_WAIT_FOR_SCROLL_AWAY && mJumperReleased) mState = STATE_SPAWN_ON_SIGHT;
            return;
        }

        switch(mState) {
            case STATE_SPAWN_ON_SIGHT:
                if(mJumperReleased) {
                    mJumperReleased = false;
                    mJumper.init(mBoundingBox.left, mBoundingBox.top);
                    gameEngine.addGameObject(mJumper);
                    mState = STATE_WAIT_FOR_SCROLL_AWAY;
                }
                break;
            case STATE_WAIT_FOR_SCROLL_AWAY:
                // do nothing
                break;
        }
    }

    void releaseJumper() {
        mJumperReleased = true;
    }

    @Override
    public void startGame(GameEngine gameEngine) {
    }
}
