package com.stephenmaloney.www.nanoman.GameObjects.Enemy;


import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EnemyBomberSpawn extends GameObject {
    public final static String TYPE = "EnemyBomber";

    private final static int STATE_WAIT_FOR_ON_SCREEN = 0;
    private final static int STATE_DELAY = 1;
    private final static int STATE_SPAWN = 2;
    private final static int STATE_WAIT_FOR_SHOT_TRIGGER = 3;
    private final static int STATE_CREATE_SHOTS = 4;
    private final static int STATE_WAIT_FOR_SHOT_RELEASE = 5;
    private int mState = STATE_WAIT_FOR_ON_SCREEN;
    private int mStateTimer = 0;

    private final Rect mBoundingBox;

    private final int mX;
    private int mShotY;

    private final EnemyBomber mEnemyBomber;
    private boolean mEnemyBomberReleased = true;

    private final List<EnemyBomberShot> mEnemyBomberShots = new ArrayList<>();

    public EnemyBomberSpawn(Resources resources, HashMap<String, String> properties) {
        mX =  Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y =  Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;

        int id;
        final String color = properties.get("Color");
        if(color.equals("Red")) {
            id = R.drawable.gameobject_enemy_bomber_red;
            for(int i = 0; i < 4; i ++) mEnemyBomberShots.add(new EnemyBomberShot(resources, R.drawable.animation_enemy_bomber_shot_red, i, this));
        }
        else {
            id = R.drawable.gameobject_enemy_bomber_blue;
            for(int i = 0; i < 4; i ++) mEnemyBomberShots.add(new EnemyBomberShot(resources, R.drawable.animation_enemy_bomber_shot_blue, i, this));
        }

        mBoundingBox = new Rect(mX, y, mX + Tile.SIZE, y + Tile.SIZE);

        mEnemyBomber = new EnemyBomber(resources, id, mX, this);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        switch(mState) {
            case STATE_WAIT_FOR_ON_SCREEN:
                if(GameEngine.isObjectVisible(mBoundingBox)) mState = STATE_SPAWN;
                break;
            case STATE_SPAWN:
                if(mEnemyBomberReleased) {
                    mEnemyBomberReleased = false;
                    mEnemyBomber.init();
                    gameEngine.addGameObject(mEnemyBomber);
                    mState = STATE_WAIT_FOR_SHOT_TRIGGER;
                }
                break;
            case STATE_WAIT_FOR_SHOT_TRIGGER:
                break;
            case STATE_CREATE_SHOTS:
                EnemyBomberShot shot;
                while(!mEnemyBomberShots.isEmpty()) {
                    shot = mEnemyBomberShots.remove(0);
                    shot.init(mX, mShotY);
                    gameEngine.addGameObject(shot);
                }
                mState = STATE_WAIT_FOR_SHOT_RELEASE;
                break;
            case STATE_WAIT_FOR_SHOT_RELEASE:
                if(mEnemyBomberShots.size() == 4) mState = STATE_DELAY;
                break;
            case STATE_DELAY:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 2000) {
                    mStateTimer = 0;
                    mState = STATE_WAIT_FOR_ON_SCREEN;
                }
                break;
        }
    }

    void releaseEnemyBomber() {
        mEnemyBomberReleased = true;
    }

    void releaseEnemyBomberShot(EnemyBomberShot shot) {
        mEnemyBomberShots.add(shot);
    }

    void triggerShots(int y) {
        mState = STATE_CREATE_SHOTS;
        mShotY = y;
    }
}
