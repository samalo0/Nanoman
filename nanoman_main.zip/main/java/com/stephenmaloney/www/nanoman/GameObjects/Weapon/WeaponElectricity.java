package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;

public class WeaponElectricity {
    private WeaponElectricityHorizontal mHorizontal;

    private final WeaponElectricityVertical[] mVertical = new WeaponElectricityVertical[2];

    private final SpriteAnimatedMirroredWeapons mParent;

    private boolean mHorizontalReleased = true;
    private boolean mVerticalReleased[] = new boolean[2];

    public WeaponElectricity(Resources resources, SpriteAnimatedMirroredWeapons parent) {
        mParent = parent;

        mVertical[0] = new WeaponElectricityVertical(resources, this, 0, parent);
        mVertical[1] = new WeaponElectricityVertical(resources, this, 1, parent);
        mHorizontal = new WeaponElectricityHorizontal(resources, this, parent);

        mVerticalReleased[0] = true;
        mVerticalReleased[1] = true;
        mHorizontalReleased = true;
    }

    public void addGameObjects(GameEngine gameEngine) {
        mVerticalReleased[0] = false;
        mVerticalReleased[1] = false;
        mHorizontalReleased = false;
        gameEngine.addGameObject(mHorizontal);
        gameEngine.addGameObject(mVertical[0]);
        gameEngine.addGameObject(mVertical[1]);
        gameEngine.soundPlay(GameEngine.GameSound.WEAPON_ELECTRICITY);
    }

    public void init(int x, int y, int direction) {
        mHorizontal.init(x, y, direction);
        if(direction == -1) {
            mVertical[0].init(x + 21, y, -1);
            mVertical[1].init(x + 21, y, 1);
        }
        else {
            mVertical[0].init(x, y, -1);
            mVertical[1].init(x, y, 1);
        }
    }

    void releaseHorizontal() {
        mHorizontalReleased = true;
        if(mVerticalReleased[0] && mVerticalReleased[1]) mParent.weaponElectricityRelease(this);
    }

    void releaseVertical(int index) {
        mVerticalReleased[index] = true;
        if(mHorizontalReleased && mVerticalReleased[0] && mVerticalReleased[1]) mParent.weaponElectricityRelease(this);
    }
}
