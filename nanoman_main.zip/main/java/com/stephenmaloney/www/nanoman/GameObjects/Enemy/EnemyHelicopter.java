package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimated;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

public class EnemyHelicopter extends SpriteAnimated {
    private final static int STATE_APPROACH = 0;
    private final static int STATE_CONTINUE_FOR_TIME = 1;
    private final static int STATE_ANGLE_AWAY = 2;
    private final static int STATE_RETREAT = 3;
    private int mState = STATE_APPROACH;
    private int mStateNext;
    private int mStateTimer = 0;

    private final EnemyHelicopterSpawn mParent;

    private final static float VELOCITY = .1f;

    private final Rect mRectPlayer;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    EnemyHelicopter(Resources resources, String color, int direction, Rect rectPlayer, EnemyHelicopterSpawn parent) {
        super(0, 0, 16, 20);

        mParent = parent;
        mDirection = direction;
        mRectPlayer = rectPlayer;

        switch(color) {
            case "Blue":
                mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_helicopter_blue, null));
                break;
            case "Green":
                mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_helicopter_green, null));
                break;
        }

        mPlayerDamage = 12;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    void init() {
        mHurtOrDead = false;
        if(mDirection == 1) {
            mX = GameView.mViewPort.left;
        }
        else {
            mX = GameView.mViewPort.right - 1;
        }
        mY = mRectPlayer.top - 32;
        mXFractional = 0;
        mYFractional = 0;
        updateBoundingBox();
        mState = STATE_APPROACH;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts) {

            mHurtOrDead = true;

            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

            gameEngine.removeGameObject(this);
            mParent.releaseHelicopter();

            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        switch(mState) {
            case STATE_APPROACH:
                if(Math.abs(mRectPlayer.left - mBoundingBox.left) < 32) {
                    mState = STATE_CONTINUE_FOR_TIME;
                    mStateNext = STATE_ANGLE_AWAY;
                    mStateTimer = 400;

                    mDirection = (mRectPlayer.left < mBoundingBox.left) ? -1 : 1;
                    mVelocityX = mDirection * VELOCITY;

                    if(mRectPlayer.centerY() > mBoundingBox.centerY()) mVelocityY = VELOCITY;
                    else mVelocityY = VELOCITY * -1;
                }
                else {
                    mDirection = (gameEngine.mPlayer.mBoundingBox.left < mBoundingBox.left) ? -1 : 1;
                    mVelocityX = mDirection * VELOCITY;
                    mVelocityY = 0;
                }
                break;
            case STATE_CONTINUE_FOR_TIME:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    mState = mStateNext;
                }
                break;
            case STATE_ANGLE_AWAY:
                mDirection *= -1;
                mVelocityY *= -1;
                mState = STATE_CONTINUE_FOR_TIME;
                mStateNext = STATE_RETREAT;
                mStateTimer = 400;
                break;
            case STATE_RETREAT:
                if(Math.abs(mRectPlayer.centerX() - mBoundingBox.centerX()) > 112 && (mRectPlayer.centerY() - mBoundingBox.centerY() < 48)) {
                    mState = STATE_APPROACH;
                }
                else {
                    mDirection = (gameEngine.mPlayer.mBoundingBox.left < mBoundingBox.left) ? 1 : -1;
                    mVelocityX = mDirection * VELOCITY;

                    if((mRectPlayer.top - 32) > mBoundingBox.top) mVelocityY = VELOCITY;
                    else mVelocityY = -VELOCITY;
                }
                break;
        }

        mSpriteAnimation.onUpdate(elapsedMillis);
        final double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY= mVelocityY * elapsedMillis + mYFractional;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;

        updateBoundingBox();
    }
}
