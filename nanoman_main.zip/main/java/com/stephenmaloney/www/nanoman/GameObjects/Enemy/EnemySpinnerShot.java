package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

class EnemySpinnerShot extends EnemyShot {
    private final EnemySpinner mParent;
    private final int mIndex;
    private final int mReleaseIndex;

    private final static float VELOCITY = .2f;
    private final static int[] OFFSET_X = {-10, -6, 0, 6, 10};
    private final static int[] OFFSET_Y_FLOOR = {0, -6, -6, -6, 0};
    private final static int[] OFFSET_Y_CEILING = {0, 6, 6, 6, 0};
    private final int[] OFFSET_Y;

    EnemySpinnerShot(Resources resources, int resource_id, int index, int position, EnemySpinner parent) {
        super(resources, resource_id);
        mParent = parent;

        mReleaseIndex = index;
        if(index > 4) mIndex = index - 5;
        else mIndex = index;

        switch (mIndex) {
            case 0:
                mDirection = -1;
                mVelocityX = VELOCITY * -1;
                mVelocityY = 0;
                break;
            case 1:
                mDirection = -1;
                mVelocityX = VELOCITY * (float)Math.cos(135 * Math.PI / 180);
                mVelocityY = VELOCITY * (float)Math.sin(135 * Math.PI / 180) * position;
                break;
            case 2:
                mDirection = -1;
                mVelocityX = 0;
                mVelocityY = VELOCITY * position;
                break;
            case 3:
                mDirection = 1;
                mVelocityX = VELOCITY * (float)Math.cos(45 * Math.PI / 180);
                mVelocityY = VELOCITY * (float)Math.sin(45 * Math.PI / 180) * position;
                break;
            case 4:
                mDirection = 1;
                mVelocityX = VELOCITY;
                mVelocityY = 0;
                break;
        }

        if(position == EnemySpinner.POSITION_FLOOR) OFFSET_Y = OFFSET_Y_FLOOR;
        else OFFSET_Y = OFFSET_Y_CEILING;
    }

    void init(int x, int y, GameEngine gameEngine) {
        mX = x + OFFSET_X[mIndex];
        mY = y + OFFSET_Y[mIndex];
        mXFractional = 0;
        mYFractional = 0;
        updateBoundingBox();

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_SHOOT);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            mParent.releaseShot(mReleaseIndex);
            gameEngine.removeGameObject(this);
        }

        super.onUpdate(elapsedMillis, gameEngine);
    }
}
