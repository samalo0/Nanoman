package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;

public class HorizontalDisplayBar extends GameObject {
    private final int mMaximumValue;
    private final int mValuePerSegment;

    private final int mLeft;
    private final int mTop;
    private final int mWidth;
    private final int mHeight;

    public int mValue;

    private final Bitmap mBitmapSegment;

    private final Paint mPaint = new Paint();
    private final Canvas mCanvas;
    private final Bitmap mBitmap;

    public HorizontalDisplayBar(Resources resources, int resourceId, int maximum_value, int segments, int x, int y) {
        mMaximumValue = maximum_value;
        mValuePerSegment = mMaximumValue / segments;

        mLeft = x;
        mTop = y;
        mWidth = (segments << 1) + 1;
        mHeight = 8;

        mBitmapSegment = BitmapFactory.decodeResource(resources, resourceId);

        mPaint.setColor(Color.BLACK);

        mBitmap = Bitmap.createBitmap(mWidth, mHeight, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);

        mValue = mMaximumValue;
        redraw();
    }

    public void add(int value) {
        mValue += value;
        if(mValue > mMaximumValue) mValue = mMaximumValue;
        redraw();
    }

    @Override
    public void onDraw(Canvas canvas) {
        canvas.drawBitmap(mBitmap, mLeft, mTop, GameView.mPaint);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
    }

    private void redraw() {
        mCanvas.drawRect(0, 0, mWidth, mHeight, mPaint);

        int stopColumn = (mValue / mValuePerSegment) << 1;
        for(int pixelColumn = 1; pixelColumn < stopColumn; pixelColumn += 2) {
            mCanvas.drawBitmap(mBitmapSegment, pixelColumn, 0, null);
        }
    }

    public boolean remove(int value) {
        mValue -= value;
        if(mValue < 0) mValue = 0;
        redraw();

        return mValue == 0;
    }

    @Override
    public void startGame(GameEngine gameEngine) {
        mValue = mMaximumValue;
        redraw();
    }
}
