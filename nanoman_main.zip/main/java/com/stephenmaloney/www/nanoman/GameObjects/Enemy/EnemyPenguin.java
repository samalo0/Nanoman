package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

public class EnemyPenguin extends SpriteAnimatedMirrored {
    private final static float VELOCITY_X = .08f;

    private final EnemyPenguinSpawn mParent;

    private float mAngle = 0;
    private int mOriginalY;

    private final static int STATE_FLY = 0;
    private final static int STATE_STUNNED = 1;
    private int mState = STATE_FLY;
    private int mStunnedTimer = 0;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    EnemyPenguin(Resources resources, int direction, EnemyPenguinSpawn parent) {
        super(0, 0, 24, 15);

        mParent = parent;
        mDirection = direction;

        mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_penguin, null));

        mFacingLeftAdjustmentX = 24;
        mPlayerDamage = 24;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    void init(int x, int y) {
        mHurtOrDead = false;

        mX = x;
        mY = y;
        mXFractional = 0;
        mYFractional = 0;
        updateBoundingBox();

        mOriginalY = y;
        mAngle = (float)Math.PI;
        mVelocityX = VELOCITY_X * mDirection;

        mState = STATE_FLY;
        mSpriteAnimation.setState(0, true);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts) {

            mHurtOrDead = true;

            // explode!
            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

            gameEngine.removeGameObject(this);
            mParent.releasePenguin();

            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
        else if(otherObject instanceof WeaponIce) {
            mState = STATE_STUNNED;
            mStunnedTimer = 0;
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if((mDirection == 1 && mBoundingBox.right > GameView.mViewPort.right) || (mDirection == -1 && mBoundingBox.left < GameView.mViewPort.left)) {
            gameEngine.removeGameObject(this);
            mParent.releasePenguin();
            return;
        }

        switch(mState) {
            case STATE_FLY:
                final double distanceX = mVelocityX * elapsedMillis + mXFractional;
                mX += (int) distanceX;
                mXFractional = distanceX % 1;

                mAngle += elapsedMillis / 275f;

                final double positionY = mOriginalY + mYFractional + 50 * Math.sin(mAngle);
                mY = (int)positionY;
                mYFractional = positionY % 1;
                updateBoundingBox();
                break;
            case STATE_STUNNED:
                mStunnedTimer += elapsedMillis;
                if(mStunnedTimer > 1500) {
                    mStunnedTimer = 0;
                    mState = STATE_FLY;
                }
                break;
        }

        mSpriteAnimation.onUpdate(elapsedMillis);
    }
}
