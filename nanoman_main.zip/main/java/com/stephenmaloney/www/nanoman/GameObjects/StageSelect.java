package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.R;

public class StageSelect extends GameObject {
    public final static int STAGE_ICEMAN = 0;
    public final static int STAGE_BOMBMAN = 1;
    public final static int STAGE_FIREMAN = 2;
    public final static int STAGE_ELECMAN = 3;
    public final static int STAGE_CUTMAN = 4;
    public final static int STAGE_GUTSMAN = 5;
    public final static int STAGE_WILY = 6;
    public final static int STAGE_WILY2 = 7;
    public final static int STAGE_WILY3 = 8;
    public final static int STAGE_WILY4 = 9;

    private final static int CIRCLE_RADIUS = 80;
    private final static int FRAME_SIZE = 45;
    private final static int FRAME_SIZE_DIV_2 = FRAME_SIZE >> 1;
    private final static int FRAME_OFFSET = 6;
    private final static int TEXT_SIZE = 12;
    private final static int SQUARE_SIZE = 32;

    private final static int BLINK_MILLIS = 100;

    private final Bitmap mBitmapBackground;
    private final Canvas mCanvas;
    private final int[] locationX = {0, 0, 0, 0, 0, 0, 0};
    private final int[] locationY = {0, 0, 0, 0, 0, 0, 0};

    private final Bitmap mBitmapFramePink;
    private final Bitmap mBitmapFrameBlue;

    private final Bitmap mBitmapBombman;
    private final Bitmap mBitmapCutman;
    private final Bitmap mBitmapElecman;
    private final Bitmap mBitmapFireman;
    private final Bitmap mBitmapGutsman;
    private final Bitmap mBitmapIceman;
    private final Bitmap mBitmapWily;

    private int mSelection = 4;
    private int mTimer = 0;
    private boolean mPinkActive = false;
    private boolean mBlock = false;

    private boolean mWilyAvailable = false;

    private final Paint mDrawPaint = new Paint();

    public StageSelect(Resources resource) {
        // create the background bitmap and canvas
        mBitmapBackground = Bitmap.createBitmap(GameView.VIEW_WIDTH, GameView.VIEW_HEIGHT, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmapBackground);

        // paint background color
        mDrawPaint.setColor(Color.argb(255, 0, 113, 241));
        mCanvas.drawRect(0, 0, mBitmapBackground.getWidth(), mBitmapBackground.getHeight(), mDrawPaint);

        // paint stage select text
        mDrawPaint.setColor(Color.WHITE);
        mDrawPaint.setTextSize(TEXT_SIZE);
        mDrawPaint.setTextAlign(Paint.Align.CENTER);
        //mDrawPaint.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        mCanvas.drawText("STAGE", GameView.VIEW_WIDTH_DIV_2, GameView.VIEW_HEIGHT_DIV_2, mDrawPaint);
        mCanvas.drawText("SELECT", GameView.VIEW_WIDTH_DIV_2, GameView.VIEW_HEIGHT_DIV_2 + TEXT_SIZE, mDrawPaint);

        // generate coordinates for selection windows
        int index = 0;
        for(double angle = 0; angle <= 2 * Math.PI; angle += (Math.PI / 3)) {
            locationX[index] = (int)(CIRCLE_RADIUS * Math.cos(angle) + GameView.VIEW_WIDTH_DIV_2 - FRAME_SIZE_DIV_2);
            locationY[index] = (int)(CIRCLE_RADIUS * Math.sin(angle) + GameView.VIEW_HEIGHT_DIV_2 - FRAME_SIZE_DIV_2);
            index++;
            if(index == 6) break;
        }

        locationX[STAGE_WILY] = GameView.VIEW_WIDTH_DIV_2 - FRAME_SIZE_DIV_2;
        locationY[STAGE_WILY] = GameView.VIEW_HEIGHT_DIV_2 - FRAME_SIZE_DIV_2;

        // draw selection windows
        mBitmapFrameBlue = BitmapFactory.decodeResource(resource, R.drawable.gameobject_stage_select_frame1);
        mDrawPaint.setColor(Color.WHITE);
        for(int i = 0; i < 6; i++) {
            mCanvas.drawBitmap(mBitmapFrameBlue, locationX[i], locationY[i], mDrawPaint);

            // draw selection text
            switch(i) {
                case 0:
                    mCanvas.drawText("ICEMAN", locationX[i] + FRAME_SIZE_DIV_2, locationY[i] + FRAME_SIZE + TEXT_SIZE, mDrawPaint);
                    break;
                case 1:
                    mCanvas.drawText("BOMBMAN", locationX[i] + FRAME_SIZE_DIV_2, locationY[i] + FRAME_SIZE + TEXT_SIZE, mDrawPaint);
                    break;
                case 2:
                    mCanvas.drawText("FIREMAN", locationX[i] + FRAME_SIZE_DIV_2, locationY[i] + FRAME_SIZE + TEXT_SIZE, mDrawPaint);
                    break;
                case 3:
                    mCanvas.drawText("ELECMAN", locationX[i] + FRAME_SIZE_DIV_2, locationY[i] + FRAME_SIZE + TEXT_SIZE, mDrawPaint);
                    break;
                case 4:
                    mCanvas.drawText("CUTMAN", locationX[i] + FRAME_SIZE_DIV_2, locationY[i] + FRAME_SIZE + TEXT_SIZE, mDrawPaint);
                    break;
                case 5:
                    mCanvas.drawText("GUTSMAN", locationX[i] + FRAME_SIZE_DIV_2, locationY[i] + FRAME_SIZE + TEXT_SIZE, mDrawPaint);
                    break;
            }
        }

        // create resources for redrawing
        mBitmapFramePink = BitmapFactory.decodeResource(resource, R.drawable.gameobject_stage_select_frame2);

        mBitmapCutman = BitmapFactory.decodeResource(resource, R.drawable.gameobject_enemy_cutman_stand1);
        mBitmapElecman = BitmapFactory.decodeResource(resource, R.drawable.gameobject_enemy_elecman_stand);
        mBitmapFireman = BitmapFactory.decodeResource(resource, R.drawable.gameobject_enemy_fireman_stand1);
        mBitmapWily = BitmapFactory.decodeResource(resource, R.drawable.gameobject_enemy_wily_stand);

        final Matrix matrix = new Matrix();
        matrix.preScale(-1, 1);
        Bitmap bitmap = BitmapFactory.decodeResource(resource, R.drawable.gameobject_enemy_bombman_hand_up);
        mBitmapBombman = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);

        bitmap = BitmapFactory.decodeResource(resource, R.drawable.gameobject_enemy_gutsman_stand_mouth_open);
        mBitmapGutsman = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);

        bitmap = BitmapFactory.decodeResource(resource, R.drawable.gameobject_enemy_iceman_stand);
        mBitmapIceman = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
    }

    @Override
    public void onDraw(Canvas canvas) {
        canvas.drawBitmap(mBitmapBackground, 0, 0, mDrawPaint);

        if(mPinkActive) canvas.drawBitmap(mBitmapFramePink, locationX[mSelection], locationY[mSelection], mDrawPaint);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        // update blink
        mTimer += elapsedMillis;
        if(mTimer >= BLINK_MILLIS) {
            mTimer = 0;
            mPinkActive = !mPinkActive;
        }

        // check for left/right
        final int direction = gameEngine.mInputController.mDirectionX;

        if(direction == 0) mBlock = false;

        if(direction != 0 && !mBlock) {
            mBlock = true;
            if(direction == 1) {
                if(mWilyAvailable) {
                    if(mSelection == 6) mSelection = 0;
                    else mSelection++;
                }
                else {
                    if(mSelection == 5) mSelection = 0;
                    else mSelection++;
                }
            }
            else {
                if(mWilyAvailable) {
                    if (mSelection == 0) mSelection = 6;
                    else mSelection--;
                }
                else {
                    if (mSelection == 0) mSelection = 5;
                    else mSelection--;
                }
            }

            gameEngine.soundPlay(GameEngine.GameSound.MENU_SELECTION);
        }

        // check for start
        if(gameEngine.mInputController.mButtonStartPressed) {
            gameEngine.mInputController.mButtonStartPressed = false;
            gameEngine.startStage(mSelection, false);
            gameEngine.soundPlay(GameEngine.GameSound.GAME_START);
        }
    }

    @Override
    public void startGame(GameEngine gameEngine) {
        final boolean[] color = new boolean[7];

        final boolean[] weaponsPresent = gameEngine.mPlayer.mWeaponSelect.mSelectionPresent;

        color[STAGE_ICEMAN] = weaponsPresent[Player.WEAPON_ICE];
        color[STAGE_BOMBMAN] = weaponsPresent[Player.WEAPON_BOMB];
        color[STAGE_FIREMAN] = weaponsPresent[Player.WEAPON_FIRE];
        color[STAGE_ELECMAN] = weaponsPresent[Player.WEAPON_ELECTRICITY];
        color[STAGE_CUTMAN] = weaponsPresent[Player.WEAPON_CUTTER];
        color[STAGE_GUTSMAN] = weaponsPresent[Player.WEAPON_GUTS];

        mWilyAvailable = weaponsPresent[Player.WEAPON_BOMB]
                && weaponsPresent[Player.WEAPON_CUTTER]
                && weaponsPresent[Player.WEAPON_ELECTRICITY]
                && weaponsPresent[Player.WEAPON_FIRE]
                && weaponsPresent[Player.WEAPON_GUTS]
                && weaponsPresent[Player.WEAPON_ICE];
        color[STAGE_WILY] = mWilyAvailable;

        redraw(color);
    }

    private void redraw(boolean[] blackColor) {
        for(int i = 0; i < 6; i++) {
            // fill with color
            if(blackColor[i]) mDrawPaint.setColor(Color.BLACK);
            else mDrawPaint.setColor(Color.argb(255, 242, 187, 58));
            mCanvas.drawRect(locationX[i] + FRAME_OFFSET, locationY[i] + FRAME_OFFSET, locationX[i] + FRAME_OFFSET + SQUARE_SIZE, locationY[i] + FRAME_OFFSET + SQUARE_SIZE, mDrawPaint);

            switch(i) {
                case 0:
                    mCanvas.drawBitmap(mBitmapIceman, locationX[i] + FRAME_OFFSET + 4, locationY[i] + FRAME_OFFSET + 8, mDrawPaint);
                    break;
                case 1:
                    mCanvas.drawBitmap(mBitmapBombman, locationX[i] + FRAME_OFFSET + 4, locationY[i] + FRAME_OFFSET + 8, mDrawPaint);
                    break;
                case 2:
                    mCanvas.drawBitmap(mBitmapFireman, locationX[i] + FRAME_OFFSET + 4, locationY[i] + FRAME_OFFSET + 1, mDrawPaint);
                    break;
                case 3:
                    mCanvas.drawBitmap(mBitmapElecman, locationX[i] + FRAME_OFFSET + 2, locationY[i] + FRAME_OFFSET + 6, mDrawPaint);
                    break;
                case 4:
                    mCanvas.drawBitmap(mBitmapCutman, locationX[i] + FRAME_OFFSET, locationY[i] + FRAME_OFFSET, mDrawPaint);
                    break;
                case 5:
                    mCanvas.drawBitmap(mBitmapGutsman, locationX[i] + FRAME_OFFSET + 1, locationY[i] + FRAME_OFFSET, mDrawPaint);
                    break;
            }
        }

        if(blackColor[STAGE_WILY]) {
            mCanvas.drawBitmap(mBitmapFrameBlue, locationX[STAGE_WILY], locationY[STAGE_WILY], mDrawPaint);
            mDrawPaint.setColor(Color.argb(255, 242, 187, 58));
            mCanvas.drawRect(locationX[STAGE_WILY] + FRAME_OFFSET, locationY[STAGE_WILY] + FRAME_OFFSET, locationX[STAGE_WILY] + FRAME_OFFSET + SQUARE_SIZE, locationY[STAGE_WILY] + FRAME_OFFSET + SQUARE_SIZE, mDrawPaint);
            mCanvas.drawBitmap(mBitmapWily, locationX[STAGE_WILY] + FRAME_OFFSET + 5, locationY[STAGE_WILY] + FRAME_OFFSET + 7, mDrawPaint);
            mDrawPaint.setColor(Color.WHITE);
            mCanvas.drawText("WILY", locationX[STAGE_WILY] + FRAME_SIZE_DIV_2, locationY[STAGE_WILY] + FRAME_SIZE + TEXT_SIZE, mDrawPaint);
        }
    }
}
