package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

public class EnemyRobotHead extends SpriteAnimatedMirrored {
    private final EnemyRobotSpawn mParent;
    private final EnemyRobotLegs mLegs;

    private final EnemyRobotShot mShot;
    private boolean mShotReleased = true;

    private final static int ANIMATION_WALK = 0;
    private final static int ANIMATION_FLY = 1;
    private final static int ANIMATION_PUNCH = 2;

    private final static int STATE_ATTACHED = 0;
    private final static int STATE_DETACHED = 1;
    private final static int STATE_GET_INTO_POSITION = 2;
    private final static int STATE_PUNCH = 3;
    private int mState = STATE_ATTACHED;
    private int mStateTimer = 0;

    private final static float VELOCITY_X = .1f;
    private final static float VELOCITY_Y = .1f;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    EnemyRobotHead(Resources resources, EnemyRobotSpawn parent, EnemyRobotLegs legs) {
        super(8, 0, 16, 14);

        mParent = parent;
        mLegs = legs;
        mShot = new EnemyRobotShot(resources, this);

        mSpriteAnimation.addState(ANIMATION_WALK, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_robot_head_walk, null));
        mSpriteAnimation.addState(ANIMATION_FLY, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_robot_head_fly, null));
        mSpriteAnimation.addState(ANIMATION_PUNCH, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_robot_head_punch, null));

        mPlayerDamage = 16;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    void detach() {
        if(mState == STATE_ATTACHED) {
            mState = STATE_DETACHED;
            mSpriteAnimation.setState(ANIMATION_FLY, true);
        }
    }

    void init() {
        mHurtOrDead = false;

        mState = STATE_ATTACHED;
        mX = mLegs.mX - 4;
        mY = mLegs.mY - 11;
        mXFractional = 0;
        mYFractional = 0;
        mDirection = mLegs.mDirection;
        updateBoundingBox();

        mSpriteAnimation.setState(ANIMATION_WALK, true);
        mFacingLeftAdjustmentX = 32;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts) {

            mHurtOrDead = true;

            // destroy the legs as well if attached
            if(mState == STATE_ATTACHED) mLegs.onDeath(gameEngine);

            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

            gameEngine.removeGameObject(this);
            mParent.releaseHead();

            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseHead();
            return;
        }

        switch(mState) {
            case STATE_ATTACHED:
                // just stick with the legs as they walk
                mX = mLegs.mX - 4;
                mY = mLegs.mY - 13;
                updateBoundingBox();

                // shoot if possible
                mStateTimer += elapsedMillis;
                if(mShotReleased && mStateTimer > 1000) {
                    mStateTimer = 0;
                    mShotReleased = false;
                    if (mDirection == 1)
                        mShot.init(mBoundingBox.right - 8, mBoundingBox.top + 8, mDirection, gameEngine);
                    else mShot.init(mBoundingBox.left + 2, mBoundingBox.top + 8, mDirection, gameEngine);
                    gameEngine.addGameObject(mShot);
                }
                break;
            case STATE_DETACHED:
                // start flying towards player to punch them
                mSpriteAnimation.setState(ANIMATION_FLY, true);
                mState = STATE_GET_INTO_POSITION;
                break;
            case STATE_GET_INTO_POSITION:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;

                final int distanceY = gameEngine.mPlayer.mBoundingBox.centerY() - mBoundingBox.centerY();
                if(distanceY > 32) mVelocityY = VELOCITY_Y;
                else if(distanceY < 16) mVelocityY = -VELOCITY_Y;
                else mVelocityY = 0;

                final int distanceX = Math.abs(gameEngine.mPlayer.mBoundingBox.centerX() - mBoundingBox.centerX());
                if(distanceX > 32) mVelocityX = mDirection *  VELOCITY_X;
                else mVelocityX = 0;

                final double doubleDistanceX = mVelocityX * elapsedMillis + mXFractional;
                mX += (int) doubleDistanceX;
                mXFractional = doubleDistanceX % 1;

                final double doubleDistanceY = mVelocityY * elapsedMillis + mYFractional;
                mY += (int) doubleDistanceY;
                mYFractional = doubleDistanceY % 1;

                updateBoundingBox();

                if(mVelocityX == 0 && mVelocityY == 0) {
                    mState = STATE_PUNCH;
                    mSpriteAnimation.setState(ANIMATION_PUNCH, true);
                    mVelocityX = mDirection * VELOCITY_X * 1.3f;
                    mVelocityY = VELOCITY_Y * 1.3f;
                }
                break;
            case STATE_PUNCH:
                if(mSpriteAnimation.mOneShotFired) {
                    mState = STATE_GET_INTO_POSITION;
                    mSpriteAnimation.setState(ANIMATION_FLY, true);
                }
                else {
                    final double double2DistanceX = mVelocityX * elapsedMillis + mXFractional;
                    mX += (int) double2DistanceX;
                    mXFractional = double2DistanceX % 1;

                    final double double2DistanceY = mVelocityY * elapsedMillis + mYFractional;
                    mY += (int) double2DistanceY;
                    mYFractional = double2DistanceY % 1;

                    updateBoundingBox();
                }
                break;
        }

        mSpriteAnimation.onUpdate(elapsedMillis);
    }

    void releaseShot() {
        mShotReleased = true;
    }
}
