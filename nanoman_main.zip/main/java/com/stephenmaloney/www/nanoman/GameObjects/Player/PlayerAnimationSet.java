package com.stephenmaloney.www.nanoman.GameObjects.Player;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimationDrawable;
import com.stephenmaloney.www.nanoman.R;

public class PlayerAnimationSet {
    private final static int STATE_STAND = 0;
    private final static int STATE_STAND_CARRY = 1;
    private final static int STATE_STAND_TO_WALK = 2;
    private final static int STATE_STAND_SHOOT = 3;
    private final static int STATE_STAND_THROW = 4;
    private final static int STATE_WALK = 5;
    private final static int STATE_WALK_CARRY = 6;
    private final static int STATE_WALK_SHOOT = 7;
    private final static int STATE_LEAN = 8;
    private final static int STATE_JUMP = 9;
    private final static int STATE_JUMP_CARRY = 10;
    private final static int STATE_JUMP_SHOOT = 11;
    private final static int STATE_JUMP_THROW = 12;
    private final static int STATE_CLIMB1 = 13;
    private final static int STATE_CLIMB2 = 14;
    private final static int STATE_CLIMB_TOP = 15;
    private final static int STATE_CLIMB_SHOOT = 16;
    private final static int STATE_CLIMB_THROW = 17;
    private final static int STATE_HURT = 18;
    private final static int STATE_WARP_IN = 19;
    private final static int STATE_WARP_LAND = 20;
    private final static int STATE_WARP_RISE = 21;
    private final static int STATE_FALLEN_DOWN = 22;
    public int mState = STATE_STAND;

    public final static int COLOR_BOMB = 0;
    public final static int COLOR_CUT = 1;
    public final static int COLOR_ELEC = 2;
    public final static int COLOR_FIRE = 3;
    private final static int COLOR_GUTS = 4;
    public final static int COLOR_ICE = 5;
    private final static int COLOR_MAG = 6;
    public final static int COLOR_PSHOT = 7;
    private final static int NUMBER_OF_COLORS = 8;
    private int mColor = 7;

    public boolean mOneShotFired = false;

    private final SpriteAnimationDrawable[] mAnimations = new SpriteAnimationDrawable[NUMBER_OF_COLORS];

    public PlayerAnimationSet(Resources resources) {
        // bomb
        mAnimations[COLOR_BOMB] = new SpriteAnimationDrawable();
        mAnimations[COLOR_BOMB].addState(STATE_STAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_stand, null));
        mAnimations[COLOR_BOMB].addState(STATE_STAND_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_stand_carry, null));
        mAnimations[COLOR_BOMB].addState(STATE_STAND_TO_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_stand_to_walk, null));
        mAnimations[COLOR_BOMB].addState(STATE_STAND_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_stand_shoot, null));
        mAnimations[COLOR_BOMB].addState(STATE_STAND_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_stand_throw, null));
        mAnimations[COLOR_BOMB].addState(STATE_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_walk, null));
        mAnimations[COLOR_BOMB].addState(STATE_WALK_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_walk_carry, null));
        mAnimations[COLOR_BOMB].addState(STATE_WALK_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_walk_shoot, null));
        mAnimations[COLOR_BOMB].addState(STATE_LEAN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_lean, null));
        mAnimations[COLOR_BOMB].addState(STATE_JUMP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_jump, null));
        mAnimations[COLOR_BOMB].addState(STATE_JUMP_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_jump_carry, null));
        mAnimations[COLOR_BOMB].addState(STATE_JUMP_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_jump_shoot, null));
        mAnimations[COLOR_BOMB].addState(STATE_JUMP_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_jump_throw, null));
        mAnimations[COLOR_BOMB].addState(STATE_CLIMB1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_climb1, null));
        mAnimations[COLOR_BOMB].addState(STATE_CLIMB2, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_climb2, null));
        mAnimations[COLOR_BOMB].addState(STATE_CLIMB_TOP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_climb_top, null));
        mAnimations[COLOR_BOMB].addState(STATE_CLIMB_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_climb_shoot, null));
        mAnimations[COLOR_BOMB].addState(STATE_CLIMB_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_climb_throw, null));
        mAnimations[COLOR_BOMB].addState(STATE_HURT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_hurt, null));
        mAnimations[COLOR_BOMB].addState(STATE_WARP_IN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_warp_fall, null));
        mAnimations[COLOR_BOMB].addState(STATE_WARP_LAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_warp_land, null));
        mAnimations[COLOR_BOMB].addState(STATE_WARP_RISE, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_warp_rise, null));
        mAnimations[COLOR_BOMB].addState(STATE_FALLEN_DOWN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_fallen_down, null));

        // cut
        mAnimations[COLOR_CUT] = new SpriteAnimationDrawable();
        mAnimations[COLOR_CUT].addState(STATE_STAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_stand, null));
        mAnimations[COLOR_CUT].addState(STATE_STAND_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_stand_carry, null));
        mAnimations[COLOR_CUT].addState(STATE_STAND_TO_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_stand_to_walk, null));
        mAnimations[COLOR_CUT].addState(STATE_STAND_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_stand_shoot, null));
        mAnimations[COLOR_CUT].addState(STATE_STAND_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_stand_throw, null));
        mAnimations[COLOR_CUT].addState(STATE_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_walk, null));
        mAnimations[COLOR_CUT].addState(STATE_WALK_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_walk_carry, null));
        mAnimations[COLOR_CUT].addState(STATE_WALK_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_walk_shoot, null));
        mAnimations[COLOR_CUT].addState(STATE_LEAN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_lean, null));
        mAnimations[COLOR_CUT].addState(STATE_JUMP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_jump, null));
        mAnimations[COLOR_CUT].addState(STATE_JUMP_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_jump_carry, null));
        mAnimations[COLOR_CUT].addState(STATE_JUMP_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_jump_shoot, null));
        mAnimations[COLOR_CUT].addState(STATE_JUMP_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_jump_throw, null));
        mAnimations[COLOR_CUT].addState(STATE_CLIMB1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_climb1, null));
        mAnimations[COLOR_CUT].addState(STATE_CLIMB2, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_climb2, null));
        mAnimations[COLOR_CUT].addState(STATE_CLIMB_TOP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_climb_top, null));
        mAnimations[COLOR_CUT].addState(STATE_CLIMB_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_climb_shoot, null));
        mAnimations[COLOR_CUT].addState(STATE_CLIMB_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_climb_throw, null));
        mAnimations[COLOR_CUT].addState(STATE_HURT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_hurt, null));
        mAnimations[COLOR_CUT].addState(STATE_WARP_IN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_warp_fall, null));
        mAnimations[COLOR_CUT].addState(STATE_WARP_LAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_warp_land, null));
        mAnimations[COLOR_CUT].addState(STATE_WARP_RISE, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_warp_rise, null));
        mAnimations[COLOR_CUT].addState(STATE_FALLEN_DOWN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_fallen_down, null));

        // elec
        mAnimations[COLOR_ELEC] = new SpriteAnimationDrawable();
        mAnimations[COLOR_ELEC].addState(STATE_STAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_stand, null));
        mAnimations[COLOR_ELEC].addState(STATE_STAND_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_stand_carry, null));
        mAnimations[COLOR_ELEC].addState(STATE_STAND_TO_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_stand_to_walk, null));
        mAnimations[COLOR_ELEC].addState(STATE_STAND_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_stand_shoot, null));
        mAnimations[COLOR_ELEC].addState(STATE_STAND_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_stand_throw, null));
        mAnimations[COLOR_ELEC].addState(STATE_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_walk, null));
        mAnimations[COLOR_ELEC].addState(STATE_WALK_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_walk_carry, null));
        mAnimations[COLOR_ELEC].addState(STATE_WALK_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_walk_shoot, null));
        mAnimations[COLOR_ELEC].addState(STATE_LEAN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_lean, null));
        mAnimations[COLOR_ELEC].addState(STATE_JUMP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_jump, null));
        mAnimations[COLOR_ELEC].addState(STATE_JUMP_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_jump_carry, null));
        mAnimations[COLOR_ELEC].addState(STATE_JUMP_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_jump_shoot, null));
        mAnimations[COLOR_ELEC].addState(STATE_JUMP_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_jump_throw, null));
        mAnimations[COLOR_ELEC].addState(STATE_CLIMB1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_climb1, null));
        mAnimations[COLOR_ELEC].addState(STATE_CLIMB2, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_climb2, null));
        mAnimations[COLOR_ELEC].addState(STATE_CLIMB_TOP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_climb_top, null));
        mAnimations[COLOR_ELEC].addState(STATE_CLIMB_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_climb_shoot, null));
        mAnimations[COLOR_ELEC].addState(STATE_CLIMB_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_climb_throw, null));
        mAnimations[COLOR_ELEC].addState(STATE_HURT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_hurt, null));
        mAnimations[COLOR_ELEC].addState(STATE_WARP_IN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_warp_fall, null));
        mAnimations[COLOR_ELEC].addState(STATE_WARP_LAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_warp_land, null));
        mAnimations[COLOR_ELEC].addState(STATE_WARP_RISE, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_warp_rise, null));
        mAnimations[COLOR_ELEC].addState(STATE_FALLEN_DOWN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_elec_fallen_down, null));

        // fire
        mAnimations[COLOR_FIRE] = new SpriteAnimationDrawable();
        mAnimations[COLOR_FIRE].addState(STATE_STAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_stand, null));
        mAnimations[COLOR_FIRE].addState(STATE_STAND_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_stand_carry, null));
        mAnimations[COLOR_FIRE].addState(STATE_STAND_TO_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_stand_to_walk, null));
        mAnimations[COLOR_FIRE].addState(STATE_STAND_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_stand_shoot, null));
        mAnimations[COLOR_FIRE].addState(STATE_STAND_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_stand_throw, null));
        mAnimations[COLOR_FIRE].addState(STATE_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_walk, null));
        mAnimations[COLOR_FIRE].addState(STATE_WALK_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_walk_carry, null));
        mAnimations[COLOR_FIRE].addState(STATE_WALK_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_walk_shoot, null));
        mAnimations[COLOR_FIRE].addState(STATE_LEAN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_lean, null));
        mAnimations[COLOR_FIRE].addState(STATE_JUMP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_jump, null));
        mAnimations[COLOR_FIRE].addState(STATE_JUMP_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_jump_carry, null));
        mAnimations[COLOR_FIRE].addState(STATE_JUMP_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_jump_shoot, null));
        mAnimations[COLOR_FIRE].addState(STATE_JUMP_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_jump_throw, null));
        mAnimations[COLOR_FIRE].addState(STATE_CLIMB1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_climb1, null));
        mAnimations[COLOR_FIRE].addState(STATE_CLIMB2, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_climb2, null));
        mAnimations[COLOR_FIRE].addState(STATE_CLIMB_TOP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_climb_top, null));
        mAnimations[COLOR_FIRE].addState(STATE_CLIMB_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_climb_shoot, null));
        mAnimations[COLOR_FIRE].addState(STATE_CLIMB_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_climb_throw, null));
        mAnimations[COLOR_FIRE].addState(STATE_HURT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_hurt, null));
        mAnimations[COLOR_FIRE].addState(STATE_WARP_IN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_warp_fall, null));
        mAnimations[COLOR_FIRE].addState(STATE_WARP_LAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_warp_land, null));
        mAnimations[COLOR_FIRE].addState(STATE_WARP_RISE, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_warp_rise, null));
        mAnimations[COLOR_FIRE].addState(STATE_FALLEN_DOWN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_fire_fallen_down, null));

        // guts
        mAnimations[COLOR_GUTS] = new SpriteAnimationDrawable();
        mAnimations[COLOR_GUTS].addState(STATE_STAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_stand, null));
        mAnimations[COLOR_GUTS].addState(STATE_STAND_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_stand_carry, null));
        mAnimations[COLOR_GUTS].addState(STATE_STAND_TO_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_stand_to_walk, null));
        mAnimations[COLOR_GUTS].addState(STATE_STAND_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_stand_shoot, null));
        mAnimations[COLOR_GUTS].addState(STATE_STAND_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_stand_throw, null));
        mAnimations[COLOR_GUTS].addState(STATE_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_walk, null));
        mAnimations[COLOR_GUTS].addState(STATE_WALK_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_walk_carry, null));
        mAnimations[COLOR_GUTS].addState(STATE_WALK_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_walk_shoot, null));
        mAnimations[COLOR_GUTS].addState(STATE_LEAN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_lean, null));
        mAnimations[COLOR_GUTS].addState(STATE_JUMP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_jump, null));
        mAnimations[COLOR_GUTS].addState(STATE_JUMP_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_jump_carry, null));
        mAnimations[COLOR_GUTS].addState(STATE_JUMP_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_jump_shoot, null));
        mAnimations[COLOR_GUTS].addState(STATE_JUMP_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_jump_throw, null));
        mAnimations[COLOR_GUTS].addState(STATE_CLIMB1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_climb1, null));
        mAnimations[COLOR_GUTS].addState(STATE_CLIMB2, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_climb2, null));
        mAnimations[COLOR_GUTS].addState(STATE_CLIMB_TOP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_climb_top, null));
        mAnimations[COLOR_GUTS].addState(STATE_CLIMB_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_climb_shoot, null));
        mAnimations[COLOR_GUTS].addState(STATE_CLIMB_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_cut_climb_throw, null));
        mAnimations[COLOR_GUTS].addState(STATE_HURT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_hurt, null));
        mAnimations[COLOR_GUTS].addState(STATE_WARP_IN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_warp_fall, null));
        mAnimations[COLOR_GUTS].addState(STATE_WARP_LAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_warp_land, null));
        mAnimations[COLOR_GUTS].addState(STATE_WARP_RISE, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_warp_rise, null));
        mAnimations[COLOR_GUTS].addState(STATE_FALLEN_DOWN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_fallen_down, null));

        // ice
        mAnimations[COLOR_ICE] = new SpriteAnimationDrawable();
        mAnimations[COLOR_ICE].addState(STATE_STAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_stand, null));
        mAnimations[COLOR_ICE].addState(STATE_STAND_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_stand_carry, null));
        mAnimations[COLOR_ICE].addState(STATE_STAND_TO_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_stand_to_walk, null));
        mAnimations[COLOR_ICE].addState(STATE_STAND_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_stand_shoot, null));
        mAnimations[COLOR_ICE].addState(STATE_STAND_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_stand_throw, null));
        mAnimations[COLOR_ICE].addState(STATE_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_walk, null));
        mAnimations[COLOR_ICE].addState(STATE_WALK_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_walk_carry, null));
        mAnimations[COLOR_ICE].addState(STATE_WALK_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_walk_shoot, null));
        mAnimations[COLOR_ICE].addState(STATE_LEAN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_lean, null));
        mAnimations[COLOR_ICE].addState(STATE_JUMP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_jump, null));
        mAnimations[COLOR_ICE].addState(STATE_JUMP_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_jump_carry, null));
        mAnimations[COLOR_ICE].addState(STATE_JUMP_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_jump_shoot, null));
        mAnimations[COLOR_ICE].addState(STATE_JUMP_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_jump_throw, null));
        mAnimations[COLOR_ICE].addState(STATE_CLIMB1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_climb1, null));
        mAnimations[COLOR_ICE].addState(STATE_CLIMB2, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_climb2, null));
        mAnimations[COLOR_ICE].addState(STATE_CLIMB_TOP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_climb_top, null));
        mAnimations[COLOR_ICE].addState(STATE_CLIMB_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_climb_shoot, null));
        mAnimations[COLOR_ICE].addState(STATE_CLIMB_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_climb_throw, null));
        mAnimations[COLOR_ICE].addState(STATE_HURT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_hurt, null));
        mAnimations[COLOR_ICE].addState(STATE_WARP_IN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_warp_fall, null));
        mAnimations[COLOR_ICE].addState(STATE_WARP_LAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_warp_land, null));
        mAnimations[COLOR_ICE].addState(STATE_WARP_RISE, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_warp_rise, null));
        mAnimations[COLOR_ICE].addState(STATE_FALLEN_DOWN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_ice_fallen_down, null));

        // pshot
        mAnimations[COLOR_PSHOT] = new SpriteAnimationDrawable();
        mAnimations[COLOR_PSHOT].addState(STATE_STAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_stand, null));
        mAnimations[COLOR_PSHOT].addState(STATE_STAND_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_stand_carry, null));
        mAnimations[COLOR_PSHOT].addState(STATE_STAND_TO_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_stand_to_walk, null));
        mAnimations[COLOR_PSHOT].addState(STATE_STAND_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_stand_shoot, null));
        mAnimations[COLOR_PSHOT].addState(STATE_STAND_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_stand_throw, null));
        mAnimations[COLOR_PSHOT].addState(STATE_WALK, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_walk, null));
        mAnimations[COLOR_PSHOT].addState(STATE_WALK_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_walk_carry, null));
        mAnimations[COLOR_PSHOT].addState(STATE_WALK_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_walk_shoot, null));
        mAnimations[COLOR_PSHOT].addState(STATE_LEAN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_lean, null));
        mAnimations[COLOR_PSHOT].addState(STATE_JUMP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_jump, null));
        mAnimations[COLOR_PSHOT].addState(STATE_JUMP_CARRY, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_guts_jump_carry, null));
        mAnimations[COLOR_PSHOT].addState(STATE_JUMP_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_jump_shoot, null));
        mAnimations[COLOR_PSHOT].addState(STATE_JUMP_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_jump_throw, null));
        mAnimations[COLOR_PSHOT].addState(STATE_CLIMB1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_climb1, null));
        mAnimations[COLOR_PSHOT].addState(STATE_CLIMB2, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_climb2, null));
        mAnimations[COLOR_PSHOT].addState(STATE_CLIMB_TOP, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_climb_top, null));
        mAnimations[COLOR_PSHOT].addState(STATE_CLIMB_SHOOT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_climb_shoot, null));
        mAnimations[COLOR_PSHOT].addState(STATE_CLIMB_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_bomb_climb_throw, null));
        mAnimations[COLOR_PSHOT].addState(STATE_HURT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_hurt, null));
        mAnimations[COLOR_PSHOT].addState(STATE_WARP_IN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_warp_fall, null));
        mAnimations[COLOR_PSHOT].addState(STATE_WARP_LAND, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_warp_land, null));
        mAnimations[COLOR_PSHOT].addState(STATE_WARP_RISE, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_warp_rise, null));
        mAnimations[COLOR_PSHOT].addState(STATE_FALLEN_DOWN, (AnimationDrawable)resources.getDrawable(R.drawable.animation_player_pshot_fallen_down, null));

        // mag uses same as pshot color
        mAnimations[COLOR_MAG] = mAnimations[COLOR_PSHOT];
    }

    public Bitmap getBitmap() {
        return mAnimations[mColor].getBitmap();
    }

    public void onUpdate(long elapsedMillis) {
        mAnimations[mColor].onUpdate(elapsedMillis);
        if(mAnimations[mColor].mOneShotFired) mOneShotFired = true;
    }

    public void setColor(int color) {
        mAnimations[color].setState(mAnimations[mColor].mState, true);
        mColor = color;
    }

    public void setState(int state, boolean reset) {
        mState = state;
        mOneShotFired = false;
        mAnimations[mColor].setState(state, reset);
    }
}
