package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.R;

class EnemyHelmetShot extends EnemyShot {
    private final static float VELOCITY = .08f;

    private final EnemyHelmet mParent;

    private final int mStartX;
    private final int mStartY;

    EnemyHelmetShot(Resources resources, int direction, int x, int y, int index, EnemyHelmet parent) {
        super(resources, R.drawable.gameobject_enemy_shot_orange);

        mParent = parent;
        mDirection = direction;
        mStartX = x;
        mStartY = y;

        switch(index) {
            case 0:
                mVelocityX = VELOCITY * (float)Math.cos(.78540) * mDirection;
                mVelocityY = VELOCITY * (float)Math.sin(.78540);
                break;
            case 1:
                mVelocityX = VELOCITY * mDirection;
                mVelocityY = 0;
                break;
            default:
                // 2
                mVelocityX = VELOCITY * (float)Math.cos(-.78540) * mDirection;
                mVelocityY = VELOCITY * (float)Math.sin(-.78540);
                break;
        }
    }

    void init(GameEngine gameEngine) {
        mX = mStartX;
        mY = mStartY;
        updateBoundingBox();

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_SHOOT);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseShot(this);
            return;
        }

        super.onUpdate(elapsedMillis, gameEngine);
    }
}
