package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricity;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFire;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponMagnet;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;

import java.util.ArrayList;
import java.util.List;

public abstract class SpriteAnimatedMirroredWeapons extends SpriteAnimatedMirrored {
    private final List<Dust> mDust = new ArrayList<>();
    private final static int DUST_LIMIT = 2;

    public SpriteAnimatedMirroredWeapons(Resources resources, int boundingBoxOffsetX, int boundingBoxOffSetY, int boundingBoxSizeX, int boundingBoxSizeY) {
        super(boundingBoxOffsetX, boundingBoxOffSetY, boundingBoxSizeX, boundingBoxSizeY);

        // set up dust when sprite is damaged
        for(int i = 0; i < DUST_LIMIT; i++) mDust.add(new Dust(resources, this));
    }

    protected void dustAdd(GameEngine gameEngine) {
        if(mDust.size() == 2) {
            final Dust dust1 = mDust.remove(0);
            final Dust dust2 = mDust.remove(0);
            dust1.init(mBoundingBox.left - 8, mBoundingBox.top - 2);
            dust2.init(mBoundingBox.right + 2, mBoundingBox.top - 2);
            gameEngine.addGameObject(dust1);
            gameEngine.addGameObject(dust2);
        }
    }

    void dustRelease(Dust dust) {
        mDust.add(dust);
    }

    public void weaponBombRelease(WeaponBomb weaponBomb) {
    }

    public void weaponCutterRelease(WeaponCutter weaponCutter) {
    }

    public void weaponElectricityRelease(WeaponElectricity weaponElectricity) {
    }

    public void weaponFireRelease(WeaponFire weaponFire) {
    }

    public void weaponGutsRelease(WeaponGuts weapon) {
    }

    public void weaponIceRelease(WeaponIce weaponIce) {
    }

    public void weaponMagnetRelease(WeaponMagnet weaponMagnet) {
    }

    public void weaponPShotRelease(WeaponPShot weaponPShot) {
    }
}
