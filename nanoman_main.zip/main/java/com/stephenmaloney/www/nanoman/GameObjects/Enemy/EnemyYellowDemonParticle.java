package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimated;
import com.stephenmaloney.www.nanoman.R;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public class EnemyYellowDemonParticle extends SpriteAnimated {
    private final static float VELOCITY_X = .18f;

    private final static int ANIMATION_SPIN = 0;
    private final static int ANIMATION_GROW = 1;

    private final static int STATE_IDLE = 0;
    private final static int STATE_WAIT_FOR_COMBINE_LEFT = 1;
    private final static int STATE_WAIT_FOR_GROW = 2;
    private final static int STATE_WAIT_FOR_COMBINE_RIGHT = 3;
    private int mState = STATE_IDLE;

    private final Rect mRectLeft;
    private final Rect mRectRight;

    private Bitmap[] mBitmapDemon = new Bitmap[2];
    private int mFrame = 0;

    EnemyYellowDemonParticle(Resources resources, Rect rectLeft, Rect rectRight, Bitmap bitmapDemon, Rect rectSegmentLeft, Rect rectSegmentRight) {
        super(0, 0, 16, 12);

        // set up animations
        mSpriteAnimation.addState(ANIMATION_SPIN, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_yellow_demon_particle_spin, null));
        mSpriteAnimation.addState(ANIMATION_GROW, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_yellow_demon_particle_grow, null));

        mPlayerDamage = 20;

        // save destination segments
        mRectLeft = rectLeft;
        mRectRight = rectRight;

        // create bitmaps for when the particle has combined
        mBitmapDemon[0] = Bitmap.createBitmap(EnemyYellowDemon.SEGMENT_WIDTH, EnemyYellowDemon.SEGMENT_HEIGHT, Bitmap.Config.ARGB_8888);
        mBitmapDemon[1] = Bitmap.createBitmap(EnemyYellowDemon.SEGMENT_WIDTH, EnemyYellowDemon.SEGMENT_HEIGHT, Bitmap.Config.ARGB_8888);

        final Canvas canvas0 = new Canvas(mBitmapDemon[0]);
        final Rect rect = new Rect(0, 0, EnemyYellowDemon.SEGMENT_WIDTH, EnemyYellowDemon.SEGMENT_HEIGHT);
        canvas0.drawBitmap(bitmapDemon, rectSegmentLeft, rect, GameView.mPaint);

        final Canvas canvas1 = new Canvas(mBitmapDemon[1]);
        canvas1.drawBitmap(bitmapDemon, rectSegmentRight, rect, GameView.mPaint);

        mMatrix.reset();
        mMatrix.preScale(-1, 1);
        mBitmapDemon[1] = Bitmap.createBitmap(mBitmapDemon[1], 0, 0, mBitmapDemon[1].getWidth(), mBitmapDemon[1].getHeight(), mMatrix, false);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && otherObject instanceof Player;
    }

    void flyInFromRight() {
        mX = GameView.mViewPort.right - 1;
        mY = mRectLeft.centerY() - 6;
        updateBoundingBox();

        mVelocityX = -VELOCITY_X;
        mState = STATE_WAIT_FOR_COMBINE_LEFT;
        mSpriteAnimation.setState(ANIMATION_SPIN, true);
    }

    void flyToRightFromLeft() {
        mVelocityX = VELOCITY_X;
        mY = mRectLeft.centerY() - 6;
        mState = STATE_WAIT_FOR_COMBINE_RIGHT;
        mSpriteAnimation.setState(ANIMATION_SPIN, true);
    }

    void flyToLeftFromRight() {
        mVelocityX = -VELOCITY_X;
        mY = mRectLeft.centerY() - 6;
        mState = STATE_WAIT_FOR_COMBINE_LEFT;
        mSpriteAnimation.setState(ANIMATION_SPIN, true);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        mMatrix.reset();
        mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);

        if(mState != STATE_IDLE) canvas.drawBitmap(mSpriteAnimation.getBitmap(), mMatrix, GameView.mPaint);
        else canvas.drawBitmap(mBitmapDemon[mFrame], mMatrix, GameView.mPaint);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        switch(mState) {
            case STATE_IDLE:
                // wait to do something
                break;
            case STATE_WAIT_FOR_COMBINE_LEFT:
                final double dX = mVelocityX * elapsedMillis + mXFractional;
                mX += (int) dX;
                mXFractional = dX % 1;
                updateBoundingBox();

                if(mBoundingBox.centerX() <= mRectLeft.centerX()) {
                    mX = mRectLeft.centerX() - 8;
                    updateBoundingBox();

                    mSpriteAnimation.setState(ANIMATION_GROW, true);
                    mState = STATE_WAIT_FOR_GROW;
                    mFrame = 0;
                }
                break;
            case STATE_WAIT_FOR_COMBINE_RIGHT:
                final double dXRight = mVelocityX * elapsedMillis + mXFractional;
                mX += (int) dXRight;
                mXFractional = dXRight % 1;
                updateBoundingBox();

                if(mBoundingBox.centerX() >= mRectRight.centerX()) {
                    mX = mRectRight.centerX() - 8;
                    updateBoundingBox();

                    mSpriteAnimation.setState(ANIMATION_GROW, true);
                    mState = STATE_WAIT_FOR_GROW;

                    mFrame = 1;
                }
                break;
            case STATE_WAIT_FOR_GROW:
                if(mSpriteAnimation.mOneShotFired) {
                    mState = STATE_IDLE;
                    if(mFrame == 1) mX = mRectRight.left;
                    else mX = mRectLeft.left;
                    mY = mRectLeft.top;
                    updateBoundingBox();
                    break;
                }
                break;
        }

        mSpriteAnimation.onUpdate(elapsedMillis);
    }
}
