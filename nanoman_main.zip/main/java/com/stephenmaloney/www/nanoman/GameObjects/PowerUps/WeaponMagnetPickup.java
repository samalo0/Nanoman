package com.stephenmaloney.www.nanoman.GameObjects.PowerUps;

import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimated;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteStatic;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class WeaponMagnetPickup extends SpriteStatic {
    public final static String TYPE = "WeaponMagnet";

    public WeaponMagnetPickup(Resources resources, HashMap<String, String> properties) {
        super(resources, R.drawable.gameobject_weapon_magnet_pickup, 0, 0, 16, 12);

        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) + 4;
        mX = x;
        mY = y;
        updateBoundingBox();
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {}

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
    }
}
