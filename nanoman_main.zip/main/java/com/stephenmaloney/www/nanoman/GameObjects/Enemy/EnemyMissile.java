package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.BoundingBox;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

public class EnemyMissile extends SpriteFrameAnimation {
    private final static float VELOCITY_X = .08f;

    private final EnemyMissileSpawn mParent;
    private final BoundingBox[] mBoundingBoxes = new BoundingBox[9];

    private float mAngle = 0;
    private int mOriginalY;

    private boolean mExploding = false;
    private boolean mStunned = false;
    private int mStateTimer = 0;

    EnemyMissile(Resources resources, int id, int direction, EnemyMissileSpawn parent) {
        super(0, 0, 16, 16, 9);

        mParent = parent;

        mDirection = direction;
        if(direction == 1) mFrames[0] = BitmapFactory.decodeResource(resources, id);
        else {
            final Bitmap flipper = BitmapFactory.decodeResource(resources, id);
            final Matrix matrix = new Matrix();
            matrix.preScale(-1, 1);
            mFrames[0] = Bitmap.createBitmap(flipper, 0, 0, flipper.getWidth(), flipper.getHeight(), matrix, false);
        }

        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion1);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion2);
        mFrames[3] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion3);
        mFrames[4] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion4);
        mFrames[5] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion5);
        mFrames[6] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion6);
        mFrames[7] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion7);
        mFrames[8] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion8);

        // create bounding boxes for each animation frame
        for(int frame = 0; frame < 9; frame++) mBoundingBoxes[frame] = new BoundingBox(0, 0, mFrames[frame].getWidth(), mFrames[frame].getHeight());

        mVelocityX = VELOCITY_X * mDirection;

        mPlayerDamage = 26;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox)
                && !mExploding
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    private void incrementFrame() {
        mX = mBoundingBox.centerX() - mBoundingBoxes[mFrame + 1].mSizeX / 2;
        mY = mBoundingBox.centerY() - mBoundingBoxes[mFrame + 1].mSizeY / 2;

        mBoundingBox.set(mBoundingBoxes[mFrame + 1].mRect);
        updateBoundingBox();

        mFrame++;
    }

    void init(int x, int y) {
        mX = x;
        mY = y;
        mXFractional = 0;
        mYFractional = 0;
        mOriginalY = y;
        mAngle = (float)Math.PI;

        mExploding = false;
        mFrame = 0;
        mBoundingBox.set(mBoundingBoxes[0].mRect);
        updateBoundingBox();
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mExploding) return;

        if(otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts) {

            // explode!
            mExploding = true;
            incrementFrame();
            mStateTimer = 0;
            gameEngine.soundPlay(GameEngine.GameSound.EXPLOSION);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());
        }
        else if(otherObject instanceof WeaponIce) {
            mStunned = true;
            mStateTimer = 0;
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if((mDirection == 1 && mBoundingBox.right > GameView.mViewPort.right) || (mDirection == -1 && mBoundingBox.left < GameView.mViewPort.left)) {
            gameEngine.removeGameObject(this);
            mParent.releaseMissile();
            return;
        }

        if(mExploding) {
            mStateTimer += elapsedMillis;
            if(mStateTimer >= 50) {
                mStateTimer = 0;
                if(mFrame == 8) {
                    gameEngine.removeGameObject(this);
                    mParent.releaseMissile();
                }
                else incrementFrame();
            }
        }
        else if(mStunned) {
            mStateTimer += elapsedMillis;
            if(mStateTimer >= 2000) {
                mStateTimer = 0;
                mStunned = false;
            }
        }
        else {
            final double distanceX = mVelocityX * elapsedMillis + mXFractional;
            mX += (int) distanceX;
            mXFractional = distanceX % 1;

            mAngle += elapsedMillis / 275f;

            final double positionY = mOriginalY + mYFractional + 50 * Math.sin(mAngle);
            mY = (int) positionY;
            mYFractional = positionY % 1;
            updateBoundingBox();
        }
    }
}
