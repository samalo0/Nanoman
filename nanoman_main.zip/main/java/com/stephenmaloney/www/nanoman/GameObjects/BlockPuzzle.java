package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class BlockPuzzle extends SpriteAnimated {
    public final static String TYPE = "BlockPuzzle";
    private final static int BOUNDING_BOX_SIZE_X = 16;
    private final static int BOUNDING_BOX_SIZE_Y = 16;

    private final int mTileX;
    private final int mTileY;

    private final int mStartDelay;
    private final int mOnTimeMillis;
    private final int mOffTimeMillis;

    private boolean mStartDelayOn;
    private boolean mOn;
    private int mTimer;
    private int mOriginalTile;
    private int mSolidTile;

    public BlockPuzzle(Resources resources, HashMap<String, String> properties) {
        super(0, 0, 0, 0);

        // get starting x, y position
        mTileX = Integer.parseInt(properties.get("PositionX"));
        mTileY = Integer.parseInt(properties.get("PositionY"));
        mX = mTileX << Tile.SIZE_POW_2;
        mY = mTileY << Tile.SIZE_POW_2;

        mBoundingBox.set(mX, mY, mX + BOUNDING_BOX_SIZE_X, mY + BOUNDING_BOX_SIZE_Y);

        final String color = properties.get("Color");
        if(color != null && color.equals("Blue")) mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_block_puzzle_blue, null));
        else mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_block_puzzle_orange, null));

        mOnTimeMillis = Integer.parseInt(properties.get("OnTime"));
        mOffTimeMillis = Integer.parseInt(properties.get("OffTime"));
        mStartDelay = Integer.parseInt(properties.get("StartDelay"));
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) { return false; }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {}

    @Override
    public void onDraw(Canvas canvas) {
        if(mOn) super.onDraw(canvas);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(mStartDelayOn) {
            mTimer += elapsedMillis;
            if(mTimer >= mStartDelay) {
                mTimer = 0;
                mStartDelayOn = false;
                mOn = true;
                mSpriteAnimation.setState(0, true);
                gameEngine.setTile(mTileX, mTileY, mSolidTile);
            }
            else return;
        }

        if(mOn) {
            mSpriteAnimation.onUpdate(elapsedMillis);
            mTimer += elapsedMillis;
            if(mTimer >= mOnTimeMillis) {
                mOn = false;
                mTimer = 0;
                gameEngine.setTile(mTileX, mTileY, mOriginalTile);
            }
        }
        else {
            mTimer += elapsedMillis;
            if(mTimer >= mOffTimeMillis) {
                mOn = true;
                mTimer = 0;
                mSpriteAnimation.setState(0, true);
                gameEngine.setTile(mTileX, mTileY, mSolidTile);

                if(GameEngine.isObjectVisible(mBoundingBox)) gameEngine.soundPlay(GameEngine.GameSound.BLOCK_PUZZLE);
            }
        }
    }

    @Override
    public void startGame(GameEngine gameEngine) {
        mStartDelayOn = true;
        mOn = false;
        mTimer = 0;
        mSpriteAnimation.setState(0, true);

        mOriginalTile = gameEngine.getTile(mTileX, mTileY);
        mSolidTile = gameEngine.getTileSolid();
    }
}

