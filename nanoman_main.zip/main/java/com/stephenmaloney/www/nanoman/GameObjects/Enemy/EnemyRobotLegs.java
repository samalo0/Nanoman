package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

public class EnemyRobotLegs extends SpriteAnimatedMirrored {
    private final static float VELOCITY_X = .06f;

    private final EnemyRobotSpawn mParent;

    private final static int ANIMATION_WALK = 0;
    private final static int ANIMATION_EXPLODE = 1;

    private final static int STATE_ATTACHED = 0;
    private final static int STATE_DETACHED = 1;
    private int mState = STATE_ATTACHED;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    EnemyRobotLegs(Resources resources, EnemyRobotSpawn parent) {
        super(7, 1, 11, 17);

        mParent = parent;

        mSpriteAnimation.addState(ANIMATION_WALK, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_robot_legs_walk, null));
        mSpriteAnimation.addState(ANIMATION_EXPLODE, (AnimationDrawable) resources.getDrawable(R.drawable.animation_explosion, null));

        mPlayerDamage = 16;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    void init(int x, int y, int direction) {
        mHurtOrDead = false;

        mX = x - 7;
        mY = y - 2;
        mXFractional = 0;
        mYFractional = 0;
        mDirection = direction;
        updateBoundingBox();

        mVelocityX = mDirection * VELOCITY_X;

        mState = STATE_ATTACHED;
        mSpriteAnimation.setState(ANIMATION_WALK, true);
        mFacingLeftAdjustmentX = 25;

        mOnGround = true;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts) {

            onDeath(gameEngine);
        }
    }

    public void onDeath(GameEngine gameEngine) {
        mHurtOrDead = true;

        mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
        gameEngine.addGameObject(mExplosion);

        // spawn object?
        gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

        // if the head is attached still, let it fly free
        mParent.detachHead();

        gameEngine.removeGameObject(this);
        mParent.releaseLegs();

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            GameView.mViewPort.left += 0;
            gameEngine.removeGameObject(this);
            mParent.releaseLegs();
            mParent.detachHead();
            return;
        }

        switch(mState) {
            case STATE_ATTACHED:
                if(!mOnGround) {
                    // detach from head
                    mState = STATE_DETACHED;
                    mParent.detachHead();
                }
                break;
            case STATE_DETACHED:
                // just keep walking
                break;
        }

        gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        if(mVelocityY > GameEngine.TERMINAL_VELOCITY) mVelocityY = GameEngine.TERMINAL_VELOCITY;
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

        mSpriteAnimation.onUpdate(elapsedMillis);
    }
}
