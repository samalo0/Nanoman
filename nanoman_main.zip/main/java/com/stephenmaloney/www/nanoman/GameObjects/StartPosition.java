package com.stephenmaloney.www.nanoman.GameObjects;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

import java.util.HashMap;

public class StartPosition extends GameObject {
    public final static String TYPE = "StartPosition";

    final int mAbsolutePositionX;
    final int mAbsolutePositionY;
    final int mDirection;

    public StartPosition(HashMap<String, String> properties) {
        // get starting x, y position
        mAbsolutePositionX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mAbsolutePositionY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) - 8;
        mDirection = Integer.parseInt(properties.get("Direction"));
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {}
}
