package com.stephenmaloney.www.nanoman.GameObjects;

public abstract class Sprite extends CollisionGameObject {
    // additional positional
    protected boolean mOnGround = false;
    protected boolean mJustLanded = false;

    // movement
    public float mVelocityX = 0;
    public float mVelocityY = 0;

    public Sprite(int boundingBoxOffsetX, int boundingBoxOffsetY, int boundingBoxSizeX, int boundingBoxSizeY) {
        super(boundingBoxOffsetX, boundingBoxOffsetY, boundingBoxSizeX, boundingBoxSizeY);
    }
}
