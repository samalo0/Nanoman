package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.R;

public class WeaponGutsFragment extends SpriteFrameAnimation {
    public final SpriteAnimatedMirroredWeapons mParent;
    private final WeaponGuts mWeaponGutsParent;
    private final int mIndex;

    public WeaponGutsFragment(Resources resources, int index, WeaponGuts gutsParent, SpriteAnimatedMirroredWeapons parent) {
        super(0, 0, 16, 16, 2);

        mWeaponGutsParent = gutsParent;
        mParent = parent;
        mIndex = index;

        mPlayerDamage = 24;

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.weapon_guts_break_elec);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.weapon_guts_break_guts);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject != mParent);
    }

    void init(int x, int y, int direction, float velocityX, float velocityY, int block_type) {
        mXFractional = 0;
        mYFractional = 0;
        mX = x;
        mY = y;
        mDirection = direction;
        mVelocityX = velocityX;
        mVelocityY = velocityY;
        updateBoundingBox();

        switch(block_type) {
            case WeaponGuts.BLOCK_TYPE_CUT:
            case WeaponGuts.BLOCK_TYPE_ELEC:
                mFrame = 0;
                break;
            case WeaponGuts.BLOCK_TYPE_GUT:
                mFrame = 1;
                break;
        }
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mWeaponGutsParent.releaseFragment(mIndex);
            return;
        }

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        if(mVelocityY > GameEngine.TERMINAL_VELOCITY) mVelocityY = GameEngine.TERMINAL_VELOCITY;

        final double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY= mVelocityY * elapsedMillis + mYFractional;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;

        updateBoundingBox();
    }
}
