package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

class EnemyFootHolderShot extends EnemyShot {
    private final EnemyFootHolder mParent;

    private final int mIndex;

    EnemyFootHolderShot(Resources resources, int resource_id, int index, EnemyFootHolder parent) {
        super(resources, resource_id);

        mParent = parent;
        mIndex = index;
        mDirection = (index == 0) ? 1 : -1;
        mVelocityX = .1f * mDirection;
    }

    @Override
    void init(int x, int y, GameEngine gameEngine) {
        mXFractional = 0;
        mYFractional = 0;

        if(mIndex == 0) {
            mX = x + 24;
            mY = y + 9;
        }
        else {
            mX = x - 6;
            mY = y + 9;
        }
        updateBoundingBox();

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_SHOOT);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseShot(this);
            return;
        }

        super.onUpdate(elapsedMillis, gameEngine);
    }
}
