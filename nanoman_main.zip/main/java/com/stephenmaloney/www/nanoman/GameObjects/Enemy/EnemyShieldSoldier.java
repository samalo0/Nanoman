package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimationMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class EnemyShieldSoldier extends SpriteFrameAnimationMirrored {
    public final static String TYPE = "EnemyShieldSoldier";

    private final static float JUMP_VELOCITY = -.32f;
    private final static float VELOCITY_X = .07f;

    private final static int STATE_REDIRECT = 0;
    private final static int STATE_DEFENSE = 1;
    private final static int STATE_START_JUMP_BACK = 2;
    private final static int STATE_START_JUMP_UP = 3;
    private final static int STATE_WAIT_TO_LAND = 4;
    private final static int STATE_START_SHOOT = 5;
    private final static int STATE_SHOOT = 6;
    private final static int STATE_STOP_SHOOT = 7;
    private final static int STATE_STUNNED = 8;
    private int mState = STATE_REDIRECT;
    private int mStateTimer = 0;

    private int mOldState;
    private int mStunnedTimer;

    private final EnemyShieldSoldierShot mShot;
    private boolean mShotReleased = true;

    private int mHealth = 10;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    public EnemyShieldSoldier(Resources resources, HashMap<String, String> properties) {
        super(11, 0, 17, 24, 4, 39);

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) - 8;
        updateBoundingBox();

        mDirection = properties.get("Direction").equals("1") ? 1 : -1;

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_shield_soldier_stand);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_shield_soldier_jump);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_shield_soldier_shoot1);
        mFrames[3] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_shield_soldier_shoot2);

        mShot = new EnemyShieldSoldierShot(resources, R.drawable.gameobject_enemy_shot_green, mDirection, this);

        mPlayerDamage = 16;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(mState == STATE_DEFENSE) {
            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DINK);
            return;
        }

        if(otherObject instanceof WeaponPShot) {
            mHealth--;
            if(mHealth == 0) onDeath(gameEngine);
            else gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
        else if(otherObject instanceof WeaponIce) {
            if(mState != STATE_STUNNED) mOldState = mState;
            mState = STATE_STUNNED;
            mStunnedTimer = 0;
        }
        else if(otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts) {
            onDeath(gameEngine);
        }
    }

    private void onDeath(GameEngine gameEngine) {
        mHurtOrDead = true;

        mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
        gameEngine.addGameObject(mExplosion);

        // spawn object?
        gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

        gameEngine.removeGameObject(this);

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        switch(mState) {
            case STATE_REDIRECT:
                if((mDirection == 1 && gameEngine.mPlayer.mBoundingBox.centerX() < mBoundingBox.centerX()) || (mDirection == -1 && gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX())) {
                    mState = STATE_START_JUMP_BACK;
                    mStateTimer = 0;
                }
                else if(gameEngine.mPlayer.mBoundingBox.centerY() < mBoundingBox.centerY()) mState = STATE_START_JUMP_UP;
                else {
                    mState = STATE_DEFENSE;
                    mStateTimer = (int)(Math.random() * 3000);
                }
                break;
            case STATE_DEFENSE:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    mState = STATE_START_SHOOT;
                    mFrame = 2;
                }
                break;
            case STATE_START_JUMP_BACK:
                mVelocityX = VELOCITY_X * -1 * mDirection;
                mVelocityY = JUMP_VELOCITY;
                mState = STATE_WAIT_TO_LAND;
                mFrame = 1;
                break;
            case STATE_START_JUMP_UP:
                mVelocityX = 0;
                mVelocityY = JUMP_VELOCITY;
                mState = STATE_WAIT_TO_LAND;
                mFrame = 1;
                break;
            case STATE_WAIT_TO_LAND:
                gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

                mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
                gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);
                updateBoundingBox();

                if(mOnGround) {
                    mState = STATE_REDIRECT;
                    mStateTimer = 0;
                    mFrame = 0;
                }
                break;
            case STATE_START_SHOOT:
                mStateTimer += elapsedMillis;
                if(mStateTimer > 150) {
                    mStateTimer = 0;
                    mState = STATE_SHOOT;
                    mFrame = 3;
                }
                break;
            case STATE_SHOOT:
                if(mShotReleased) {
                    mShotReleased = false;
                    mShot.init(mX, mY, gameEngine);
                    gameEngine.addGameObject(mShot);
                }

                mStateTimer += elapsedMillis;
                if(mStateTimer > 150) {
                    mStateTimer = 0;
                    mState = STATE_STOP_SHOOT;
                    mFrame = 2;
                }
                break;
            case STATE_STOP_SHOOT:
                mStateTimer += elapsedMillis;
                if(mStateTimer > 150) {
                    mStateTimer = 0;
                    mState = STATE_REDIRECT;
                    mFrame = 0;
                }
                break;
            case STATE_STUNNED:
                mStunnedTimer += elapsedMillis;
                if(mStunnedTimer >= 2000) {
                    mStunnedTimer = 0;
                    mState = mOldState;
                }
                else if(!mOnGround) {
                    gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

                    mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
                    gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);
                    updateBoundingBox();
                }
                break;
        }
    }

    void releaseShot() {
        mShotReleased = true;
    }
}
