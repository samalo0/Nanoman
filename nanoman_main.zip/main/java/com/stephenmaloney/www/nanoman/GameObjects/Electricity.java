package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class Electricity extends SpriteAnimatedMirrored {
    public final static String TYPE = "Electricity";

    private final static int BOUNDING_BOX_SIZE_X = 64;
    private final static int BOUNDING_BOX_SIZE_Y = 13;
    private final static int BOUNDING_BOX_OFFSET_X = 0;
    private final static int BOUNDING_BOX_OFFSET_Y = 0;
    private final static int POSITION_OFFSET_X = 48;
    private final static int POSITION_OFFSET_Y = 1;
    private final static int FACING_LEFT_ADJUSTMENT_X = 64;

    private final int mOnTime;
    private final int mOffTime;

    public boolean mOn = false;
    private int onTimer = 0;

    public Electricity(Resources resources, HashMap<String, String> properties) {
        super(BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        mFacingLeftAdjustmentX = FACING_LEFT_ADJUSTMENT_X;

        mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(R.drawable.animation_electricity, null));

        // get starting x, y position
        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) + POSITION_OFFSET_Y;
        mDirection = Integer.parseInt(properties.get("Direction"));
        if(mDirection == -1) mX -= POSITION_OFFSET_X;
        updateBoundingBox();

        mOnTime = Integer.parseInt(properties.get("OnTime"));
        mOffTime = Integer.parseInt(properties.get("OffTime"));
        mPlayerDamage = Integer.parseInt(properties.get("Damage"));
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mOn) super.onDraw(canvas);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        if(mOn) {
            onTimer += elapsedMillis;
            if(onTimer > mOnTime) {
                mOn = false;
                onTimer = 0;
            }
            else {
                // on and not switching off
                mSpriteAnimation.onUpdate(elapsedMillis);
            }
        }
        else {
            onTimer += elapsedMillis;
            if(onTimer > mOffTime) {
                mOn = true;
                onTimer = 0;
                gameEngine.soundPlay(GameEngine.GameSound.WEAPON_MAGNET);
            }
        }
    }
}
