package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimated;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteStatic;
import com.stephenmaloney.www.nanoman.R;

public class EnemyBomber extends SpriteStatic {
    private final static float VELOCITY_Y = -.7f;

    private final EnemyBomberSpawn mParent;

    private final Explosion mExplosion;

    public EnemyBomber(Resources resources, int resource_id, int x, EnemyBomberSpawn parent) {
        super(resources, resource_id, 0, 0, 16, 12);

        mParent = parent;

        mX = x;
        mPlayerDamage = 20;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    void init() {
        mY = GameView.mViewPort.bottom - 1;
        mVelocityY = VELOCITY_Y;
        updateBoundingBox();
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        final double distance = mVelocityY * elapsedMillis + mYFractional;
        mY += (int)distance;
        mYFractional = distance % 1;
        updateBoundingBox();

        if(mVelocityY > .1) {
            mParent.triggerShots(mY);

            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            gameEngine.removeGameObject(this);
            mParent.releaseEnemyBomber();

            gameEngine.soundPlay(GameEngine.GameSound.EXPLOSION);
        }
    }
}
