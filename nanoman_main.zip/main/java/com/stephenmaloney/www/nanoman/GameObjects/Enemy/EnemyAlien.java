package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.ElectricityMini;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimationMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.List;

public class EnemyAlien extends SpriteFrameAnimationMirrored {
    private final static int BOUNDING_BOX_SIZE_LAUNCH_Y = 19;
    private final static int BOUNDING_BOX_SIZE_OPENING_Y = 24;
    private final static int BOUNDING_BOX_SIZE_OPENED_Y = 42;

    private final static float FLY_VELOCITY = .05f;

    private final static int STATE_LAUNCH = 0;
    private final static int STATE_OPEN1 = 1;
    private final static int STATE_OPEN2 = 2;
    private final static int STATE_SHOOT = 3;
    private final static int STATE_CLOSE1 = 4;
    private final static int STATE_CLOSE2 = 5;
    private final static int STATE_RETREAT = 6;
    private int mState;

    private final static int OPEN1_DISTANCE = 64;
    private final static int OPEN2_DISTANCE = 32;
    private final static int SHOOT_DISTANCE = 10;
    private final static int CLOSE1_DISTANCE = 16;
    private final static int CLOSE2_DISTANCE = 32;

    private final EnemyAlienSpawn mParent;

    private List<ElectricityMini> mElectricityMini = new ArrayList<>();
    private final static int ELECTRICITY_LIMIT = 2;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    EnemyAlien(Resources resources, EnemyAlienSpawn enemyAlienSpawner) {
        super(0, 0, 16, BOUNDING_BOX_SIZE_LAUNCH_Y, 3, 16);

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_alien1);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_alien2);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_alien3);

        mParent = enemyAlienSpawner;

        for(int i = 0; i < ELECTRICITY_LIMIT; i++) mElectricityMini.add(new ElectricityMini(resources, this));

        mPlayerDamage = 16;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    public void electricityMiniRelease(ElectricityMini em) {
        mElectricityMini.add(em);
    }

    private ElectricityMini electricityMiniGet() {
        if(mElectricityMini.isEmpty()) return null;
        return mElectricityMini.remove(0);
    }

    void init(int x, int y) {
        mState = STATE_LAUNCH;
        mFrame = 0;
        mHurtOrDead = false;

        mX = x;
        mXFractional = 0;
        mYFractional = 0;

        if(y > GameView.mViewPort.centerY()) {
            mY = GameView.mViewPort.bottom - 1;
            mVelocityY = FLY_VELOCITY * -1;
        }
        else {
            mY = GameView.mViewPort.top + 1 - BOUNDING_BOX_SIZE_LAUNCH_Y;
            mVelocityY = FLY_VELOCITY;
        }

        updateBoundingBox();
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot
            || otherObject instanceof WeaponElectricityHorizontal
            || otherObject instanceof WeaponElectricityVertical
            || otherObject instanceof WeaponCutter
            || otherObject instanceof WeaponIce
            || otherObject instanceof WeaponFireHorizontal
            || otherObject instanceof WeaponFireSpinner
            || otherObject instanceof WeaponBomb
            || otherObject instanceof WeaponGuts
            || otherObject instanceof WeaponGutsFragment) {

            mHurtOrDead = true;

            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

            gameEngine.removeGameObject(this);
            mParent.releaseAlien(this);

            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        // if not on screen, destroy the alien
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseAlien(this);
            return;
        }

        // calculate positional values
        final int playerCenterX = gameEngine.mPlayer.mBoundingBox.centerX();
        final int playerCenterY = gameEngine.mPlayer.mBoundingBox.centerY();
        final int alienCenterX = mBoundingBox.centerX();
        final int alienCenterY = mBoundingBox.centerY();
        final boolean abovePlayer = playerCenterY > alienCenterY;
        final boolean leftOfPlayer = playerCenterX > alienCenterX;

        final int absoluteDistanceToPlayer = Math.abs(playerCenterY - alienCenterY);

        switch(mState) {
            case STATE_LAUNCH:
                // check for getting closer
                if(absoluteDistanceToPlayer <= OPEN1_DISTANCE) {
                    mState = STATE_OPEN1;
                    mFrame = 1;
                    mBoundingBox.set(0, 0, 16, BOUNDING_BOX_SIZE_OPENING_Y);
                    updateBoundingBox();
                }

                // make sure to approach player
                if(abovePlayer) mVelocityY = FLY_VELOCITY;
                else mVelocityY = FLY_VELOCITY * -1;

                // face the player
                if(leftOfPlayer) mDirection = 1;
                else mDirection = -1;
                break;
            case STATE_OPEN1:
                if(absoluteDistanceToPlayer <= OPEN2_DISTANCE) {
                    mState = STATE_OPEN2;
                    mFrame = 2;
                    mBoundingBox.set(0, 0, 16, BOUNDING_BOX_SIZE_OPENED_Y);
                    updateBoundingBox();
                }

                // make sure to approach player
                if(abovePlayer) mVelocityY = FLY_VELOCITY;
                else mVelocityY = FLY_VELOCITY * -1;

                // face the player
                if(leftOfPlayer) mDirection = 1;
                else mDirection = -1;
                break;
            case STATE_OPEN2:
                if(absoluteDistanceToPlayer <= SHOOT_DISTANCE) {
                    mState = STATE_SHOOT;
                }

                // make sure to approach player
                if(abovePlayer) mVelocityY = FLY_VELOCITY;
                else mVelocityY = FLY_VELOCITY * -1;

                // face the player
                if(leftOfPlayer) mDirection = 1;
                else mDirection = -1;
                break;
            case STATE_SHOOT:
                // face the player
                if(leftOfPlayer) mDirection = 1;
                else mDirection = -1;

                ElectricityMini em1 = electricityMiniGet();
                if(em1 != null) {
                    em1.init(mBoundingBox.centerX() + 8 * mDirection, mBoundingBox.centerY() - 19, mDirection, gameEngine);
                    gameEngine.addGameObject(em1);
                }
                ElectricityMini em2 = electricityMiniGet();
                if(em2 != null) {
                    em2.init(mBoundingBox.centerX() + 8 * mDirection, mBoundingBox.centerY() + 19, mDirection, gameEngine);
                    gameEngine.addGameObject(em2);
                }

                // start retreat
                mState = STATE_CLOSE1;

                // make sure to retreat from player
                if(abovePlayer) mVelocityY = FLY_VELOCITY * -1;
                else mVelocityY = FLY_VELOCITY;
                break;
            case STATE_CLOSE1:
                if(absoluteDistanceToPlayer >= CLOSE1_DISTANCE) {
                    mState = STATE_CLOSE2;
                    mFrame = 1;
                    mBoundingBox.set(0, 0, 16, BOUNDING_BOX_SIZE_OPENING_Y);
                    updateBoundingBox();
                }

                // make sure to retreat from player
                if(abovePlayer) mVelocityY = FLY_VELOCITY * -1;
                else mVelocityY = FLY_VELOCITY;
                break;
            case STATE_CLOSE2:
                if(absoluteDistanceToPlayer >= CLOSE2_DISTANCE) {
                    mState = STATE_RETREAT;
                    mFrame = 0;
                    mBoundingBox.set(0, 0, 16, BOUNDING_BOX_SIZE_LAUNCH_Y);
                    updateBoundingBox();
                }

                // make sure to retreat from player
                if(abovePlayer) mVelocityY = FLY_VELOCITY * -1;
                else mVelocityY = FLY_VELOCITY;
                break;
        }

        // move
        final double distance = mVelocityY * elapsedMillis + mYFractional;
        mY += (int)distance;
        mYFractional = distance % 1;
        updateBoundingBox();
    }
}
