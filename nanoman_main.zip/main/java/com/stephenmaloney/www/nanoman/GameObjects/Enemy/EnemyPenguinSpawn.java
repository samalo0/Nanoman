package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class EnemyPenguinSpawn extends GameObject {
    public final static String TYPE = "EnemyPenguin";

    private final Rect mBoundingBox;
    private final int mDirection;

    private final EnemyPenguin mPenguin;
    private boolean mPenguinReleased = true;

    private int mDelay = 3000;

    public EnemyPenguinSpawn(Resources resources, HashMap<String, String> properties) {
        mDirection = Integer.parseInt(properties.get("Direction"));

        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;

        mPenguin = new EnemyPenguin(resources, mDirection, this);

        mBoundingBox = new Rect(x, y, x + Tile.SIZE, y + Tile.SIZE);
    }

    @Override
    public void onDraw(Canvas canvas) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(GameEngine.isObjectVisible(mBoundingBox)) {
            mDelay += elapsedMillis;
            if(mDelay >= 3000 && mPenguinReleased) {
                mPenguinReleased = false;
                if (mDirection == 1)
                    mPenguin.init(GameView.mViewPort.left, gameEngine.mPlayer.mBoundingBox.centerY());
                else
                    mPenguin.init(GameView.mViewPort.right - 1, gameEngine.mPlayer.mBoundingBox.centerY());
                gameEngine.addGameObject(mPenguin);

                mDelay = 0;
            }
        }
    }

    void releasePenguin() {
        mPenguinReleased = true;
    }

    @Override
    public void startGame(GameEngine gameEngine) {
    }
}
