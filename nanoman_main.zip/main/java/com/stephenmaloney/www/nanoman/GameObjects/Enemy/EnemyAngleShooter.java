package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public class EnemyAngleShooter extends SpriteFrameAnimation {
    public final static String TYPE = "EnemyAngleShooter";

    private final static int STATE_START_DELAY = 0;
    private final static int STATE_PROTECTED = 1;
    private final static int STATE_OPENING = 2;
    private final static int STATE_SHOOTING = 3;
    private final static int STATE_CLOSING = 4;
    private int mState = STATE_START_DELAY;
    private int mStateTimer = 0;

    private final Rect mBoundingBoxSmall = new Rect(0, 0, 9, 16);
    private final Rect mBoundingBoxExtended = new Rect(0, 0, 15, 16);

    private EnemyAngleShooterShot[] mShots = new EnemyAngleShooterShot[SHOTS_LIMIT];
    private boolean mShotsReleased[] = {true, true, true, true};
    private final static int SHOTS_LIMIT = 4;
    private int mCurrentShot = 0;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    public EnemyAngleShooter(Resources resources, HashMap<String, String> properties) {
        super(0, 0, 9, 16, 4);

        mDirection = Integer.parseInt(properties.get("Direction"));

        mX = (Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2);
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2);
        updateBoundingBox();

        mStateTimer = Integer.parseInt(properties.get("StartDelay"));

        final String color = properties.get("Color");
        switch(color) {
            case "Red":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_red1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_red2);
                mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_red3);
                mFrames[3] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_red4);

                for(int i = 0; i < SHOTS_LIMIT; i++) mShots[i] = new EnemyAngleShooterShot(resources, R.drawable.gameobject_enemy_shot_red, i, mDirection, this);
                break;
            case "Blue":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_blue1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_blue2);
                mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_blue3);
                mFrames[3] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_blue4);

                for(int i = 0; i < SHOTS_LIMIT; i++) mShots[i] = new EnemyAngleShooterShot(resources, R.drawable.gameobject_enemy_shot_blue, i, mDirection, this);
                break;
            case "Orange":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_orange1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_orange2);
                mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_orange3);
                mFrames[3] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_angle_shooter_orange4);

                for(int i = 0; i < SHOTS_LIMIT; i++) mShots[i] = new EnemyAngleShooterShot(resources, R.drawable.gameobject_enemy_shot_orange, i, mDirection, this);
                break;
        }

        if(mDirection == -1) {
            // flip bitmaps horizontally
            mMatrix.reset();
            mMatrix.preScale(-1, 1);
            for(int i = 0; i < 4; i++) mFrames[i] = Bitmap.createBitmap(mFrames[i], 0, 0, mFrames[i].getWidth(), mFrames[i].getHeight(), mMatrix, false);

            mX += 1;
            mBoundingBoxOffsetX = 6;
            mBoundingBoxOffsetY = 0;
            updateBoundingBox();
        }

        mPlayerDamage = 12;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(mState == STATE_PROTECTED) {
            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DINK);
            return;
        }

        if(otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts) {

            mHurtOrDead = true;

            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

            gameEngine.removeGameObject(this);
            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        switch(mState) {
            case STATE_START_DELAY:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    mState = STATE_PROTECTED;
                }
                break;
            case STATE_PROTECTED:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 2000) {
                    mStateTimer = 0;
                    mState = STATE_OPENING;
                    mFrame = 1;
                    mStateTimer = 0;
                }
                break;
            case STATE_OPENING:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 100) {
                    mStateTimer = 0;
                    if(mFrame == 2) {
                        mState = STATE_SHOOTING;
                        mFrame = 3;
                        mCurrentShot = 0;
                        mBoundingBox.set(mBoundingBoxExtended);
                        if(mDirection == -1) {
                            mBoundingBoxOffsetX = 0;
                            mBoundingBoxOffsetY = 0;
                        }
                        updateBoundingBox();
                    }
                    else mFrame++;
                }
                break;
            case STATE_SHOOTING:
                mStateTimer += elapsedMillis;
                if(mStateTimer > 750) {
                    mStateTimer = 0;
                    if(mShotsReleased[mCurrentShot]) {
                        mShotsReleased[mCurrentShot] = false;
                        if(mDirection == 1) mShots[mCurrentShot].init(mX + 15, mY + 5, gameEngine);
                        else mShots[mCurrentShot].init(mX - 6, mY + 5, gameEngine);
                        gameEngine.addGameObject(mShots[mCurrentShot]);
                    }
                    mCurrentShot++;
                    if(mCurrentShot == SHOTS_LIMIT) {
                        mState = STATE_CLOSING;
                        mFrame = 2;
                        mBoundingBox.set(mBoundingBoxSmall);
                        if(mDirection == -1) {
                            mBoundingBoxOffsetX = 6;
                            mBoundingBoxOffsetY = 0;
                        }
                        updateBoundingBox();
                    }
                }
                break;
            case STATE_CLOSING:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 100) {
                    mStateTimer = 0;
                    if(mFrame == 1) {
                        mState = STATE_PROTECTED;
                        mFrame = 0;
                    }
                    else mFrame--;
                }
                break;
        }
    }

    void releaseShot(int index) {
        mShotsReleased[index] = true;
    }

    @Override
    public void startGame(GameEngine gameEngine) {
    }
}
