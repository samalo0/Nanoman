package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;

import java.util.HashMap;

public class EnemyFlameHeadSpawn extends GameObject {
    public final static String TYPE = "EnemyFlameHead";

    private final EnemyFlameHead mHead;
    private boolean mHeadReleased = true;

    private final Rect mBoundingBox;

    public EnemyFlameHeadSpawn(Resources resources, HashMap<String, String> properties) {
        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;
        mBoundingBox = new Rect(x, y, x + Tile.SIZE, y + Tile.SIZE);

        mHead = new EnemyFlameHead(resources, this);
    }

    @Override
    public void onDraw(Canvas canvas) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameView.mViewPort.contains(mBoundingBox)) {
            return;
        }

        if(mHeadReleased) {
            mHeadReleased = false;
            mHead.init();
            gameEngine.addGameObject(mHead);
        }
    }

    void releaseHead() {
        mHeadReleased = true;
    }
}
