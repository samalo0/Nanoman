package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.os.Environment;
import android.util.Log;
import android.util.Xml;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyAlienSpawn;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyAngleShooter;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBigeye;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBomberSpawn;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBombman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBubbleRobot;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyClone;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyCutman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyElecman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyEyePatrol;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFireman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFlameHeadSpawn;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFlyingNutSpawn;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFootHolder;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyGutsman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyHelicopterSpawn;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyHelmet;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyIceman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyJumperSpawn;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyMiner;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyMissileSpawn;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyPenguinSpawn;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyRobotSpawn;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyScissorsSpawn;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyShieldSoldier;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemySlider;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemySpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyWily;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyYellowDemon;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.AmmoLarge;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.AmmoSmall;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.CheckPoint;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.HealthLarge;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.HealthSmall;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.OneUp;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.WeaponMagnetPickup;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsBlock;
import com.stephenmaloney.www.nanoman.R;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.HashMap;

public class Stage extends GameObject {
    private final static float SCROLL_VELOCITY = .3f;

    private final Bitmap mBitmap;

    private Tile[] mTileSet;
    public int[][] mTileMap;
    private int mTileMapColumns;
    private int mTileMapRows;
    public int mSolidTileNumber;

    private float mScrollVelocity;
    private float mScrollFloatAccumulator;
    private int mScrollEnd;
    private boolean mScrollingY = false;
    private boolean mScrollingX = false;

    private boolean mScrollLock;
    private int mScrollLockX;
    private int mScrollLockDirection;

    public Stage(GameEngine gameEngine, int stageXmlResourceId) {
        // read stage xml file and build tiles and map
        xmlLoadStageFromResource(gameEngine, stageXmlResourceId);

        // build stage bitmap
        // build an empty bitmap the size of the level
        mBitmap = Bitmap.createBitmap(mTileMapColumns << Tile.SIZE_POW_2, mTileMapRows << Tile.SIZE_POW_2, Bitmap.Config.ARGB_8888);

        // create a canvas from the bitmap and place all the tiles on it
        Canvas canvas = new Canvas(mBitmap);
        for(int row = 0; row < mTileMapRows; row++) {
            for(int column = 0; column < mTileMapColumns; column++) {
                canvas.drawBitmap(mTileSet[mTileMap[row][column]].mBitmap, column << Tile.SIZE_POW_2, row << Tile.SIZE_POW_2, GameView.mPaint);
            }
        }

        // find a solid tile to use for block puzzles
        for(int i = 0; i < mTileSet.length; i++) {
            if(mTileSet[i].mSolid) {
                mSolidTileNumber = i;
                break;
            }
        }
    }

    @Override
    public void onDraw(Canvas canvas) {
        canvas.drawBitmap(mBitmap, GameView.mViewPort, GameView.mGameView, GameView.mPaint);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
    }

    public void onUpdateClimb(Player player, int direction) {
        final int column = player.mBoundingBox.centerX() >> Tile.SIZE_POW_2;
        int row;
        if(direction == 1) row = player.mBoundingBox.bottom >> Tile.SIZE_POW_2;
        else row = player.mBoundingBox.top >> Tile.SIZE_POW_2;

        final int rowBottom = (player.mBoundingBox.bottom - 1) >> Tile.SIZE_POW_2;

        boolean wasClimbingTop = player.mClimbTop;
        player.mClimbing = false;
        player.mClimbTop = false;

        if(mTileSet[mTileMap[row][column]].mClimb) {
            // set climbing flag
            player.mClimbing = true;

            // place player left edge bounding box on climbing tile horizontally
            player.mX = (column << Tile.SIZE_POW_2) - Player.BOUNDING_BOX_OFFSET_X + 2;
            player.mXFractional = 0;
            player.updateBoundingBox();

            if(direction == 1 && !mTileSet[mTileMap[row - 1][column]].mSolid && !mTileSet[mTileMap[row - 1][column]].mClimb) {
                // starting to climb down a ladder - transition from standing to climbing
                player.mClimbTop = true;
            }
        }
        else if(direction == -1 && mTileSet[mTileMap[rowBottom][column]].mClimb) {
            // transition from climbing to standing at the top of a ladder
            player.mClimbing = true;
            player.mClimbTop = true;
        }

        // check for player climbing to the top of the ladder - stop falling back down
        if(!player.mClimbTop && !player.mClimbing && wasClimbingTop && direction == -1) {
            player.mVelocityY = 0;
            player.mY = (row << Tile.SIZE_POW_2) + 8;
            player.mYFractional = 0;
            player.updateBoundingBox();
        }
    }

    public void onUpdateCollisionX(long elapsedMillis, Sprite sprite) {
        if(elapsedMillis == 0) return;

        // if no velocity, no position change or collisions
        if(sprite instanceof Player) {
            if(sprite.mVelocityX == 0 && !((Player) sprite).mOnTram && !((Player)sprite).mOnFootHolder && ((Player) sprite).mPushVelocity == 0) return;
        }
        else if(sprite.mVelocityX == 0) return;

        // calculate desired distance to move
        double adjustedVelocityX = sprite.mVelocityX;
        if(sprite instanceof Player) {
            if(((Player) sprite).mOnFootHolder) adjustedVelocityX += ((Player)sprite).mFootHolder.mVelocityX;
            if(((Player) sprite).mOnTram) adjustedVelocityX += ((Player) sprite).mTramVelocity;
            adjustedVelocityX += ((Player) sprite).mPushVelocity;
        }
        double distance = adjustedVelocityX * elapsedMillis + sprite.mXFractional;

        // determine which tiles on y axis intersect the bounding box
        final int startRow = sprite.mBoundingBox.top >> Tile.SIZE_POW_2;
        final int endRow = (sprite.mBoundingBox.bottom - 1) >> Tile.SIZE_POW_2;

        // get forward facing edge coordinate for distance calculation
        int forwardEdge;
        if(adjustedVelocityX > 0) forwardEdge = sprite.mBoundingBox.right;
        else forwardEdge = sprite.mBoundingBox.left;

        final int startColumn = forwardEdge >> Tile.SIZE_POW_2;

        // find the next solid tiles in the direction faced
        boolean foundSolid = false;
        int solidTileX = 0;
        if(adjustedVelocityX > 0) {
            final int endColumn = (startColumn + GameView.VIEW_WIDTH_IN_TILES) < mTileMapColumns? startColumn + GameView.VIEW_WIDTH_IN_TILES : mTileMapColumns;

            // check for object outside the tile map and return
            if(startColumn >= mTileMapColumns || startRow >= mTileMapRows || endRow >= mTileMapRows) return;

            for (int column = startColumn; column < endColumn; column++) {
                for (int row = startRow; row <= endRow; row++) {
                    if(mTileSet[mTileMap[row][column]].mSolid) {
                        foundSolid = true;
                        solidTileX = column << Tile.SIZE_POW_2;
                        break;
                    }
                }
                if(foundSolid) break;
            }

            if(!foundSolid) solidTileX = mTileMapColumns << Tile.SIZE_POW_2;

            int distanceToSolid = solidTileX - forwardEdge;
            if(distance < distanceToSolid) {
                sprite.mX += (int)distance;
                sprite.mXFractional = distance % 1;
            }
            else {
                // ran into solid
                sprite.mX += distanceToSolid;
                sprite.mXFractional = 0;
                sprite.mVelocityX = 0;
            }
            sprite.updateBoundingBox();
        }
        else {
            final int endColumn = startColumn - GameView.VIEW_WIDTH_IN_TILES > 0? startColumn - GameView.VIEW_WIDTH_IN_TILES : 0;

            // check for object outside the tile map and return
            if(startColumn >= mTileMapColumns || endColumn >= mTileMapColumns || startRow >= mTileMapRows || endRow >= mTileMapRows) return;

            for (int column = startColumn; column >= endColumn; column--) {
                for (int row = startRow; row <= endRow; row++) {
                    if(mTileSet[mTileMap[row][column]].mSolid) {
                        foundSolid = true;
                        solidTileX = (column << Tile.SIZE_POW_2) + Tile.SIZE;
                        break;
                    }
                }
                if(foundSolid) break;
            }

            if(!foundSolid) solidTileX = 0;

            int distanceToSolid = solidTileX - forwardEdge;
            if(distance > distanceToSolid) {
                sprite.mX += (int)distance;
                sprite.mXFractional = distance % 1;
            }
            else {
                sprite.mX += distanceToSolid;
                sprite.mXFractional = 0;
                sprite.mVelocityX = 0;
            }
            sprite.updateBoundingBox();
        }

        if(sprite instanceof Player){
            ((Player) sprite).mInWater = mTileSet[mTileMap[((Player) sprite).mBoundingBox.centerY() >> Tile.SIZE_POW_2][((Player) sprite).mBoundingBox.centerX() >> Tile.SIZE_POW_2]].mWater;
        }
    }

    public boolean onUpdateCollisionXNoFall(long elapsedMillis, Sprite sprite) {
        boolean retVal = false;

        // if no velocity, no position change or collisions
        if(sprite.mVelocityX == 0) return false;

        // calculate desired distance to move
        double distance = sprite.mVelocityX * elapsedMillis + sprite.mXFractional;

        // determine which tiles on y axis intersect the bounding box
        int startRow = sprite.mBoundingBox.top >> Tile.SIZE_POW_2;
        int endRow = (sprite.mBoundingBox.bottom - 1) >> Tile.SIZE_POW_2;

        // get forward facing edge coordinate for distance calculation
        int forwardEdge;
        if(sprite.mVelocityX > 0) forwardEdge = sprite.mBoundingBox.right;
        else forwardEdge = sprite.mBoundingBox.left;

        int startColumn = forwardEdge >> Tile.SIZE_POW_2;

        boolean foundObstacle = false;
        int tileX = 0;
        if(sprite.mVelocityX > 0) {
            // find the next solid tiles in the direction faced (or next non-solid tile in the row below)
            for (int column = startColumn; column < mTileMapColumns; column++) {
                for (int row = startRow; row <= endRow; row++) {
                    if(mTileSet[mTileMap[row][column]].mSolid || !mTileSet[mTileMap[row + 1][column]].mSolid) {
                        foundObstacle = true;
                        tileX = column << Tile.SIZE_POW_2;
                        break;
                    }
                }
                if(foundObstacle) break;
            }

            if(foundObstacle) {
                int distanceToObstacle = tileX - forwardEdge;
                if(distance < distanceToObstacle) {
                    sprite.mX += (int)distance;
                    sprite.mXFractional = distance % 1;
                }
                else {
                    sprite.mX += distanceToObstacle;
                    sprite.mXFractional = 0;
                    retVal = true;
                }
                sprite.updateBoundingBox();
                return retVal;
            }
        }
        else {
            for (int column = startColumn; column >= 0; column--) {
                for (int row = startRow; row <= endRow; row++) {
                    if(mTileSet[mTileMap[row][column]].mSolid || !mTileSet[mTileMap[row + 1][column]].mSolid) {
                        foundObstacle = true;
                        tileX = (column << Tile.SIZE_POW_2) + Tile.SIZE;
                        break;
                    }
                }
                if(foundObstacle) break;
            }

            if(foundObstacle) {
                int distanceToObstacle = tileX - forwardEdge;
                if(distance > distanceToObstacle) {
                    sprite.mX += (int)distance;
                    sprite.mXFractional = distance % 1;
                }
                else {
                    sprite.mX += distanceToObstacle;
                    sprite.mXFractional = 0;
                    retVal = true;
                }
                sprite.updateBoundingBox();
                return retVal;
            }
        }

        sprite.mX += (int)distance;
        sprite.mXFractional = distance % 1;
        sprite.updateBoundingBox();
        return false;
    }

    public void onUpdateCollisionY(long elapsedMillis, Sprite sprite, GameEngine gameEngine) {
        if(elapsedMillis == 0) return;

        // no velocity, no movement
        double distance = 0;
        if(sprite instanceof Player) {
            if(sprite.mVelocityY == 0 && !((Player) sprite).mOnFootHolder) return;

            // add foot holder distance
            if(((Player) sprite).mOnFootHolder) distance = ((Player) sprite).mFootHolder.mVelocityY * elapsedMillis;
        }
        else if(sprite.mVelocityY == 0) return;

        // calculate distance to move
        distance += sprite.mVelocityY * elapsedMillis + sprite.mYFractional;

        // determine which tiles on x axis intersect the bounding box
        int startColumn = sprite.mBoundingBox.left >> Tile.SIZE_POW_2;
        int endColumn = (sprite.mBoundingBox.right - 1) >> Tile.SIZE_POW_2;

        // get forward facing edge coordinate for distance calculation
        int forwardEdge;
        if(sprite.mVelocityY > 0) forwardEdge = sprite.mBoundingBox.bottom;
        else forwardEdge = sprite.mBoundingBox.top;
        int startRow = forwardEdge >> Tile.SIZE_POW_2;

        // find the next solid tiles in the direction faced
        boolean foundSolid = false;
        boolean foundDeath = false;
        boolean foundIce = false;
        int solidTileY = 0;
        if(sprite.mVelocityY > 0) {
            // check for object outside the tile map and return
            if(startColumn >= mTileMapColumns || endColumn >= mTileMapColumns || startRow >= mTileMapRows) return;

            // moving downward
            for (int row = startRow; row < mTileMapRows; row++) {
                for (int column = startColumn; column <= endColumn; column++) {
                    if(mTileSet[mTileMap[row][column]].mSolid) {
                        foundSolid = true;
                        solidTileY = row << Tile.SIZE_POW_2;
                        foundDeath = mTileSet[mTileMap[row][column]].mDeath;
                        foundIce = mTileSet[mTileMap[row][column]].mIce;
                        break;
                    }

                    // if the sprite is a player
                    if(sprite instanceof Player) {
                        if(mTileSet[mTileMap[row][column]].mClimb && !((Player)sprite).mClimbing) {
                            // falling on a top climbable should stop movement like a solid, unless a player is climbing down
                            if(!mTileSet[mTileMap[row - 1][column]].mSolid && !mTileSet[mTileMap[row - 1][column]].mClimb) {
                                solidTileY = row << Tile.SIZE_POW_2;
                                if(solidTileY < forwardEdge) {
                                    // bounding box bottom inside top climbing tile
                                    continue;
                                }
                                else foundSolid = true;
                                break;
                            }
                        }
                    }
                }
                if(foundSolid) break;
            }

            if(!foundSolid) solidTileY = mTileMapRows << Tile.SIZE_POW_2;

            int distanceToSolid = solidTileY - forwardEdge;
            if(distance < distanceToSolid) {
                // falling
                sprite.mY += (int)distance;
                sprite.mYFractional = distance % 1;
                sprite.mOnGround = false;
                sprite.updateBoundingBox();
            }
            else {
                // landed on the ground
                sprite.mY += distanceToSolid;
                sprite.mYFractional = 0;
                if(!sprite.mOnGround) sprite.mJustLanded = true;
                sprite.mOnGround = true;
                sprite.mVelocityY = 0;
                sprite.updateBoundingBox();

                if(sprite instanceof Player) {
                    // standing on ice?
                    ((Player)sprite).mOnIce = foundIce;

                    // fell into death
                    if(foundDeath) ((Player)sprite).onDeath(gameEngine);
                }
            }
        }
        else {
            // check for object outside the tile map and return
            if(startColumn >= mTileMapColumns || endColumn >= mTileMapColumns || startRow >= mTileMapRows) return;

            // rising
            for (int row = startRow; row >= 0; row--) {
                for (int column = startColumn; column <= endColumn; column++) {
                    if(mTileSet[mTileMap[row][column]].mSolid) {
                        foundSolid = true;
                        solidTileY = (row << Tile.SIZE_POW_2) + Tile.SIZE;

                        foundDeath = mTileSet[mTileMap[row][column]].mDeath;
                        break;
                    }
                }
                if(foundSolid) break;
            }

            if(!foundSolid) solidTileY = 0;

            int distanceToSolid = solidTileY - forwardEdge;
            if(distance > distanceToSolid) {
                // moving up
                sprite.mY += (int)distance;
                sprite.mYFractional = distance % 1;
                sprite.updateBoundingBox();
            }
            else {
                // hit head
                sprite.mY += distanceToSolid;
                sprite.mYFractional = 0;
                sprite.mVelocityY = -.25f * sprite.mVelocityY;
                sprite.updateBoundingBox();

                if(sprite instanceof Player) {
                    if (foundDeath) {
                        // hit head on death tile
                        ((Player) sprite).onDeath(gameEngine);
                    }
                    else {
                        // if jumping, stop rise
                        ((Player)sprite).mJumpReleaseTimer = -1;
                    }
                }
            }
            sprite.mOnGround = false;
        }

        if(sprite instanceof Player){
            ((Player) sprite).mInWater = mTileSet[mTileMap[((Player) sprite).mBoundingBox.centerY() >> Tile.SIZE_POW_2][((Player) sprite).mBoundingBox.centerX() >> Tile.SIZE_POW_2]].mWater;
        }
    }

    public void onUpdateGateScrollX(long elapsedMillis) {
        if(mScrollingX) {
            mScrollFloatAccumulator += mScrollVelocity * elapsedMillis;
            final int scrollInt = (int) mScrollFloatAccumulator;
            GameView.mViewPort.offsetTo(scrollInt, GameView.mViewPort.top);

            if ((mScrollVelocity > 0 && scrollInt >= mScrollEnd) || (mScrollVelocity < 0 && scrollInt <= mScrollEnd)) {
                GameView.mViewPort.offsetTo(mScrollEnd, GameView.mViewPort.top);
                mScrollingX = false;
            }
        }
    }

    public void onUpdateScrollX(Player player) {
        // if no scroll lock, get player adjusted horizontal velocity
        double adjustedVelocityX = player.mVelocityX + player.mPushVelocity;
        if(player.mOnTram) adjustedVelocityX += player.mTramVelocity;
        if(player.mOnFootHolder) adjustedVelocityX += player.mFootHolder.mVelocityX;

        // stop scrolling if there is a horizontal scroll lock
        if(adjustedVelocityX > 0) {
            if(mScrollLock && mScrollLockDirection == 1 && GameView.mViewPort.right >= (mScrollLockX - 1)) return;

            if(player.mX > GameView.mViewPort.centerX() && (GameView.mViewPort.right >> Tile.SIZE_POW_2) < mTileMap[0].length
                    && (!mTileSet[mTileMap[GameView.mViewPort.top >> Tile.SIZE_POW_2][GameView.mViewPort.right >> Tile.SIZE_POW_2]].mNoScroll)) {

                GameView.mViewPort.offsetTo(player.mX - GameView.VIEW_WIDTH_DIV_2, GameView.mViewPort.top);
            }
        }
        else if(adjustedVelocityX < 0) {
            if(mScrollLock && mScrollLockDirection == -1 && GameView.mViewPort.left <= (mScrollLockX)) return;

            if(adjustedVelocityX < 0 && player.mX < GameView.mViewPort.centerX() && (GameView.mViewPort.left > 0)
                    && (!mTileSet[mTileMap[GameView.mViewPort.top >> Tile.SIZE_POW_2][(GameView.mViewPort.left - 1) >> Tile.SIZE_POW_2]].mNoScroll)) {

                GameView.mViewPort.offsetTo(player.mX - GameView.VIEW_WIDTH_DIV_2, GameView.mViewPort.top);
            }
        }
    }

    public void onUpdateScrollY(GameEngine gameEngine, long elapsedMillis, Player player) {
        if(mScrollingY) {
            mScrollFloatAccumulator += mScrollVelocity * elapsedMillis;
            final int scrollInt = (int) mScrollFloatAccumulator;
            GameView.mViewPort.offsetTo(GameView.mViewPort.left, scrollInt);

            if(mScrollVelocity > 0 && scrollInt >= mScrollEnd) {
                mScrollingY = false;
                mScrollLock = false;
                GameView.mViewPort.offsetTo(GameView.mViewPort.left, mScrollEnd);
                gameEngine.setState(GameEngine.STATE_NORMAL);
            }
            else if(mScrollVelocity < 0 && scrollInt <= mScrollEnd) {
                mScrollingY = false;
                mScrollLock = false;
                GameView.mViewPort.offsetTo(GameView.mViewPort.left, mScrollEnd);
                gameEngine.setState(GameEngine.STATE_NORMAL);
            }
        }
        else if (player.mVelocityY > 0
                && player.mBoundingBox.top > GameView.mViewPort.bottom
                && !mTileSet[mTileMap[GameView.mViewPort.bottom >> Tile.SIZE_POW_2][GameView.mViewPort.left >> Tile.SIZE_POW_2]].mNoScroll) {
            gameEngine.setState(GameEngine.STATE_SCROLLING_Y);
            mScrollingY = true;
            mScrollVelocity = SCROLL_VELOCITY;
            mScrollEnd = GameView.mViewPort.top + GameView.VIEW_HEIGHT;
            mScrollFloatAccumulator = GameView.mViewPort.top;
        }
        else if (player.mVelocityY < 0
                && player.mBoundingBox.bottom < GameView.mViewPort.top
                && !mTileSet[mTileMap[(GameView.mViewPort.top >> Tile.SIZE_POW_2) - 1][player.mBoundingBox.centerX() >> Tile.SIZE_POW_2]].mNoScroll) {
            gameEngine.setState(GameEngine.STATE_SCROLLING_Y);
            mScrollingY = true;
            mScrollVelocity = -SCROLL_VELOCITY;
            mScrollEnd = GameView.mViewPort.top - GameView.VIEW_HEIGHT;
            mScrollFloatAccumulator = GameView.mViewPort.top;
        }
    }

    void onUpdateTram(long elapsedMillis, Tram tram) {
        // calculate desired distance to move
        double distance = tram.mVelocityX * elapsedMillis + tram.mXFractional;

        // determine which tiles on y axis intersect the bounding box
        int row = (tram.mBoundingBox.bottom - 1) >> Tile.SIZE_POW_2;

        // get forward facing edge coordinate for distance calculation
        int forwardEdge;
        if(tram.mVelocityX > 0) forwardEdge = (int)tram.mX + 8;
        else forwardEdge = tram.mBoundingBox.left;

        int startColumn = forwardEdge >> Tile.SIZE_POW_2;

        boolean foundEnd = false;
        int endTileX = 0;
        if(tram.mVelocityX > 0) {
            for (int column = startColumn; column < mTileMapColumns; column++) {
                if(mTileMap[row][column] == tram.mEndTileNumber) {
                    foundEnd = true;
                    endTileX = column << Tile.SIZE_POW_2;
                    break;
                }
            }

            if(!foundEnd) endTileX = mTileMapColumns << Tile.SIZE_POW_2;

            int distanceToEndTile = endTileX - forwardEdge;
            if(distance < distanceToEndTile) {
                tram.mX += (int)distance;
                tram.mXFractional = distance % 1;
            }
            else {
                // ran into end tile - go the other way
                tram.mX += distanceToEndTile;
                tram.mXFractional = 0;
                tram.mVelocityX *= -1;
            }
            tram.updateBoundingBox();

            if(mTileMap[row][(tram.mBoundingBox.left + 8) >> Tile.SIZE_POW_2] == tram.mDipTileNumber) tram.transitionToDown();
            else tram.transitionToSupport();
        }
        else {
            for (int column = startColumn; column >= 0; column--) {
                if(mTileMap[row][column] == tram.mEndTileNumber) {
                    foundEnd = true;
                    endTileX = (column << Tile.SIZE_POW_2) + Tile.SIZE;
                    break;
                }
            }

            if(!foundEnd) endTileX = 0;

            int distanceToEndTile = endTileX - forwardEdge;
            if(distance > distanceToEndTile) {
                tram.mX += (int)distance;
                tram.mXFractional = distance % 1;
            }
            else {
                tram.mX += distanceToEndTile;
                tram.mXFractional = 0;
                tram.mVelocityX *= -1;
            }
            tram.updateBoundingBox();

            if(mTileMap[row][tram.mBoundingBox.left >> Tile.SIZE_POW_2] == tram.mDipTileNumber) tram.transitionToDown();
            else tram.transitionToSupport();
        }
    }

    public void setGateTransition(Gate gate) {
        mScrollVelocity = SCROLL_VELOCITY * gate.mPassDirection;
        mScrollEnd = gate.mScrollEndX;
        mScrollFloatAccumulator = GameView.mViewPort.left;
        mScrollingX = true;
    }

    public void setScrollLockX(int x, int direction) {
        mScrollLock = true;
        mScrollLockX = x;
        mScrollLockDirection = direction;
    }

    public void xmlLoadStageFromResource(GameEngine gameEngine, int stageXmlResourceId) {
        try {
            XmlPullParser parser = gameEngine.getResources().getXml(stageXmlResourceId);

            /*
            if(stageXmlResourceId == R.xml.stage_ice) {
                // debugging - building levels
                final File file = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "stage_ice.xml");
                final FileInputStream fileInputStream = new FileInputStream(file);
                parser = Xml.newPullParser();
                parser.setInput(fileInputStream, "UTF-8");
            }
            else parser = gameEngine.getResources().getXml(stageXmlResourceId);
            */

            int eventType = parser.getEventType();

            int tileNumber = 0;
            String drawableName = "";
            boolean climb = false;
            boolean death = false;
            boolean ice = false;
            boolean noScroll = false;
            boolean solid = false;
            boolean water = false;

            int rowNumber = 0;
            boolean inRow = false;

            HashMap<String, String> gameObjectProperties = null;
            String gameObjectType = "";

            while(eventType != XmlPullParser.END_DOCUMENT) {
                String tagName = parser.getName();

                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        switch(tagName) {
                            case "TileSet":
                                for(int attribute = 0; attribute < parser.getAttributeCount(); attribute++) {
                                    switch (parser.getAttributeName(attribute)) {
                                        case "NumberOfTiles":
                                            final int numberOfTiles = Integer.parseInt(parser.getAttributeValue(attribute));
                                            mTileSet = new Tile[numberOfTiles];
                                            break;
                                    }
                                }
                                break;
                            case "Tile":
                                for(int attribute = 0; attribute < parser.getAttributeCount(); attribute++) {
                                    switch(parser.getAttributeName(attribute)) {
                                        case "Number":
                                            tileNumber = Integer.parseInt(parser.getAttributeValue(attribute));
                                            break;
                                        case "DrawableName":
                                            drawableName = parser.getAttributeValue(attribute);
                                            break;
                                        case "Climb":
                                            climb = Boolean.parseBoolean(parser.getAttributeValue(attribute));
                                            break;
                                        case "Death":
                                            death = Boolean.parseBoolean(parser.getAttributeValue(attribute));
                                            break;
                                        case "Ice":
                                            ice = Boolean.parseBoolean(parser.getAttributeValue(attribute));
                                            break;
                                        case "NoScroll":
                                            noScroll = Boolean.parseBoolean(parser.getAttributeValue(attribute));
                                            break;
                                        case "Solid":
                                            solid = Boolean.parseBoolean(parser.getAttributeValue(attribute));
                                            break;
                                        case "Water":
                                            water = Boolean.parseBoolean(parser.getAttributeValue(attribute));
                                            break;
                                    }
                                }
                                break;
                            case "TileMap":
                                for(int attribute = 0; attribute < parser.getAttributeCount(); attribute++) {
                                    switch (parser.getAttributeName(attribute)) {
                                        case "NumberOfRows":
                                            mTileMapRows = Integer.parseInt(parser.getAttributeValue(attribute));
                                            break;
                                        case "NumberOfColumns":
                                            mTileMapColumns = Integer.parseInt(parser.getAttributeValue(attribute));
                                            mTileMap = new int[mTileMapRows][mTileMapColumns];
                                            break;
                                    }
                                }
                                break;
                            case "Row":
                                for(int attribute = 0; attribute < parser.getAttributeCount(); attribute++) {
                                    if(parser.getAttributeName(attribute).equalsIgnoreCase("Number")) {
                                        rowNumber = Integer.parseInt(parser.getAttributeValue(attribute));
                                    }
                                }
                                inRow = true;
                                break;
                            case "GameObjects":
                                break;
                            case "GameObject":
                                gameObjectProperties = new HashMap<>();
                                for(int attribute = 0; attribute < parser.getAttributeCount(); attribute++) {
                                    switch (parser.getAttributeName(attribute)) {
                                        case "Type":
                                            gameObjectType = parser.getAttributeValue(attribute);
                                            gameObjectProperties.put(parser.getAttributeName(attribute), parser.getAttributeValue(attribute));
                                            break;
                                        default:
                                            gameObjectProperties.put(parser.getAttributeName(attribute), parser.getAttributeValue(attribute));
                                            break;
                                    }
                                }
                                break;
                        }
                        break;
                    case XmlPullParser.TEXT:
                        if(inRow) {
                            final String columnString = parser.getText();
                            final String[] columnData = columnString.split(",");
                            for(int columnNumber = 0; columnNumber < mTileMapColumns; columnNumber++) mTileMap[rowNumber][columnNumber] = Integer.parseInt(columnData[columnNumber]);
                        }
                        break;
                    case XmlPullParser.END_TAG:
                        switch(tagName) {
                            case "Tile":
                                mTileSet[tileNumber] = new Tile(gameEngine.getContext(), drawableName);
                                mTileSet[tileNumber].mDrawableName = drawableName;
                                mTileSet[tileNumber].mClimb = climb;
                                mTileSet[tileNumber].mDeath = death;
                                mTileSet[tileNumber].mIce = ice;
                                mTileSet[tileNumber].mNoScroll = noScroll;
                                mTileSet[tileNumber].mSolid = solid;
                                mTileSet[tileNumber].mWater = water;
                                break;
                            case "Row":
                                inRow = false;
                                break;
                            case "GameObject":
                                switch(gameObjectType) {
                                    case StartPosition.TYPE:
                                        // set starting position
                                        StartPosition startPosition = new StartPosition(gameObjectProperties);
                                        gameEngine.setPlayerStartPosition(startPosition.mAbsolutePositionX, startPosition.mAbsolutePositionY, startPosition.mDirection);
                                        break;
                                    case HealthSmall.TYPE:
                                        gameEngine.addGameObject(new HealthSmall(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case HealthLarge.TYPE:
                                        gameEngine.addGameObject(new HealthLarge(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case Electricity.TYPE:
                                        gameEngine.addGameObject(new Electricity(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemySlider.TYPE:
                                        gameEngine.addGameObject(new EnemySlider(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case BlockPuzzle.TYPE:
                                        gameEngine.addGameObject(new BlockPuzzle(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case ElectricityMini.TYPE:
                                        gameEngine.addGameObject(new ElectricityMini(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyAlienSpawn.TYPE:
                                        gameEngine.addGameObject(new EnemyAlienSpawn(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case AmmoSmall.TYPE:
                                        gameEngine.addGameObject(new AmmoSmall(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case AmmoLarge.TYPE:
                                        gameEngine.addGameObject(new AmmoLarge(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case OneUp.TYPE:
                                        gameEngine.addGameObject(new OneUp(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyJumperSpawn.TYPE:
                                        gameEngine.addGameObject(new EnemyJumperSpawn(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case CheckPoint.TYPE:
                                        gameEngine.addGameObject(new CheckPoint(gameObjectProperties));
                                        break;
                                    case Gate.TYPE:
                                        gameEngine.addGameObject(new Gate(gameEngine.getContext(), gameObjectProperties));
                                        break;
                                    case EnemyElecman.TYPE:
                                        gameEngine.addGameObject(new EnemyElecman(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case WeaponGutsBlock.TYPE:
                                        gameEngine.addGameObject(new WeaponGutsBlock(gameEngine.getContext(), gameObjectProperties));
                                        break;
                                    case EnemyBomberSpawn.TYPE:
                                        gameEngine.addGameObject(new EnemyBomberSpawn(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemySpinner.TYPE:
                                        gameEngine.addGameObject(new EnemySpinner(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyAngleShooter.TYPE:
                                        gameEngine.addGameObject(new EnemyAngleShooter(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyShieldSoldier.TYPE:
                                        gameEngine.addGameObject(new EnemyShieldSoldier(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyMissileSpawn.TYPE:
                                        gameEngine.addGameObject(new EnemyMissileSpawn(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyFlyingNutSpawn.TYPE:
                                        gameEngine.addGameObject(new EnemyFlyingNutSpawn(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyEyePatrol.TYPE:
                                        gameEngine.addGameObject(new EnemyEyePatrol(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyBombman.TYPE:
                                        gameEngine.addGameObject(new EnemyBombman(gameEngine.getContext(), gameObjectProperties));
                                        break;
                                    case EnemyHelicopterSpawn.TYPE:
                                        gameEngine.addGameObject(new EnemyHelicopterSpawn(gameEngine, gameObjectProperties));
                                        break;
                                    case EnemyScissorsSpawn.TYPE:
                                        gameEngine.addGameObject(new EnemyScissorsSpawn(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case WeaponMagnetPickup.TYPE:
                                        gameEngine.addGameObject(new WeaponMagnetPickup(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyBigeye.TYPE:
                                        gameEngine.addGameObject(new EnemyBigeye(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyCutman.TYPE:
                                        gameEngine.addGameObject(new EnemyCutman(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyHelmet.TYPE:
                                        gameEngine.addGameObject(new EnemyHelmet(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case Tram.TYPE:
                                        gameEngine.addGameObject(new Tram(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyMiner.TYPE:
                                        gameEngine.addGameObject(new EnemyMiner(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyGutsman.TYPE:
                                        gameEngine.addGameObject(new EnemyGutsman(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyRobotSpawn.TYPE:
                                        gameEngine.addGameObject(new EnemyRobotSpawn(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyPenguinSpawn.TYPE:
                                        gameEngine.addGameObject(new EnemyPenguinSpawn(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyFootHolder.TYPE:
                                        gameEngine.addGameObject(new EnemyFootHolder(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyIceman.TYPE:
                                        gameEngine.addGameObject(new EnemyIceman(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case FlamePillar.TYPE:
                                        gameEngine.addGameObject(new FlamePillar(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyFlameHeadSpawn.TYPE:
                                        gameEngine.addGameObject(new EnemyFlameHeadSpawn(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case FlameHorizontal.TYPE:
                                        gameEngine.addGameObject(new FlameHorizontal(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case FlameHazard.TYPE:
                                        gameEngine.addGameObject(new FlameHazard(gameEngine.getResources()));
                                        break;
                                    case EnemyFireman.TYPE:
                                        gameEngine.addGameObject(new EnemyFireman(gameEngine.getContext(), gameObjectProperties));
                                        break;
                                    case EnemyYellowDemon.TYPE:
                                        gameEngine.addGameObject(new EnemyYellowDemon(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case EnemyClone.TYPE:
                                        gameEngine.addGameObject(new EnemyClone(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                    case Pressure.TYPE:
                                        gameEngine.addGameObject(new Pressure(gameObjectProperties));
                                        break;
                                    case EnemyBubbleRobot.TYPE:
                                        gameEngine.addGameObject(new EnemyBubbleRobot(gameEngine.getResources(), gameObjectProperties, gameEngine.mPlayer.mBoundingBox));
                                        break;
                                    case Teleport.TYPE:
                                        gameEngine.addGameObject(new Teleport(gameObjectProperties));
                                        break;
                                    case EnemyWily.Type:
                                        gameEngine.addGameObject(new EnemyWily(gameEngine.getResources(), gameObjectProperties));
                                        break;
                                }
                                break;
                        }
                        break;
                }
                eventType = parser.next();
            }
        }
        catch(XmlPullParserException | IOException e) {
            Log.d("debug", e.toString());
        }
    }
}
