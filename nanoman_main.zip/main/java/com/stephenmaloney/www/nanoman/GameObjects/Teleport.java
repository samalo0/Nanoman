package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Canvas;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

import java.util.HashMap;

public class Teleport extends GameObject {
    public final static String TYPE = "Teleport";

    private final int mX;
    private final int mY;
    private final int mDestinationX;
    private final int mDestinationY;

    public Teleport(HashMap<String, String> properties) {
        mX = (Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2) + 16;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) - 16;
        mDestinationX = (Integer.parseInt(properties.get("DestinationX")) << Tile.SIZE_POW_2) + 2;
        mDestinationY = (Integer.parseInt(properties.get("DestinationY")) << Tile.SIZE_POW_2) - 8;
    }

    @Override
    public void onDraw(Canvas canvas) {}

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(gameEngine.mPlayer.mBoundingBox.centerX() == mX
                && gameEngine.mPlayer.mBoundingBox.centerY() >= mY
                && gameEngine.mPlayer.mBoundingBox.centerY() <= mY + 32) {

            gameEngine.mPlayer.teleportTo(mDestinationX, mDestinationY, gameEngine);
            gameEngine.removeGameObject(this);
        }
    }
}
