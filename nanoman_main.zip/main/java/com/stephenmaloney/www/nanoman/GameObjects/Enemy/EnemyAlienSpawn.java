package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EnemyAlienSpawn extends GameObject {
    public final static String TYPE = "EnemyAlien";

    private final Rect mBoundingBox;
    private final int mX;
    private final int mY;

    private final List<EnemyAlien> mEnemyAliens = new ArrayList<>();
    private final static int ENEMY_ALIEN_LIMIT = 3;

    private final static int STATE_INITIAL_WAIT = 0;
    private final static int STATE_SPAWN_WAIT = 1;
    private final static int STATE_WAIT_FOR_SCROLL_AWAY = 2;

    private final static int INITIAL_WAIT_MILLIS = 2000;
    private final static int SPAWN_WAIT = 700;
    private int mTimer;
    private int mState;
    private int mFlipper = 1;
    private int mSpawnCount;

    public EnemyAlienSpawn(Resources resources, HashMap<String, String> properties) {
        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;

        mBoundingBox = new Rect(mX, mY, mX + Tile.SIZE, mY + Tile.SIZE);

        // create aliens
        for(int i = 0; i < ENEMY_ALIEN_LIMIT; i++) mEnemyAliens.add(new EnemyAlien(resources, this));
    }

    private EnemyAlien getAlien() {
        if(mEnemyAliens.isEmpty()) return null;
        return mEnemyAliens.remove(0);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            switch(mState) {
                case STATE_WAIT_FOR_SCROLL_AWAY:
                    mState = STATE_INITIAL_WAIT;
                    break;
                case STATE_INITIAL_WAIT:
                    mTimer = 0;
                    break;
            }
            return;
        }

        switch(mState) {
            case STATE_INITIAL_WAIT:
                mTimer += elapsedMillis;
                if(mTimer >= INITIAL_WAIT_MILLIS) {
                    mTimer = 0;
                    mState = STATE_SPAWN_WAIT;
                    mSpawnCount = 0;
                }
                break;
            case STATE_SPAWN_WAIT:
                if(mSpawnCount == ENEMY_ALIEN_LIMIT) {
                    mState = STATE_WAIT_FOR_SCROLL_AWAY;
                    break;
                }

                mTimer += elapsedMillis;
                if(mTimer >= SPAWN_WAIT) {
                    mTimer = 0;
                    EnemyAlien enemyAlien = getAlien();
                    if (enemyAlien == null) {
                        mState = STATE_WAIT_FOR_SCROLL_AWAY;
                    }
                    else {
                        enemyAlien.init(mX + (mFlipper << Tile.SIZE_POW_2), mY);
                        gameEngine.addGameObject(enemyAlien);
                        mFlipper *= -1;
                        mSpawnCount++;
                    }
                }
                break;
        }
    }

    void releaseAlien(EnemyAlien alien) {
        mEnemyAliens.add(alien);
    }

    @Override
    public void startGame(GameEngine gameEngine) {
        mState = STATE_INITIAL_WAIT;
        mTimer = 0;
    }
}
