package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;

import java.util.HashMap;

public class Gate extends GameObject {
    public final static String TYPE = "Gate";

    private final static int STATE_CLOSED_APPROACH = 0;
    private final static int STATE_OPENING = 1;
    private final static int STATE_OPEN = 2;
    private final static int STATE_CLOSING = 3;
    private final static int STATE_IMPASSABLE = 4;
    private int mState = STATE_CLOSED_APPROACH;

    private final static int TILE_MILLIS = 100;
    private int mStateTimer;

    private final int mX;
    private final int mY;
    private final int mTileX;
    private final int mTileY;

    private final static int ORIENTATION_VERTICAL = 0;
    private final static int ORIENTATION_HORIZONTAL = 1;
    private final int mOrientation;

    private int mCurrentLength;
    private final int mMaximumLength;

    private final int mWidth;

    public final int mPassDirection;

    private final Bitmap mBitmap;
    private final Bitmap mTileBitmap;
    private final Rect mBoundingBox;
    private final Canvas mCanvas;
    private final Matrix mMatrix = new Matrix();

    private int mSolidTile;
    private final int[][] mOriginalTile;

    final int mScrollEndX;

    public Gate(Context context, HashMap<String, String> properties) {
        if(properties.get("Orientation").equals("Vertical")) mOrientation = ORIENTATION_VERTICAL;
        else mOrientation = ORIENTATION_HORIZONTAL;

        mWidth = Integer.parseInt(properties.get("Width"));
        mMaximumLength = Integer.parseInt(properties.get("Length"));
        mCurrentLength = mMaximumLength;

        mOriginalTile = new int[mMaximumLength][mWidth];

        mPassDirection = Integer.parseInt(properties.get("PassDirection"));

        final String mDrawable = properties.get("Drawable");
        final int id = context.getResources().getIdentifier(mDrawable, "drawable", context.getPackageName());
        mTileBitmap = BitmapFactory.decodeResource(context.getResources(), id);

        mTileX = Integer.parseInt(properties.get("PositionX"));
        mX = mTileX << Tile.SIZE_POW_2;
        mTileY = Integer.parseInt(properties.get("PositionY"));
        mY = mTileY << Tile.SIZE_POW_2;

        if(mOrientation == ORIENTATION_HORIZONTAL) {
            mBoundingBox = new Rect(mX, mY, mX + (Tile.SIZE * mMaximumLength), mY + (Tile.SIZE * mWidth));
            mBitmap = Bitmap.createBitmap(Tile.SIZE * mMaximumLength, Tile.SIZE * mWidth, Bitmap.Config.ARGB_8888);
            mScrollEndX = 0;
        }
        else {
            mBoundingBox = new Rect(mX, mY, mX + (Tile.SIZE * mWidth), mY + (Tile.SIZE * mMaximumLength));
            mBitmap = Bitmap.createBitmap(Tile.SIZE * mWidth, Tile.SIZE * mMaximumLength, Bitmap.Config.ARGB_8888);
            if(mPassDirection == 1) mScrollEndX = mX + (Tile.SIZE * (mWidth - 1));
            else mScrollEndX = mX + (Tile.SIZE * (mWidth - 1)) - GameView.VIEW_WIDTH;
        }
        mCanvas = new Canvas(mBitmap);

        buildBitmap();
    }

    private void buildBitmap() {
        mBitmap.eraseColor(Color.TRANSPARENT);

        if(mOrientation == ORIENTATION_HORIZONTAL) {
            for(int row = 0; row < mWidth; row++) {
                for (int column = 0; column < mCurrentLength; column++) {
                    mCanvas.drawBitmap(mTileBitmap, column << Tile.SIZE_POW_2, row << Tile.SIZE_POW_2, GameView.mPaint);
                }
            }
        }
        else {
            for (int row = 0; row < mCurrentLength; row++) {
                for (int column = 0; column < mWidth; column++) {
                    mCanvas.drawBitmap(mTileBitmap, column << Tile.SIZE_POW_2, row << Tile.SIZE_POW_2, GameView.mPaint);
                }
            }
        }
    }

    public void lock(GameEngine gameEngine) {
        startGame(gameEngine);
        mState = STATE_IMPASSABLE;
    }

    public void unlock(GameEngine gameEngine) {
        for(mCurrentLength--; mCurrentLength >= 0; mCurrentLength--) {
            if (mOrientation == ORIENTATION_HORIZONTAL) {
                for (int i = 0; i < mWidth; i++)
                    gameEngine.setTile(mTileX + mCurrentLength, mTileY + i, mOriginalTile[mCurrentLength][i]);
            } else {
                for (int i = 0; i < mWidth; i++)
                    gameEngine.setTile(mTileX + i, mTileY + mCurrentLength, mOriginalTile[mCurrentLength][i]);
            }
        }
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        mMatrix.reset();
        mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);
        canvas.drawBitmap(mBitmap, mMatrix, GameView.mPaint);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if (!GameEngine.isObjectVisible(mBoundingBox)) return;

        int distance;
        switch(mState) {
            case STATE_CLOSED_APPROACH:
                if(mOrientation == ORIENTATION_VERTICAL) {
                    if(mPassDirection == 1) {
                        distance = mX - gameEngine.mPlayer.mBoundingBox.right;
                        if(distance < 0) {
                            // already on the other side of the gate
                            gameEngine.setScrollLockX(mX + Tile.SIZE, -mPassDirection);
                            mState = STATE_IMPASSABLE;
                            return;
                        }
                        else gameEngine.setScrollLockX(mX + Tile.SIZE, mPassDirection);
                    }
                    else {
                        distance = gameEngine.mPlayer.mBoundingBox.left - (mX + Tile.SIZE * mWidth);
                        if(distance < 0) {
                            // already on the other side of the gate
                            gameEngine.setScrollLockX(mX + Tile.SIZE * (mWidth - 1), -mPassDirection);
                            mState = STATE_IMPASSABLE;
                            return;
                        }
                        else gameEngine.setScrollLockX(mX + Tile.SIZE * (mWidth - 1), mPassDirection);
                    }
                }
                else {
                    if(mPassDirection == 1) distance = mY - gameEngine.mPlayer.mBoundingBox.bottom;
                    else distance = gameEngine.mPlayer.mBoundingBox.top - (mY + Tile.SIZE * mWidth);
                }

                if(distance > 0 && distance < 10) {
                    // start opening gate
                    mState = STATE_OPENING;
                    mStateTimer = TILE_MILLIS;

                    // if the gate is horizontal, force player through it
                    if(mOrientation == ORIENTATION_VERTICAL) gameEngine.setStateGateScrollingX(this);
                }
                break;
            case STATE_OPENING:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= TILE_MILLIS) {
                    mStateTimer = 0;

                    if(mCurrentLength == mMaximumLength) gameEngine.soundPlay(GameEngine.GameSound.GATE);

                    mCurrentLength--;
                    if(mOrientation == ORIENTATION_HORIZONTAL) {
                        for(int i = 0; i < mWidth; i++) gameEngine.setTile(mTileX + mCurrentLength, mTileY + i, mOriginalTile[mCurrentLength][i]);
                    }
                    else {
                        for(int i = 0; i < mWidth; i++) gameEngine.setTile(mTileX + i, mTileY + mCurrentLength, mOriginalTile[mCurrentLength][i]);
                    }

                    buildBitmap();

                    if(mCurrentLength == 0) mState = STATE_OPEN;
                }
                break;
            case STATE_OPEN:
                if(mOrientation == ORIENTATION_VERTICAL) {
                    if(mPassDirection == 1) distance = gameEngine.mPlayer.mBoundingBox.left - (mX + (Tile.SIZE * mWidth));
                    else distance = mX - gameEngine.mPlayer.mBoundingBox.right;
                }
                else {
                    if(mPassDirection == 1) distance = gameEngine.mPlayer.mBoundingBox.top - (mY + (Tile.SIZE * mWidth));
                    else distance = mY - gameEngine.mPlayer.mBoundingBox.bottom;
                }

                if(distance > 0) {
                    // close gate
                    mState = STATE_CLOSING;
                    mStateTimer = TILE_MILLIS;
                }
                break;
            case STATE_CLOSING:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= TILE_MILLIS) {
                    mStateTimer = 0;

                    if(mCurrentLength == 0) gameEngine.soundPlay(GameEngine.GameSound.GATE);

                    if(mOrientation == ORIENTATION_HORIZONTAL) {
                        for(int i = 0; i < mWidth; i++) gameEngine.setTile(mTileX + mCurrentLength, mTileY + i, mSolidTile);
                    }
                    else {
                        for(int i = 0; i < mWidth; i++) gameEngine.setTile(mTileX + i, mTileY + mCurrentLength, mSolidTile);
                    }

                    mCurrentLength++;

                    buildBitmap();

                    if(mCurrentLength == mMaximumLength) {
                        mState = STATE_IMPASSABLE;
                        if(mOrientation == ORIENTATION_VERTICAL) {
                            if(mPassDirection == 1) gameEngine.setScrollLockX(mX + Tile.SIZE * (mWidth - 1), -mPassDirection);
                            else gameEngine.setScrollLockX(mX + Tile.SIZE, -mPassDirection);
                            gameEngine.setState(GameEngine.STATE_NORMAL);
                        }
                    }
                }
                break;
            case STATE_IMPASSABLE:
                // do nothing
                break;
        }
    }

    @Override
    public void startGame(GameEngine gameEngine) {
        mSolidTile = gameEngine.getTileSolid();
        if(mOrientation == ORIENTATION_HORIZONTAL) {
            for(int column = 0; column < mMaximumLength; column++) {
                for(int row = 0; row < mWidth; row++) {
                    mOriginalTile[column][row] = gameEngine.getTile(mTileX + column, mTileY + row);
                    gameEngine.setTile(mTileX + column, mTileY + row, mSolidTile);
                }
            }
        }
        else {
            for(int row = 0; row < mMaximumLength; row++) {
                for(int column = 0; column < mWidth; column++) {
                    mOriginalTile[row][column] = gameEngine.getTile(mTileX + column, mTileY + row);
                    gameEngine.setTile(mTileX + column, mTileY + row, mSolidTile);
                }
            }
        }
    }
}
