package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.R;

public class WeaponIce extends SpriteAnimatedMirrored {
    private final static int BOUNDING_BOX_OFFSET_X = 0;
    private final static int BOUNDING_BOX_OFFSET_Y = 0;
    private final static int BOUNDING_BOX_SIZE_X = 16;
    private final static int BOUNDING_BOX_SIZE_Y = 16;

    private final SpriteAnimatedMirroredWeapons mParent;

    private final static float VELOCITY_X = .25f;

    public WeaponIce(Resources resources, SpriteAnimatedMirroredWeapons parent) {
        super(BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        mFacingLeftAdjustmentX = BOUNDING_BOX_SIZE_X;
        mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(R.drawable.animation_weapon_ice, null));
        mParent = parent;

        mPlayerDamage = 16;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject != mParent);
    }

    public void init(int x, int y, int direction, GameEngine gameEngine) {
        mX = x;
        mXFractional = 0;
        mY = y;
        mYFractional = 0;
        updateBoundingBox();

        mDirection = direction;
        mVelocityX = VELOCITY_X * mDirection;

        gameEngine.soundPlay(GameEngine.GameSound.WEAPON_ICE);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mSpriteAnimation.onUpdate(elapsedMillis);

        final double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;
        updateBoundingBox();

        if(mX < GameView.mViewPort.left || mBoundingBox.right > GameView.mViewPort.right) {
            gameEngine.removeGameObject(this);
            mParent.weaponIceRelease(this);
        }
    }
}
