package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.R;

public class WeaponGuts extends SpriteFrameAnimation {
    private final static int BOUNDING_BOX_SIZE_X = 32;
    private final static int BOUNDING_BOX_SIZE_Y = 32;

    private final static float VELOCITY_X = .3f;

    private final static float VELOCITY_Y_GUTSMAN = -.15f;
    private final static float VELOCITY_Y_PLAYER = 0f;

    private final SpriteAnimatedMirroredWeapons mParent;

    private final WeaponGutsFragment[] mBlockThrowFragment = new WeaponGutsFragment[4];
    private final static int FRAGMENT_LIMIT = 4;
    private final boolean[] mFragmentReleased = {true, true, true, true};
    private boolean mFragmentsReleased = true;

    private final Rect mCenteringObject;

    private final static int STATE_PICKUP = 0;
    public final static int STATE_CARRYING = 1;
    private final static int STATE_START_THROW = 2;
    private final static int STATE_IN_AIR = 3;
    private final static int STATE_FRAGMENT = 4;
    private final static int STATE_WAIT_FOR_RELEASE = 5;
    private final static int STATE_SUMMONING = 6;
    public int mState = STATE_PICKUP;

    private final static int PICKUP_MILLIS = 50;
    private int mStateTimer = 0;

    public boolean mCanDamage = false;
    private boolean mVisible = true;

    final static int BLOCK_TYPE_ELEC = 0;
    final static int BLOCK_TYPE_CUT = 1;
    final static int BLOCK_TYPE_GUT = 2;
    final static int BLOCK_TYPE_WILY1 = 3;

    private boolean mGutsman = false;

    public WeaponGuts(Resources resources, Rect centeringObject, SpriteAnimatedMirroredWeapons parent) {
        super(0, 0, 32, 32, 4);

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_block_throw_elec);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_block_throw_cut);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_block_throw_gut);
        mFrames[3] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_block_throw_wily1);

        mParent = parent;
        mCenteringObject = centeringObject;
        for(int i = 0; i < FRAGMENT_LIMIT; i++) mBlockThrowFragment[i] = new WeaponGutsFragment(resources, i, this, parent);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && mCanDamage;
    }

    public void initPickup(int direction, int blockType) {
        mFrame = blockType;
        mState = STATE_PICKUP;
        mStateTimer = 0;
        mDirection = direction;
        mXFractional = 0;
        mYFractional = 0;
        if(direction == 1) {
            mX = mCenteringObject.centerX();
            mY = mCenteringObject.centerY() - (BOUNDING_BOX_SIZE_Y >> 1);
        }
        else {
            mX = mCenteringObject.centerX() - BOUNDING_BOX_SIZE_X;
            mY = mCenteringObject.centerY() - (BOUNDING_BOX_SIZE_Y >> 1);
        }
        updateBoundingBox();

        mVisible = true;
        mCanDamage = false;

        mGutsman = false;
    }

    public void initSummon() {
        mFrame = BLOCK_TYPE_GUT;
        mX = mCenteringObject.centerX() - 16;
        mY = GameView.mViewPort.top - 31;
        mXFractional = 0;
        mYFractional = 0;
        updateBoundingBox();

        mState = STATE_SUMMONING;
        mVelocityY = 0;

        mVisible = true;
        mCanDamage = true;

        mGutsman = true;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {}

    @Override
    public void onDraw(Canvas canvas) {
        if(mVisible) super.onDraw(canvas);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        switch(mState) {
            case STATE_PICKUP:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= PICKUP_MILLIS) {
                    mStateTimer = 0;
                    mState = STATE_CARRYING;
                    mX = mCenteringObject.left - ((mBoundingBox.width() - mCenteringObject.width()) >> 1);
                    mY = mCenteringObject.top - BOUNDING_BOX_SIZE_Y;
                    updateBoundingBox();
                }
                else {
                    if (mDirection == 1) {
                        mX = mCenteringObject.centerX();
                        mY = mCenteringObject.centerY() - BOUNDING_BOX_SIZE_Y;
                    } else {
                        mX = mCenteringObject.centerX() - BOUNDING_BOX_SIZE_X;
                        mY = mCenteringObject.centerY() - BOUNDING_BOX_SIZE_Y;
                    }
                    updateBoundingBox();
                }
                break;
            case STATE_CARRYING:
                mX = mCenteringObject.left - ((mBoundingBox.width() - mCenteringObject.width()) >> 1);
                mY = mCenteringObject.top - BOUNDING_BOX_SIZE_Y + 2;
                updateBoundingBox();
                break;
            case STATE_START_THROW:
                mVelocityX = VELOCITY_X * mDirection;
                if(mGutsman) mVelocityY = VELOCITY_Y_GUTSMAN;
                else mVelocityY = VELOCITY_Y_PLAYER;
                mState = STATE_IN_AIR;
                mCanDamage = true;
                break;
            case STATE_IN_AIR:
                final float oldVelocityX = mVelocityX;
                gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

                mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
                if(mVelocityY > GameEngine.TERMINAL_VELOCITY) mVelocityY = GameEngine.TERMINAL_VELOCITY;

                final float oldVelocityY = mVelocityY;
                gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);
                if((mVelocityX == 0 && Math.abs(oldVelocityX) > 0) || (mVelocityY == 0 && Math.abs(oldVelocityY) > 0)) {
                    // collision
                    mState = STATE_FRAGMENT;
                    mVelocityX = oldVelocityX;
                    mVelocityY = oldVelocityY;
                    mVisible = false;
                    mCanDamage = false;
                    gameEngine.soundPlay(GameEngine.GameSound.WEAPON_GUTS);
                    break;
                }
                break;
            case STATE_FRAGMENT:
                mFragmentsReleased = false;

                mBlockThrowFragment[0].init(mX, mY, mDirection, mVelocityX, mVelocityY, mFrame);
                mBlockThrowFragment[1].init(mX + 16, mY, mDirection, mVelocityX + .04f, mVelocityY, mFrame);
                mBlockThrowFragment[2].init(mX, mY + 16, mDirection, mVelocityX, mVelocityY + .04f, mFrame);
                mBlockThrowFragment[3].init(mX + 16, mY + 16, mDirection, mVelocityX + .04f, mVelocityY + .04f, mFrame);

                for(int i = 0; i < 4; i++) {
                    mFragmentReleased[i] = false;
                    gameEngine.addGameObject(mBlockThrowFragment[i]);
                }

                mState = STATE_WAIT_FOR_RELEASE;
                break;
            case STATE_WAIT_FOR_RELEASE:
                if(mFragmentsReleased) {
                    gameEngine.removeGameObject(this);
                    mParent.weaponGutsRelease(this);
                }
                break;
            case STATE_SUMMONING:
                // wait for it to fall and be caught by gutsman
                mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
                if(mVelocityY > GameEngine.TERMINAL_VELOCITY) mVelocityY = GameEngine.TERMINAL_VELOCITY;
                mY += mVelocityY * elapsedMillis;
                updateBoundingBox();

                if(mBoundingBox.bottom >= mCenteringObject.top) {
                    mStateTimer = 0;
                    mState = STATE_CARRYING;
                    mX = mCenteringObject.left - ((mBoundingBox.width() - mCenteringObject.width()) >> 1);
                    mY = mCenteringObject.top - BOUNDING_BOX_SIZE_Y;
                    updateBoundingBox();
                }
                break;
        }
    }

    void releaseFragment(int index) {
        mFragmentReleased[index] = true;
        if(mFragmentReleased[0] && mFragmentReleased[1] && mFragmentReleased[2] && mFragmentReleased[3]) mFragmentsReleased = true;
    }

    @Override
    public void startGame(GameEngine gameEngine) {
    }

    public void triggerThrow(int direction) {
        if(mState == STATE_CARRYING) {
            mState = STATE_START_THROW;
            mDirection = direction;
        }
    }
}
