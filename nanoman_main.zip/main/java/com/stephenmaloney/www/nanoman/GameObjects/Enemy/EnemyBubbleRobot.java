package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class EnemyBubbleRobot extends GameObject {
    public final static String TYPE = "EnemyBubbleRobot";

    private final Rect mBoundingBox;

    private final EnemyBubbleRobotDrone mDrone;

    private final static int STATE_WAIT_FOR_VISIBLE = 0;
    private final static int STATE_DELAY_SPAWN = 1;
    private final static int STATE_SPAWN_DRONE = 2;
    private final static int STATE_WAIT_FOR_DRONE_DEATH = 3;
    private final static int STATE_DEATH = 4;
    private int mState = STATE_WAIT_FOR_VISIBLE;
    private int mStateTimer = 0;

    private final EnemyHealthBar mHealthBar;
    private boolean mHealthBarVisible = false;

    private float mVelocityMultiplier = 1;

    public EnemyBubbleRobot(Resources resources, HashMap<String, String> properties, Rect playerLocation) {
        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;
        mBoundingBox = new Rect(x, y, x + Tile.SIZE, y + Tile.SIZE);
        mHealthBar = new EnemyHealthBar(resources);
        mDrone = new EnemyBubbleRobotDrone(resources, playerLocation, x, y, this);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            if(mHealthBarVisible) {
                mHealthBarVisible = false;
                gameEngine.removeGameObject(mHealthBar);
            }
            return;
        }

        if(!mHealthBarVisible) {
            mHealthBarVisible = true;
            gameEngine.addGameObject(mHealthBar);
            gameEngine.musicPlayLooped(R.raw.music_wily_boss_theme);
        }

        switch(mState) {
            case STATE_WAIT_FOR_VISIBLE:
                mState = STATE_SPAWN_DRONE;
                break;
            case STATE_DELAY_SPAWN:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    mState = STATE_SPAWN_DRONE;
                }
                break;
            case STATE_SPAWN_DRONE:
                mDrone.init(mVelocityMultiplier);
                mVelocityMultiplier += .3;
                gameEngine.addGameObject(mDrone);
                mState = STATE_WAIT_FOR_DRONE_DEATH;
                break;
            case STATE_WAIT_FOR_DRONE_DEATH:
                break;
            case STATE_DEATH:
                gameEngine.mPlayer.warpOut(Player.WARP_DESTINATION_WILY4);
                gameEngine.removeGameObject(this);
                gameEngine.soundPlay(GameEngine.GameSound.PLAYER_DEATH);
                gameEngine.musicPlayOnce(R.raw.music_victory);
                break;
        }
    }

    void releaseDrone() {
        mHealthBar.remove(10);
        if(mHealthBar.isEmpty()) mState = STATE_DEATH;
        else {
            mState = STATE_DELAY_SPAWN;
            mStateTimer = 500;
        }
    }
}
