package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

class EnemyYellowDemonShot extends EnemyShot {
    private final EnemyYellowDemonEye mParent;

    EnemyYellowDemonShot(Resources resources, int resource_id, EnemyYellowDemonEye parent) {
        super(resources, resource_id);
        mParent = parent;
    }

    void init(int x, int y, int direction, GameEngine gameEngine) {
        mDirection = direction;

        final double dx = gameEngine.mPlayer.mBoundingBox.centerX() - mBoundingBox.centerX();
        final double dy = mBoundingBox.centerY() - gameEngine.mPlayer.mBoundingBox.centerY();
        double angle = Math.atan2(dy, dx);
        if(angle < 0) angle = Math.abs(angle);
        else angle = 2 * Math.PI - angle;

        mVelocityX = .2f * (float)Math.cos(angle);
        mVelocityY = .2f * (float)Math.sin(angle);

        mX = x;
        mY = y;
        mXFractional = 0;
        mYFractional = 0;
        updateBoundingBox();

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_SHOOT);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            mParent.releaseShot();
            gameEngine.removeGameObject(this);
        }

        super.onUpdate(elapsedMillis, gameEngine);
    }
}
