package com.stephenmaloney.www.nanoman.GameObjects.Player;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBigeye;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBombman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBubbleRobotDrone;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBubbleRobotShot;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyClone;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyCutman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyEyePatrol;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFireman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFlameHead;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFlyingNut;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFootHolder;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyGutsman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyHelicopter;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyHelmet;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyIceman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyMiner;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyMinerPickAxe;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyMissile;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyPenguin;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyRobotHead;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyRobotLegs;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyScissors;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyShieldSoldier;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyWily;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyWilyGun;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyWilyPropeller;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyWilyShot1;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyWilyShot2;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyWilyWeakness;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyYellowDemonParticle;
import com.stephenmaloney.www.nanoman.GameObjects.FlameHazard;
import com.stephenmaloney.www.nanoman.GameObjects.FlameHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.FlamePillar;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.WeaponMagnetPickup;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.WeaponPickup;
import com.stephenmaloney.www.nanoman.GameObjects.StageSelect;
import com.stephenmaloney.www.nanoman.GameObjects.Tram;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsBlock;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.DeathExplosion;
import com.stephenmaloney.www.nanoman.GameObjects.Electricity;
import com.stephenmaloney.www.nanoman.GameObjects.ElectricityMini;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyAlien;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyAngleShooter;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBomber;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBomberShot;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyElecman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyJumper;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyShot;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemySlider;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemySpinner;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.AmmoLarge;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.AmmoSmall;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.HealthLarge;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.HealthSmall;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.OneUp;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricity;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFire;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponMagnet;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponSelect;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.List;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public class Player extends SpriteAnimatedMirroredWeapons {
    private final static float CLIMB_VELOCITY = .05f;
    private final static float CLIMB_TOP_VELOCITY = .1f;
    private final static float JUMP_VELOCITY = -0.22f;

    private final static float GRAVITY_NORMAL_ACCELERATION = .0011f;
    private final static float GRAVITY_NORMAL_TERMINAL_VELOCITY = .6f;

    private final static float GRAVITY_WATER_ACCELERATION = .0005f;
    private final static float GRAVITY_WATER_TERMINAL_VELOCITY = .3f;
    
    private final static float WALK_NORMAL_ACCELERATION = .0012f;
    private final static float FRICTION_NORMAL_ACCELERATION = .0006f;
    private final static float WALK_NORMAL_MAX_VELOCITY = .08f;

    private final static float WALK_ICE_ACCELERATION = .0002f;
    private final static float FRICTION_ICE_ACCELERATION = .00007f;

    private final static float WALK_WATER_ACCELERATION = .0008f;
    private final static float FRICTION_WATER_ACCELERATION = .0005f;
    private final static float WALK_WATER_MAX_VELOCITY = .06f;

    private final static float HURT_VELOCITY = .15f;
    private final static float WARP_VELOCITY = 0.5f;

    private final static int JUMP_AUTORELEASE_MILLIS = 140;
    private final static int HURT_INVINCIBILITY_MILLIS = 2000;
    private final static int HURT_BLINK_ON_MILLIS = 40;
    private final static int HURT_BLINK_OFF_MILLIS = 40;
    private final static int DEATH_MILLIS = 3000;

    private final static int BOUNDING_BOX_SIZE_X = 12;
    private final static int BOUNDING_BOX_SIZE_Y = 24;
    public final static int BOUNDING_BOX_OFFSET_X = 8;
    private final static int BOUNDING_BOX_OFFSET_Y = 0;

    private final static int FACING_LEFT_ADJUSTMENT_X = 28;

    private final static int STATE_STAND = 0;
    private final static int STATE_STAND_CARRY = 1;
    private final static int STATE_STAND_TO_WALK = 2;
    private final static int STATE_STAND_SHOOT = 3;
    private final static int STATE_STAND_THROW = 4;
    private final static int STATE_WALK = 5;
    private final static int STATE_WALK_CARRY = 6;
    private final static int STATE_WALK_SHOOT = 7;
    private final static int STATE_LEAN = 8;
    private final static int STATE_JUMP = 9;
    private final static int STATE_JUMP_CARRY = 10;
    private final static int STATE_JUMP_SHOOT = 11;
    private final static int STATE_JUMP_THROW = 12;
    private final static int STATE_CLIMB1 = 13;
    private final static int STATE_CLIMB2 = 14;
    private final static int STATE_CLIMB_TOP = 15;
    private final static int STATE_CLIMB_SHOOT = 16;
    private final static int STATE_CLIMB_THROW = 17;
    private final static int STATE_HURT = 18;
    private final static int STATE_WARP_IN = 19;
    private final static int STATE_WARP_LAND = 20;
    private final static int STATE_WARP_RISE = 21;
    private final static int STATE_FALLEN_DOWN = 22;

    // state variables
    public boolean mClimbing = false;
    public boolean mClimbTop = false;

    private boolean mDead = false;
    private final List<DeathExplosion> mDeathExplosions = new ArrayList<>();
    private final static int DEATH_EXPLOSION_LIMIT = 16;
    private int mDeathTimer = 0;

    private boolean mHurtNoControl = false;
    private boolean mHurtInvincible = false;
    private int mHurtInvincibleTimer = 0;
    private boolean mVisible = true;
    private int mHurtBlinkTimer = 0;

    private boolean mJumpOnThisPress = false;
    public int mJumpReleaseTimer = -1;

    private boolean mShotOnThisPress = false;
    private int mWalkShootTimer = 0;

    private boolean mWarpingDown = false;
    private boolean mWarpingUp = false;
    private int mWarpDestination;

    public final static int WARP_DESTINATION_STAGE_SELECT = 0;
    public final static int WARP_DESTINATION_WILY2 = 1;
    public final static int WARP_DESTINATION_WILY3 = 2;
    public final static int WARP_DESTINATION_WILY4 = 3;

    public boolean mCheckPointSet = false;
    public int mStartPositionX;
    public int mStartPositionY;
    public int mStartDirection;

    private boolean mOnMagnet = false;
    private int mMagnetMultiplier = 0;
    private int mMagnetTimer = 0;

    public boolean mOnTram = false;
    public float mTramVelocity;

    public boolean mOnFootHolder = false;
    public EnemyFootHolder mFootHolder;

    private boolean mCanPickupBlock = false;
    private boolean mCarryingBlock = false;
    private WeaponGutsBlock mBlockThrow;

    public boolean mOnIce = false;
    public boolean mInWater = false;
    private boolean mInWaterLastCheck = false;

    public float mPushVelocity = 0;

    // weapons
    public final static int WEAPON_BOMB = 0;
    public final static int WEAPON_CUTTER = 1;
    public final static int WEAPON_ELECTRICITY = 2;
    public final static int WEAPON_FIRE = 3;
    public final static int WEAPON_GUTS = 4;
    public final static int WEAPON_ICE = 5;
    public final static int WEAPON_MAGNET = 6;
    public final static int WEAPON_PSHOT = 7;
    public int mWeaponSelected = WEAPON_PSHOT;

    private final static int WEAPON_BOMB_AMMO_PER_SHOT = 8;
    private final static int WEAPON_CUTTER_AMMO_PER_SHOT = 12;
    private final static int WEAPON_ELECTRICITY_AMMO_PER_SHOT = 8;
    private final static int WEAPON_FIRE_AMMO_PER_SHOT = 4;
    private final static int WEAPON_GUTS_AMMO_PER_SHOT = 8;
    private final static int WEAPON_ICE_AMMO_PER_SHOT = 4;
    private final static int WEAPON_MAGNET_AMMO_PER_SHOT = 2;

    private final List<WeaponBomb> mWeaponBomb = new ArrayList<>();
    private final static int WEAPON_BOMB_LIMIT = 2;

    private final List<WeaponCutter> mWeaponCutter = new ArrayList<>();
    private final static int WEAPON_CUTTER_LIMIT = 1;

    private final List<WeaponElectricity> mWeaponElectricity = new ArrayList<>();
    private final static int WEAPON_ELECTRICITY_LIMIT = 1;

    private final List<WeaponFire> mWeaponFire = new ArrayList<>();
    private final static int WEAPON_FIRE_LIMIT = 2;

    private final WeaponGuts mWeaponGuts;
    private boolean mWeaponGutsReleased = true;

    private final List<WeaponIce> mWeaponIce = new ArrayList<>();
    private final static int WEAPON_ICE_LIMIT = 2;

    private final List<WeaponMagnet> mWeaponMagnet = new ArrayList<>();
    private final static int WEAPON_MAGNET_LIMIT = 20;

    private final List<WeaponPShot> mWeaponPShots = new ArrayList<>();
    private final static int WEAPON_PSHOT_LIMIT = 3;

    public final WeaponSelect mWeaponSelect;

    private final PlayerAmmoBars mAmmoBars;
    private final PlayerHealthBar mHealthBar;

    private final PlayerAnimationSet mAnimations;

    private boolean mTeleporting;
    private int mTeleportDestinationX;
    private int mTeleportDestinationY;

    public Player(Resources resources) {
        super(resources, BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        mFacingLeftAdjustmentX = FACING_LEFT_ADJUSTMENT_X;

        // set up player animation states
        mAnimations = new PlayerAnimationSet(resources);

        // set up bomb
        for(int i = 0; i < WEAPON_BOMB_LIMIT; i++) mWeaponBomb.add(new WeaponBomb(resources, this, false));

        // set up cutter
        for(int i = 0; i < WEAPON_CUTTER_LIMIT; i++) mWeaponCutter.add(new WeaponCutter(resources, this));

        // set up electricity
        for(int i = 0; i < WEAPON_ELECTRICITY_LIMIT; i++) mWeaponElectricity.add(new WeaponElectricity(resources, this));

        // set up fire
        for(int i = 0; i < WEAPON_FIRE_LIMIT; i++) mWeaponFire.add(new WeaponFire(resources, this));

        // set up guts
        mWeaponGuts = new WeaponGuts(resources, mBoundingBox, this);

        // set up ice
        for(int i = 0; i < WEAPON_ICE_LIMIT; i++) mWeaponIce.add(new WeaponIce(resources, this));

        // set up magnet
        for(int i = 0; i < WEAPON_MAGNET_LIMIT; i++) mWeaponMagnet.add(new WeaponMagnet(resources, this));

        // set up p shots
        for(int i = 0; i < WEAPON_PSHOT_LIMIT; i++) mWeaponPShots.add(new WeaponPShot(resources, this));

        // set up death explosions
        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) mDeathExplosions.add(new DeathExplosion(resources, R.drawable.animation_player_death, i));

        // set up bars
        mAmmoBars = new PlayerAmmoBars(resources);
        mHealthBar = new PlayerHealthBar(resources);

        // create weapon select
        mWeaponSelect = new WeaponSelect(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        if(!Rect.intersects(mBoundingBox, otherObject.mBoundingBox)) return false;

        if(otherObject instanceof HealthSmall
                || otherObject instanceof HealthLarge
                || otherObject instanceof AmmoSmall
                || otherObject instanceof AmmoLarge
                || otherObject instanceof OneUp
                || otherObject instanceof WeaponMagnet
                || otherObject instanceof WeaponGutsBlock
                || otherObject instanceof WeaponPickup
                || otherObject instanceof WeaponMagnetPickup
                || (otherObject instanceof Tram  && ((Tram) otherObject).mFrame == Tram.STATE_SUPPORT)
                || otherObject instanceof EnemyFootHolder) return true;

        if(!mHurtInvincible) {
            if (otherObject instanceof Electricity) {
                if (((Electricity) otherObject).mOn) return true;
            }
            else if (otherObject instanceof EnemySlider
                    || otherObject instanceof EnemyAlien
                    || otherObject instanceof EnemyBomber
                    || otherObject instanceof EnemyBomberShot
                    || otherObject instanceof EnemyElecman
                    || otherObject instanceof EnemyFireman
                    || otherObject instanceof EnemyGutsman
                    || otherObject instanceof EnemySpinner
                    || otherObject instanceof EnemyShot
                    || otherObject instanceof EnemyAngleShooter
                    || otherObject instanceof EnemyShieldSoldier
                    || otherObject instanceof EnemyMissile
                    || otherObject instanceof EnemyFlyingNut
                    || otherObject instanceof EnemyEyePatrol
                    || otherObject instanceof EnemyBombman
                    || otherObject instanceof EnemyClone
                    || otherObject instanceof EnemyScissors
                    || otherObject instanceof EnemyHelicopter
                    || otherObject instanceof EnemyBigeye
                    || otherObject instanceof EnemyCutman
                    || otherObject instanceof EnemyHelmet
                    || otherObject instanceof EnemyMiner
                    || otherObject instanceof EnemyMinerPickAxe
                    || otherObject instanceof EnemyRobotHead
                    || otherObject instanceof EnemyRobotLegs
                    || otherObject instanceof EnemyPenguin
                    || otherObject instanceof EnemyIceman
                    || otherObject instanceof EnemyFlameHead
                    || otherObject instanceof EnemyJumper
                    || otherObject instanceof EnemyYellowDemonParticle
                    || otherObject instanceof EnemyBubbleRobotDrone
                    || otherObject instanceof EnemyBubbleRobotShot
                    || otherObject instanceof EnemyWily
                    || otherObject instanceof EnemyWilyGun
                    || otherObject instanceof EnemyWilyPropeller
                    || otherObject instanceof EnemyWilyShot1
                    || otherObject instanceof EnemyWilyWeakness
                    || otherObject instanceof EnemyWilyShot2

                    || otherObject instanceof ElectricityMini
                    || otherObject instanceof FlamePillar
                    || otherObject instanceof FlameHazard
                    || otherObject instanceof FlameHorizontal

                    || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                    || (otherObject instanceof WeaponCutter && ((WeaponCutter) otherObject).mParent != this)
                    || (otherObject instanceof WeaponElectricityHorizontal && ((WeaponElectricityHorizontal) otherObject).mParent != this)
                    || (otherObject instanceof WeaponElectricityVertical && ((WeaponElectricityVertical) otherObject).mParent != this)
                    || (otherObject instanceof WeaponFireHorizontal && ((WeaponFireHorizontal) otherObject).mParent != this)
                    || (otherObject instanceof WeaponFireSpinner && ((WeaponFireSpinner) otherObject).mParent != this)
                    || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage)
                    || (otherObject instanceof WeaponGutsFragment && ((WeaponGutsFragment) otherObject).mParent != this)
                    || otherObject instanceof WeaponIce
                    || otherObject instanceof WeaponPShot)

                return true;
        }

        return false;
    }

    public void knockOver() {
        // if not in air, knock player over
        if(mOnGround) {
            mAnimations.setState(STATE_FALLEN_DOWN, true);
            mHurtNoControl = true;
        }
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(!mHurtInvincible && (otherObject instanceof Electricity
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponPShot
                || otherObject instanceof ElectricityMini
                || otherObject instanceof EnemySlider
                || otherObject instanceof EnemyAlien
                || otherObject instanceof EnemyJumper
                || otherObject instanceof EnemyElecman
                || otherObject instanceof EnemyGutsman
                || otherObject instanceof EnemyFireman
                || otherObject instanceof EnemyBomber
                || otherObject instanceof EnemyBomberShot
                || otherObject instanceof EnemyShot
                || otherObject instanceof EnemyAngleShooter
                || otherObject instanceof EnemyShieldSoldier
                || otherObject instanceof EnemyMissile
                || otherObject instanceof EnemyFlyingNut
                || otherObject instanceof EnemyEyePatrol
                || otherObject instanceof EnemyBombman
                || otherObject instanceof EnemyHelicopter
                || otherObject instanceof EnemyScissors
                || otherObject instanceof EnemyBigeye
                || otherObject instanceof EnemyCutman
                || otherObject instanceof EnemyClone
                || otherObject instanceof EnemyHelmet
                || otherObject instanceof EnemyMinerPickAxe
                || otherObject instanceof EnemyRobotHead
                || otherObject instanceof EnemyRobotLegs
                || otherObject instanceof EnemyPenguin
                || otherObject instanceof EnemyIceman
                || otherObject instanceof EnemyFlameHead
                || otherObject instanceof FlameHorizontal
                || otherObject instanceof EnemyYellowDemonParticle
                || otherObject instanceof EnemyBubbleRobotDrone
                || otherObject instanceof EnemyBubbleRobotShot
                || otherObject instanceof EnemyWily
                || otherObject instanceof EnemyWilyPropeller
                || otherObject instanceof EnemyWilyGun
                || otherObject instanceof EnemyWilyShot1
                || otherObject instanceof EnemyWilyWeakness
                || otherObject instanceof EnemyWilyShot2)) {

            mHealthBar.remove(otherObject.mPlayerDamage);
            if(mHealthBar.isEmpty()) onDeath(gameEngine);
            else onHurt(otherObject.mDirection, gameEngine);
        }
        else if(!mHurtInvincible && otherObject instanceof EnemySpinner) {
            mHealthBar.remove(otherObject.mPlayerDamage);
            if(mHealthBar.isEmpty()) onDeath(gameEngine);
            else onHurt(mDirection * -1, gameEngine);
        }
        else if(!mHurtInvincible && (otherObject instanceof EnemyMiner || otherObject instanceof FlamePillar || otherObject instanceof FlameHazard)) {
            mHealthBar.remove(otherObject.mPlayerDamage);
            if(mHealthBar.isEmpty()) onDeath(gameEngine);
            else onHurt(otherObject.mBoundingBox.centerX() < mBoundingBox.centerX()? 1 : -1, gameEngine);
        }
        else if(otherObject instanceof HealthLarge) {
            if(mHealthBar.isFull()) gameEngine.soundPlay(GameEngine.GameSound.METER_ADD);
            else mHealthBar.add(((HealthLarge)otherObject).mHealth);
            gameEngine.removeGameObject(otherObject);

        }
        else if(otherObject instanceof HealthSmall) {
            if(mHealthBar.isFull()) gameEngine.soundPlay(GameEngine.GameSound.METER_ADD);
            else mHealthBar.add(((HealthSmall) otherObject).mHealth);
            gameEngine.removeGameObject(otherObject);
        }
        else if(otherObject instanceof AmmoSmall) {
            if(mWeaponSelected == WEAPON_PSHOT) {
                gameEngine.soundPlay(GameEngine.GameSound.METER_ADD);
                for(int i = 0; i < 7; i++) {
                    if(mWeaponSelect.mHorizontalAmmoBars[i].mValue < PlayerAmmoBars.AMMO_MAX) {
                        mAmmoBars.addInstant(AmmoSmall.AMMO, i);
                        mWeaponSelect.mHorizontalAmmoBars[i].add(AmmoSmall.AMMO);
                        break;
                    }
                }
            }
            else {
                if(mAmmoBars.isFull()) gameEngine.soundPlay(GameEngine.GameSound.METER_ADD);
                else {
                    mAmmoBars.add(AmmoSmall.AMMO);
                    mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].add(AmmoSmall.AMMO);
                }
            }
            gameEngine.removeGameObject(otherObject);
        }
        else if(otherObject instanceof AmmoLarge) {
            if(mWeaponSelected == WEAPON_PSHOT) {
                gameEngine.soundPlay(GameEngine.GameSound.METER_ADD);
                for(int i = 0; i < 7; i++) {
                    if(mWeaponSelect.mHorizontalAmmoBars[i].mValue < PlayerAmmoBars.AMMO_MAX) {
                        mAmmoBars.addInstant(AmmoLarge.AMMO, i);
                        mWeaponSelect.mHorizontalAmmoBars[i].add(AmmoLarge.AMMO);
                        break;
                    }
                }
            }
            else {
                if(mAmmoBars.isFull()) gameEngine.soundPlay(GameEngine.GameSound.METER_ADD);
                else {
                    mAmmoBars.add(AmmoLarge.AMMO);
                    mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].add(AmmoLarge.AMMO);
                }
            }
            gameEngine.removeGameObject(otherObject);
        }
        else if(otherObject instanceof OneUp) {
            mWeaponSelect.mLives++;
            gameEngine.removeGameObject(otherObject);
            gameEngine.soundPlay(GameEngine.GameSound.ONE_UP);
        }
        else if(otherObject instanceof WeaponPickup) {
            // picked up boss weapon
            mWeaponSelect.mSelectionPresent[((WeaponPickup) otherObject).mType] = true;
            gameEngine.progressSave();
            gameEngine.removeGameObject(otherObject);

            gameEngine.musicPlayOnce(R.raw.music_victory);

            // warp out of the level
            warpOut(WARP_DESTINATION_STAGE_SELECT);
        }
        else if(otherObject instanceof WeaponMagnetPickup) {
            // picked up magnet
            mWeaponSelect.mSelectionPresent[WEAPON_MAGNET] = true;
            gameEngine.progressSave();
            gameEngine.removeGameObject(otherObject);
            gameEngine.soundPlay(GameEngine.GameSound.ONE_UP);
        }
        else if(otherObject instanceof WeaponMagnet) {
            if(mVelocityY >= 0 && mBoundingBox.bottom <= otherObject.mBoundingBox.bottom) {
                mY = otherObject.mY - mBoundingBox.height() + 1;
                mYFractional = otherObject.mYFractional;
                mVelocityY = 0;
                mOnMagnet = true;
                mOnIce = false;
                if(mAnimations.mState == STATE_JUMP) mAnimations.setState(STATE_STAND, true);
                else if(mAnimations.mState == STATE_JUMP_CARRY) mAnimations.setState(STATE_STAND_CARRY, true);
            }
        }
        else if(otherObject instanceof Tram) {
            if(mVelocityY >= 0 && mBoundingBox.bottom <= otherObject.mBoundingBox.bottom) {
                mY = otherObject.mY - mBoundingBox.height() + 1;
                mYFractional = otherObject.mYFractional;
                mVelocityY = 0;
                mOnTram = true;
                mOnIce = false;
                mTramVelocity = ((Tram) otherObject).mVelocityX;
                if(mAnimations.mState == STATE_JUMP) mAnimations.setState(STATE_STAND, true);
                else if(mAnimations.mState == STATE_JUMP_CARRY) mAnimations.setState(STATE_STAND_CARRY, true);
            }
        }
        else if(otherObject instanceof EnemyFootHolder) {
            if(mVelocityY >= 0 && mBoundingBox.bottom <= otherObject.mBoundingBox.bottom) {
                mY = otherObject.mY - mBoundingBox.height() + 1;
                mYFractional = otherObject.mYFractional;
                mVelocityY = 0;
                mOnFootHolder = true;
                mFootHolder = (EnemyFootHolder) otherObject;
                mOnIce = false;
                if(mAnimations.mState == STATE_JUMP) mAnimations.setState(STATE_STAND, true);
                else if(mAnimations.mState == STATE_JUMP_CARRY) mAnimations.setState(STATE_STAND_CARRY, true);
            }
        }
        else if(otherObject instanceof WeaponGutsBlock) {
            mCanPickupBlock = true;
            mBlockThrow = (WeaponGutsBlock)otherObject;
        }
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mVisible) {
            mMatrix.reset();
            if (mDirection == -1) {
                mMatrix.postScale(-1, 1);
                mMatrix.postTranslate(mFacingLeftAdjustmentX, 0);
            }
            mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);

            canvas.drawBitmap(mAnimations.getBitmap(), mMatrix, GameView.mPaint);
        }

        if(mWeaponSelected != WEAPON_PSHOT) mAmmoBars.onDraw(canvas);
        mHealthBar.onDraw(canvas);
    }

    public void onDeath(GameEngine gameEngine) {
        mHurtInvincible = true;
        mHealthBar.remove(PlayerHealthBar.HEALTH_MAX);
        mDead = true;
        mVisible = false;
        mDeathTimer = 0;
        mWeaponSelect.mLives--;
        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) {
            DeathExplosion exp = mDeathExplosions.get(i);
            exp.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(exp);
        }
        gameEngine.soundPlay(GameEngine.GameSound.PLAYER_DEATH);
        gameEngine.musicPause();
    }

    private void onHurt(int pushDirection, GameEngine gameEngine) {
        // set hurt flags
        mHurtNoControl = true;
        mHurtInvincible = true;

        // fall if climbing
        mClimbing = false;
        mClimbTop = false;

        // set hurt animation
        mAnimations.setState(STATE_HURT, true);

        // set hurt "knock back"
        mVelocityX = pushDirection * HURT_VELOCITY;

        // play hurt sound
        gameEngine.soundPlay(GameEngine.GameSound.PLAYER_DAMAGE);

        // create dust
        dustAdd(gameEngine);
    }

    private void onShoot(GameEngine gameEngine) {
        switch(mWeaponSelected) {
            case WEAPON_BOMB:
                final WeaponBomb weaponBomb = weaponBombGet();
                if(weaponBomb == null) return;
                if(mDirection == 1) weaponBomb.init(mBoundingBox.right + 8, mBoundingBox.top + 6, mDirection, mVelocityX * .7f, mVelocityY * .7f);
                else weaponBomb.init(mBoundingBox.left - 22, mBoundingBox.top + 6, mDirection, mVelocityX * .7f, mVelocityY * .7f);
                gameEngine.addGameObject(weaponBomb);
                break;
            case WEAPON_CUTTER:
                final WeaponCutter weaponCutter = weaponCutterGet();
                if(weaponCutter == null) return;
                if(mDirection == 1) weaponCutter.init(mBoundingBox.right + 8, mBoundingBox.centerY(), mDirection, gameEngine);
                else weaponCutter.init(mBoundingBox.left - 22, mBoundingBox.centerY(), mDirection, gameEngine);
                gameEngine.addGameObject(weaponCutter);
                break;
            case WEAPON_ELECTRICITY:
                final WeaponElectricity weaponElectricity = weaponElectricityGet();
                if(weaponElectricity == null) return;
                if(mDirection == 1) weaponElectricity.init(mBoundingBox.right + 14, mBoundingBox.top - 9, mDirection);
                else weaponElectricity.init(mBoundingBox.left - 47, mBoundingBox.top - 9, mDirection);
                weaponElectricity.addGameObjects(gameEngine);
                break;
            case WEAPON_FIRE:
                final WeaponFire weaponFire = weaponFireGet();
                if(weaponFire == null) return;
                if(mDirection == 1) weaponFire.init(mX + 35, mY + 3, mDirection);
                else weaponFire.init(mX - 20, mY + 3, mDirection);
                weaponFire.addGameObjects(gameEngine);
                break;
            case WEAPON_GUTS:
                if(mCanPickupBlock && !mCarryingBlock && mWeaponGutsReleased && mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].mValue > 0) {
                    // remove ammo
                    mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].remove(WEAPON_GUTS_AMMO_PER_SHOT);
                    mAmmoBars.remove(WEAPON_GUTS_AMMO_PER_SHOT);

                    // pickup block - clear it out
                    mBlockThrow.pickup(gameEngine);

                    // initPickup weapon
                    mWeaponGuts.initPickup(mDirection, mBlockThrow.mType);
                    gameEngine.addGameObject(mWeaponGuts);
                    mCarryingBlock = true;

                    mAnimations.setState(STATE_STAND_CARRY, true);
                    return;
                }
                else if(mCarryingBlock) {
                    mCarryingBlock = false;
                    mWeaponGuts.triggerThrow(mDirection);
                }
                else return;
                break;
            case WEAPON_ICE:
                final WeaponIce weaponIce = weaponIceGet();
                if(weaponIce == null) return;
                if(mDirection == 1) weaponIce.init(mX + 35, mY + 3, mDirection, gameEngine);
                else weaponIce.init(mX - 20, mY + 3, mDirection, gameEngine);
                gameEngine.addGameObject(weaponIce);
                break;
            case WEAPON_MAGNET:
                final WeaponMagnet weaponMagnet = weaponMagnetGet();
                if(weaponMagnet == null) return;
                if(mDirection == 1) weaponMagnet.init(mX + 35 + (16 * mMagnetMultiplier), mY + 8, gameEngine);
                else weaponMagnet.init(mX - 23 - (16 * mMagnetMultiplier), mY + 8, gameEngine);
                mMagnetMultiplier++;
                gameEngine.addGameObject(weaponMagnet);
                break;
            case WEAPON_PSHOT:
                if(!mWeaponPShots.isEmpty()) {
                    final WeaponPShot pShot = mWeaponPShots.remove(0);
                    pShot.init(mX + 30, mY + 8, mDirection, gameEngine);
                    gameEngine.addGameObject(pShot);
                }
                break;
        }

        switch(mAnimations.mState) {
            case STATE_WALK:
            case STATE_WALK_CARRY:
                switch(mWeaponSelected) {
                    case WEAPON_ELECTRICITY:
                    case WEAPON_FIRE:
                    case WEAPON_ICE:
                    case WEAPON_MAGNET:
                    case WEAPON_PSHOT:
                        mAnimations.setState(STATE_WALK_SHOOT, false);
                        break;
                    case WEAPON_BOMB:
                    case WEAPON_CUTTER:
                    case WEAPON_GUTS:
                        mAnimations.setState(STATE_STAND_THROW, true);
                        break;
                }
                break;
            case STATE_WALK_SHOOT:
                mAnimations.setState(STATE_WALK_SHOOT, false);
                break;
            case STATE_JUMP:
            case STATE_JUMP_CARRY:
                switch(mWeaponSelected) {
                    case WEAPON_ELECTRICITY:
                    case WEAPON_FIRE:
                    case WEAPON_ICE:
                    case WEAPON_MAGNET:
                    case WEAPON_PSHOT:
                        mAnimations.setState(STATE_JUMP_SHOOT, true);
                        break;
                    case WEAPON_BOMB:
                    case WEAPON_CUTTER:
                    case WEAPON_GUTS:
                        mAnimations.setState(STATE_JUMP_THROW, true);
                        break;
                }
                break;
            case STATE_JUMP_SHOOT:
                mAnimations.setState(STATE_JUMP_SHOOT, true);
                break;
            case STATE_CLIMB1:
            case STATE_CLIMB2:
                switch(mWeaponSelected) {
                    case WEAPON_ELECTRICITY:
                    case WEAPON_FIRE:
                    case WEAPON_ICE:
                    case WEAPON_MAGNET:
                    case WEAPON_PSHOT:
                        mAnimations.setState(STATE_CLIMB_SHOOT, true);
                        break;
                    case WEAPON_BOMB:
                    case WEAPON_CUTTER:
                    case WEAPON_GUTS:
                        mAnimations.setState(STATE_CLIMB_THROW, true);
                        break;
                }
                break;
            case STATE_CLIMB_SHOOT:
                mAnimations.setState(STATE_CLIMB_SHOOT, true);
                break;
            case STATE_STAND:
            case STATE_STAND_CARRY:
            case STATE_STAND_TO_WALK:
            case STATE_LEAN:
            case STATE_CLIMB_TOP:
                switch(mWeaponSelected) {
                    case WEAPON_ELECTRICITY:
                    case WEAPON_FIRE:
                    case WEAPON_ICE:
                    case WEAPON_MAGNET:
                    case WEAPON_PSHOT:
                        mAnimations.setState(STATE_STAND_SHOOT, true);
                        break;
                    case WEAPON_BOMB:
                    case WEAPON_CUTTER:
                    case WEAPON_GUTS:
                        mAnimations.setState(STATE_STAND_THROW, true);
                        break;
                }
                break;
            case STATE_STAND_SHOOT:
                mAnimations.setState(STATE_STAND_SHOOT, true);
                break;
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(mWeaponSelected != WEAPON_PSHOT) mAmmoBars.onUpdate(elapsedMillis, gameEngine);
        mHealthBar.onUpdate(elapsedMillis, gameEngine);

        // check for water transition to play sound
        if(mInWaterLastCheck != mInWater) {
            mInWaterLastCheck = mInWater;
            gameEngine.soundPlay(GameEngine.GameSound.WATER);
        }

        if(mTeleporting) {
            mAnimations.onUpdate(elapsedMillis);

            // if starting to teleport
            if(mAnimations.mState == STATE_WARP_RISE) {
                // wait for animation to finish
                if(mAnimations.mOneShotFired) {
                    // place player at destination
                    mX = mTeleportDestinationX;
                    mY = mTeleportDestinationY;
                    updateBoundingBox();

                    // set animation to land animation
                    mAnimations.setState(STATE_WARP_LAND, true);

                    // set the stage viewport to that location
                    GameView.mViewPort.offsetTo(mX - (mX % GameView.VIEW_WIDTH), mY - (mY % GameView.VIEW_HEIGHT));
                }
            }
            else if(mAnimations.mState == STATE_WARP_LAND) {
                // if arriving from teleport
                if(mAnimations.mOneShotFired) {
                    // player is at the destination
                    mTeleporting = false;
                    mAnimations.setState(STATE_STAND, true);
                }
            }

            return;
        }

        if(mDead) {
            mDeathTimer += elapsedMillis;
            if(mDeathTimer >= DEATH_MILLIS) {
                if(mWeaponSelect.mLives >= 0) gameEngine.setState(GameEngine.STATE_RESTART_STAGE);
                else {
                    mWeaponSelect.mLives = WeaponSelect.DEFAULT_LIVES;
                    mAmmoBars.refillAll();
                    mWeaponSelect.refillAll();
                    gameEngine.setState(GameEngine.STATE_TRANSITION_TO_STAGE_SELECT);
                }
            }
            return;
        }

        if(mWarpingUp) {
            mDeathTimer += elapsedMillis;
            if(mDeathTimer >= 6171) {
                if (mAnimations.mState == STATE_STAND) {
                    mAnimations.setState(STATE_WARP_RISE, true);
                    gameEngine.soundPlay(GameEngine.GameSound.PLAYER_WARP);
                }
                else {
                    mAnimations.onUpdate(elapsedMillis);

                    if (mAnimations.mState == STATE_WARP_RISE && mAnimations.mOneShotFired) {
                        mAnimations.setState(STATE_WARP_IN, true);
                        mVelocityY = -WARP_VELOCITY;
                    } else if (mAnimations.mState == STATE_WARP_IN) {
                        mY += mVelocityY * elapsedMillis;
                        updateBoundingBox();

                        if (mBoundingBox.bottom <= GameView.mViewPort.top) {
                            switch (mWarpDestination) {
                                case WARP_DESTINATION_STAGE_SELECT:
                                    gameEngine.setState(GameEngine.STATE_TRANSITION_TO_STAGE_SELECT);
                                    break;
                                case WARP_DESTINATION_WILY2:
                                    gameEngine.setStateTransitionToStage(StageSelect.STAGE_WILY2);
                                    break;
                                case WARP_DESTINATION_WILY3:
                                    gameEngine.setStateTransitionToStage(StageSelect.STAGE_WILY3);
                                    break;
                                case WARP_DESTINATION_WILY4:
                                    gameEngine.setStateTransitionToStage(StageSelect.STAGE_WILY4);
                                    break;
                            }
                        }
                    }
                }
            }
            else {
                mVelocityY += GRAVITY_NORMAL_ACCELERATION * elapsedMillis;
                if(mVelocityY > GRAVITY_NORMAL_TERMINAL_VELOCITY) mVelocityY = GRAVITY_NORMAL_TERMINAL_VELOCITY;
                gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);
            }
            return;
        }

        if(mWarpingDown) {
            mDeathTimer += elapsedMillis;
            if(mDeathTimer >= 500) {
                // update animation
                mAnimations.onUpdate(elapsedMillis);

                if (mAnimations.mState == STATE_WARP_LAND) {
                    // check for end of animation
                    if (mAnimations.mOneShotFired) {
                        mAnimations.setState(STATE_STAND, true);
                        mWarpingDown = false;
                        mDeathTimer = 0;
                    }
                } else if (mY >= mStartPositionY) {
                    mY = mStartPositionY;
                    mAnimations.setState(STATE_WARP_LAND, true);
                    updateBoundingBox();
                    gameEngine.soundPlay(GameEngine.GameSound.PLAYER_WARP);
                } else {
                    // move down
                    mY += mVelocityY * elapsedMillis;
                }
            }
            return;
        }

        if(mHurtInvincible) {
            mHurtInvincibleTimer += elapsedMillis;
            if(mHurtInvincibleTimer > HURT_INVINCIBILITY_MILLIS) {
                mHurtInvincibleTimer = 0;
                mHurtBlinkTimer = 0;
                mHurtInvincible = false;
                mVisible = true;
            }
            else {
                mHurtBlinkTimer += elapsedMillis;
                if(mVisible && mHurtBlinkTimer > HURT_BLINK_ON_MILLIS) {
                    mHurtBlinkTimer = 0;
                    mVisible = false;
                }
                else if(!mVisible && mHurtBlinkTimer > HURT_BLINK_OFF_MILLIS) {
                    mHurtBlinkTimer = 0;
                    mVisible = true;
                }
            }
        }

        if(mHurtNoControl) {
            // slow down the bump with friction
            if(mVelocityX > 0) {
                mVelocityX += -1 * FRICTION_NORMAL_ACCELERATION * elapsedMillis;
                if(mVelocityX < 0) mVelocityX = 0;
            }
            else if(mVelocityX < 0) {
                mVelocityX += FRICTION_NORMAL_ACCELERATION * elapsedMillis;
                if(mVelocityX > 0) mVelocityX = 0;
            }

            // update x position after collision check
            gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

            // update viewport
            gameEngine.mStage.onUpdateScrollX(this);

            // update y velocity
            if(mInWater) {
                mVelocityY += GRAVITY_WATER_ACCELERATION * elapsedMillis;
                if(mVelocityY > GRAVITY_WATER_TERMINAL_VELOCITY) mVelocityY = GRAVITY_WATER_TERMINAL_VELOCITY;
            }
            else {
                mVelocityY += GRAVITY_NORMAL_ACCELERATION * elapsedMillis;
                if(mVelocityY > GRAVITY_NORMAL_TERMINAL_VELOCITY) mVelocityY = GRAVITY_NORMAL_TERMINAL_VELOCITY;
            }

            // update y position after collision check
            gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

            // update viewport
            gameEngine.mStage.onUpdateScrollY(gameEngine, elapsedMillis, this);

            // update animation
            mAnimations.onUpdate(elapsedMillis);

            // check for end of animation
            if(mAnimations.mOneShotFired) {
                mAnimations.setState(STATE_STAND, true);
                mHurtNoControl = false;
            }
            return;
        }

        // x - update player animation with direction
        if (gameEngine.mInputController.mDirectionX == -1 || gameEngine.mInputController.mDirectionX == 1) {
            mDirection = gameEngine.mInputController.mDirectionX;
            switch (mAnimations.mState) {
                case STATE_STAND:
                    mAnimations.setState(STATE_STAND_TO_WALK, true);
                    break;
                case STATE_STAND_CARRY:
                    mAnimations.setState(STATE_WALK_CARRY, true);
                    break;
                case STATE_STAND_SHOOT:
                    mAnimations.setState(STATE_WALK_SHOOT, true);
                    break;
            }
        } else if (gameEngine.mInputController.mDirectionX == 0) {
            switch (mAnimations.mState) {
                case STATE_WALK:
                    mAnimations.setState(STATE_LEAN, true);
                    break;
                case STATE_WALK_SHOOT:
                    mAnimations.setState(STATE_STAND_SHOOT, true);
                    break;
                case STATE_WALK_CARRY:
                    mAnimations.setState(STATE_STAND_CARRY, true);
                    break;
            }
        }

        // update velocity
        if(mClimbing) mVelocityX = 0;
        else {
            if(mInWater) {
                mVelocityX += WALK_WATER_ACCELERATION * gameEngine.mInputController.mDirectionX * elapsedMillis;

                if (mVelocityX > 0) {
                    mVelocityX += -FRICTION_WATER_ACCELERATION * elapsedMillis;
                    if (mVelocityX < 0) mVelocityX = 0;
                } else if (mVelocityX < 0) {
                    mVelocityX += FRICTION_WATER_ACCELERATION * elapsedMillis;
                    if (mVelocityX > 0) mVelocityX = 0;
                }

                // clamp maximum horizontal velocity
                if (mVelocityX > WALK_WATER_MAX_VELOCITY) mVelocityX = WALK_WATER_MAX_VELOCITY;
                else if (mVelocityX < (-WALK_WATER_MAX_VELOCITY)) mVelocityX = -WALK_WATER_MAX_VELOCITY;
            }
            else if(mOnIce && mOnGround) {
                mVelocityX += WALK_ICE_ACCELERATION * gameEngine.mInputController.mDirectionX * elapsedMillis;

                if (mVelocityX > 0) {
                    mVelocityX += -FRICTION_ICE_ACCELERATION * elapsedMillis;
                    if (mVelocityX < 0) mVelocityX = 0;
                } else if (mVelocityX < 0) {
                    mVelocityX += FRICTION_ICE_ACCELERATION * elapsedMillis;
                    if (mVelocityX > 0) mVelocityX = 0;
                }

                // clamp maximum horizontal velocity
                if (mVelocityX > WALK_NORMAL_MAX_VELOCITY) mVelocityX = WALK_NORMAL_MAX_VELOCITY;
                else if (mVelocityX < (-WALK_NORMAL_MAX_VELOCITY)) mVelocityX = -WALK_NORMAL_MAX_VELOCITY;
            }
            else {
                mVelocityX += WALK_NORMAL_ACCELERATION * gameEngine.mInputController.mDirectionX * elapsedMillis;

                if (mVelocityX > 0) {
                    mVelocityX += -FRICTION_NORMAL_ACCELERATION * elapsedMillis;
                    if (mVelocityX < 0) mVelocityX = 0;
                } else if (mVelocityX < 0) {
                    mVelocityX += FRICTION_NORMAL_ACCELERATION * elapsedMillis;
                    if (mVelocityX > 0) mVelocityX = 0;
                }

                // clamp maximum horizontal velocity
                if (mVelocityX > WALK_NORMAL_MAX_VELOCITY) mVelocityX = WALK_NORMAL_MAX_VELOCITY;
                else if (mVelocityX < (-WALK_NORMAL_MAX_VELOCITY)) mVelocityX = -WALK_NORMAL_MAX_VELOCITY;
            }

            // update x position after collision check
            gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);
        }

        // update viewport
        gameEngine.mStage.onUpdateScrollX(this);

        // y
        // climb
        if(mClimbTop) {
            // special case - climbing at the top of the ladder, force climb up or down
            if(mVelocityY < 0) {
                mVelocityY = -1 * CLIMB_TOP_VELOCITY;
                gameEngine.mStage.onUpdateClimb(this, -1);
            }
            else {
                mVelocityY = CLIMB_TOP_VELOCITY;
                gameEngine.mStage.onUpdateClimb(this, 1);
            }
        }
        else if(!mCarryingBlock) {
            // check for climbing
            switch (gameEngine.mInputController.mDirectionY) {
                case 1:
                case -1:
                    // down or up, try to climb
                    gameEngine.mStage.onUpdateClimb(this, gameEngine.mInputController.mDirectionY);

                    if (mClimbing) {
                        if (mAnimations.mState == STATE_CLIMB_SHOOT || mAnimations.mState == STATE_CLIMB_THROW) {
                            mVelocityY = 0;
                        } else {
                            mVelocityY = gameEngine.mInputController.mDirectionY * CLIMB_VELOCITY;
                            if (mClimbTop) mAnimations.setState(STATE_CLIMB_TOP, true);
                            else if ((mY % 16) < 8)
                                mAnimations.setState(STATE_CLIMB1, true);
                            else mAnimations.setState(STATE_CLIMB2, true);
                        }
                    }
                    break;
                case 0:
                    // center - stop climbing up or down
                    if (mClimbing) {
                        mVelocityY = 0;
                        if(mAnimations.mState != STATE_CLIMB_SHOOT && mAnimations.mState != STATE_CLIMB_THROW) {
                            if ((mY % 16) < 8)
                                mAnimations.setState(STATE_CLIMB1, true);
                            else mAnimations.setState(STATE_CLIMB2, true);
                        }
                    }
                    break;
            }
        }

        // gravity (if not climbing or on a game object)
        if(!mClimbing && !mOnMagnet && !mOnTram && !mOnFootHolder) {
            if(mInWater) {
                mVelocityY += GRAVITY_WATER_ACCELERATION * elapsedMillis;
                if(mVelocityY > GRAVITY_WATER_TERMINAL_VELOCITY) mVelocityY = GRAVITY_WATER_TERMINAL_VELOCITY;
            }
            else {
                mVelocityY += GRAVITY_NORMAL_ACCELERATION * elapsedMillis;
                if(mVelocityY > GRAVITY_NORMAL_TERMINAL_VELOCITY) mVelocityY = GRAVITY_NORMAL_TERMINAL_VELOCITY;
            }
        }

        // jump
        if(gameEngine.mInputController.mButtonAPressed && !mJumpOnThisPress && (mOnGround || mClimbing || mOnMagnet || mOnTram || mOnFootHolder)) {
            // start the jump
            mJumpOnThisPress = true;
            mJustLanded = false;

            // just fall from ladder if you jump while climbing
            if(mClimbing) {
                mClimbing = false;
                mJumpReleaseTimer = -1;
            }
            else mJumpReleaseTimer = 0;
        }
        else if(!gameEngine.mInputController.mButtonAPressed && mJumpOnThisPress) {
            mJumpOnThisPress = false;
        }

        if(mJumpOnThisPress && mJumpReleaseTimer >= 0) {
            // hold jump velocity until button release or timeout
            mVelocityY = JUMP_VELOCITY;

            mJumpReleaseTimer += elapsedMillis;
            if(mJumpReleaseTimer > JUMP_AUTORELEASE_MILLIS) {
                mJumpReleaseTimer = -1;
            }
        }

        // update y position after collision check
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);
        gameEngine.mStage.onUpdateScrollY(gameEngine, elapsedMillis, this);

        // check for being on the ground, or landing on the ground
        if(!mOnGround && mAnimations.mState != STATE_JUMP_SHOOT && mAnimations.mState != STATE_JUMP_THROW && !mClimbing && !mOnMagnet && !mOnTram && !mOnFootHolder) {
            if(mCarryingBlock) mAnimations.setState(STATE_JUMP_CARRY, true);
            else mAnimations.setState(STATE_JUMP, true);
        }
        else if(mJustLanded) {
            mJustLanded = false;
            mClimbing = false;
            if(mCarryingBlock) mAnimations.setState(STATE_STAND_CARRY, true);
            else mAnimations.setState(STATE_STAND, true);

            gameEngine.soundPlay(GameEngine.GameSound.PLAYER_LAND);
        }

        // shoot
        if(gameEngine.mInputController.mButtonBPressed && !mClimbTop) {
            if(!mShotOnThisPress) {
                mShotOnThisPress = true;
                onShoot(gameEngine);
            }
            else if(mWeaponSelected == WEAPON_MAGNET) {
                mMagnetTimer += elapsedMillis;
                if(mMagnetTimer > 100) {
                    mMagnetTimer = 0;
                    onShoot(gameEngine);
                }
            }
        }
        else if(!gameEngine.mInputController.mButtonBPressed) {
            // allow another shot
            mShotOnThisPress = false;
            mMagnetMultiplier = 0;
            mMagnetTimer = 0;
        }

        mAnimations.onUpdate(elapsedMillis);

        // check for end animations that cause transition
        if(mAnimations.mOneShotFired) {
            switch (mAnimations.mState) {
                case STATE_LEAN:
                case STATE_STAND_SHOOT:
                case STATE_STAND_THROW:
                    mAnimations.setState(STATE_STAND, true);
                    break;
                case STATE_STAND_TO_WALK:
                    mAnimations.setState(STATE_WALK, true);
                    break;
                case STATE_JUMP_SHOOT:
                case STATE_JUMP_THROW:
                    mAnimations.setState(STATE_JUMP, true);
                    break;
                case STATE_CLIMB_SHOOT:
                case STATE_CLIMB_THROW:
                    if(((int) mY) % 16 < 8) mAnimations.setState(STATE_CLIMB1, true);
                    else mAnimations.setState(STATE_CLIMB2, true);
                    break;
            }
        }

        if(mAnimations.mState == STATE_WALK_SHOOT) {
            mWalkShootTimer += elapsedMillis;
            if (mWalkShootTimer > 300) {
                mAnimations.setState(STATE_WALK, false);
                mWalkShootTimer = 0;
            }
        }

        // force recheck every update
        mOnMagnet = false;
        mOnTram = false;
        mCanPickupBlock = false;
        mOnFootHolder = false;
        mPushVelocity = 0;
    }

    public void onUpdateForceTravelX(GameEngine gameEngine, long elapsedMillis, int direction) {
        if(mAnimations.mState == STATE_STAND
                || mAnimations.mState == STATE_LEAN
                || mAnimations.mState == STATE_STAND_TO_WALK
                || mAnimations.mState == STATE_WALK_SHOOT
                || ((mAnimations.mState == STATE_JUMP || mAnimations.mState == STATE_JUMP_SHOOT) && mJustLanded)) mAnimations.setState(STATE_WALK, true);

        mAnimations.onUpdate(elapsedMillis);
        mVelocityX = WALK_NORMAL_MAX_VELOCITY * .6f * direction;
        gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

        mVelocityY += GRAVITY_NORMAL_ACCELERATION * elapsedMillis;
        if(mVelocityY > GRAVITY_NORMAL_TERMINAL_VELOCITY) mVelocityY = GRAVITY_NORMAL_TERMINAL_VELOCITY;
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);
    }

    public void setCheckPoint(int x, int y, int direction) {
        mCheckPointSet = true;
        mStartPositionX = x;
        mStartPositionY = y;
        mStartDirection = direction;
    }

    public void setSelectedWeapon(int selectedWeapon) {
        mWeaponSelected = selectedWeapon;
        mAmmoBars.mSelected = selectedWeapon;
        mAnimations.setColor(selectedWeapon);
    }

    @Override
    public void startGame(GameEngine gameEngine) {
        // reset health
        mHealthBar.startGame(gameEngine);

        // reset all flags
        mWarpingUp = false;
        mOnGround = false;
        mJustLanded = false;
        mDead = false;
        mDeathTimer = 0;
        mVisible = true;
        mJumpReleaseTimer = -1;
        mClimbing = false;
        mClimbTop = false;
        mHurtNoControl = false;
        mHurtInvincible = false;
        mHurtInvincibleTimer = 0;
        mHurtBlinkTimer = 0;

        mOnMagnet = false;
        mOnTram = false;
        mOnFootHolder = false;

        // warp in
        mWarpingDown = true;
        mVelocityX = 0;
        mVelocityY = WARP_VELOCITY;
        mAnimations.setState(STATE_WARP_IN, true);

        mDirection = mStartDirection;
        mX = mStartPositionX;
        mY = GameView.mViewPort.top - BOUNDING_BOX_SIZE_Y + 1;
        updateBoundingBox();
    }

    public void teleportTo(int x, int y, GameEngine gameEngine) {
        mTeleporting = true;
        mTeleportDestinationX = x;
        mTeleportDestinationY = y;
        mAnimations.setState(STATE_WARP_RISE, true);
        gameEngine.soundPlay(GameEngine.GameSound.PLAYER_WARP);
    }

    public void warpOut(int toWhere) {
        mWarpingUp = true;
        mAnimations.setState(STATE_STAND, true);
        mDeathTimer = 0;
        mVelocityX = 0;
        mVelocityY = 0;
        mHurtInvincible = true;
        mVisible = true;

        mWarpDestination = toWhere;
    }

    private WeaponBomb weaponBombGet() {
        if(mWeaponBomb.isEmpty() || mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].mValue == 0) return null;

        mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].remove(WEAPON_BOMB_AMMO_PER_SHOT);
        mAmmoBars.remove(WEAPON_BOMB_AMMO_PER_SHOT);

        return mWeaponBomb.remove(0);
    }

    public void weaponBombRelease(WeaponBomb weaponBomb) {
        mWeaponBomb.add(weaponBomb);
    }

    private WeaponCutter weaponCutterGet() {
        if(mWeaponCutter.isEmpty() || mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].mValue == 0) return null;

        mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].remove(WEAPON_CUTTER_AMMO_PER_SHOT);
        mAmmoBars.remove(WEAPON_CUTTER_AMMO_PER_SHOT);

        return mWeaponCutter.remove(0);
    }

    public void weaponCutterRelease(WeaponCutter weaponCutter) { mWeaponCutter.add(weaponCutter); }

    private WeaponElectricity weaponElectricityGet() {
        if(mWeaponElectricity.isEmpty() || mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].mValue == 0) return null;

        mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].remove(WEAPON_ELECTRICITY_AMMO_PER_SHOT);
        mAmmoBars.remove(WEAPON_ELECTRICITY_AMMO_PER_SHOT);

        return mWeaponElectricity.remove(0);
    }

    @Override
    public void weaponElectricityRelease(WeaponElectricity weaponElectricity) { mWeaponElectricity.add(weaponElectricity); }

    private WeaponFire weaponFireGet() {
        if(mWeaponFire.isEmpty() || mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].mValue == 0) return null;

        mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].remove(WEAPON_FIRE_AMMO_PER_SHOT);
        mAmmoBars.remove(WEAPON_FIRE_AMMO_PER_SHOT);

        return mWeaponFire.remove(0);
    }

    @Override
    public void weaponFireRelease(WeaponFire weaponFire) { mWeaponFire.add(weaponFire); }

    @Override
    public void weaponGutsRelease(WeaponGuts weaponGuts) { mWeaponGutsReleased = true; }

    private WeaponIce weaponIceGet() {
        if(mWeaponIce.isEmpty() || mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].mValue == 0) return null;

        mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].remove(WEAPON_ICE_AMMO_PER_SHOT);
        mAmmoBars.remove(WEAPON_ICE_AMMO_PER_SHOT);

        return mWeaponIce.remove(0);
    }

    @Override
    public void weaponIceRelease(WeaponIce weaponIce) { mWeaponIce.add(weaponIce); }

    private WeaponMagnet weaponMagnetGet() {
        if(mWeaponMagnet.isEmpty() || mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].mValue == 0) return null;

        mWeaponSelect.mHorizontalAmmoBars[mWeaponSelected].remove(WEAPON_MAGNET_AMMO_PER_SHOT);
        mAmmoBars.remove(WEAPON_MAGNET_AMMO_PER_SHOT);

        return mWeaponMagnet.remove(0);
    }

    @Override
    public void weaponMagnetRelease(WeaponMagnet weaponMagnet) { mWeaponMagnet.add(weaponMagnet); }

    public void weaponPShotRelease(WeaponPShot p) {
        if(!mWeaponPShots.contains(p)) mWeaponPShots.add(p);
    }
}