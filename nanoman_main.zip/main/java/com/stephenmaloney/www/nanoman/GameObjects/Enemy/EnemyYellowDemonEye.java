package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.DeathExplosion;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.List;

public class EnemyYellowDemonEye extends SpriteFrameAnimation {
    private final static int STATE_CLOSED = 0;
    private final static int STATE_PARTIAL_OPEN = 1;
    private final static int STATE_OPEN = 2;
    private final static int STATE_SHOOT = 3;
    private final static int STATE_WAIT_TO_CLOSE = 4;
    private final static int STATE_PARTIAL_CLOSE = 5;
    private final static int STATE_CLOSE_REMOVE = 6;
    private int mState = STATE_CLOSED;
    private int mStateTimer = 0;

    private final EnemyYellowDemonShot mShot;
    private boolean mShotReleased = true;

    private final List<DeathExplosion> mDeathExplosions = new ArrayList<>();
    private final static int DEATH_EXPLOSION_LIMIT = 16;

    private final EnemyHealthBar mHealthBar;
    private boolean mHurtOrDead = false;
    private int mHurtTimer = 0;

    private final EnemyYellowDemon mParent;

    EnemyYellowDemonEye(Resources resources, EnemyYellowDemon parent) {
        super(0, 0, 13, 8, 5);

        mParent = parent;

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_yellow_demon_eye1);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_yellow_demon_eye2);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_yellow_demon_eye3);

        final Matrix matrix = new Matrix();
        matrix.preScale(-1, 1);
        mFrames[3] = Bitmap.createBitmap(mFrames[1], 0, 0, mFrames[1].getWidth(), mFrames[1].getHeight(), matrix, false);
        mFrames[4] = Bitmap.createBitmap(mFrames[2], 0, 0, mFrames[2].getWidth(), mFrames[2].getHeight(), matrix, false);

        mShot = new EnemyYellowDemonShot(resources, R.drawable.gameobject_enemy_shot_orange, this);

        // set up death explosions
        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) mDeathExplosions.add(new DeathExplosion(resources, R.drawable.animation_enemy_death, i));

        // create health bar
        mHealthBar = new EnemyHealthBar(resources);
    }

    void addHealthBar(GameEngine gameEngine) {
        gameEngine.addGameObject(mHealthBar);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject instanceof WeaponPShot
                || (!mHurtOrDead
                && (otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical)));
    }

    void init(int x, int y, int adderX, int adderY, int direction) {
        mX = x + (int)(adderX * Math.random());
        mY = y + (int)(adderY * Math.random());
        updateBoundingBox();

        mDirection = direction;
        mFrame = 0;
        mState = STATE_CLOSED;
        mStateTimer = 0;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot || otherObject instanceof WeaponElectricityHorizontal || otherObject instanceof WeaponElectricityVertical) mHealthBar.remove(10);
        else if(otherObject instanceof WeaponCutter) mHealthBar.remove(20);

        if(mHealthBar.isEmpty()) {
            mHurtOrDead = true;

            for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) {
                DeathExplosion exp = mDeathExplosions.get(i);
                exp.init(mBoundingBox.centerX(), mBoundingBox.centerY());
                gameEngine.addGameObject(exp);
            }

            gameEngine.removeGameObject(mHealthBar);
            gameEngine.removeGameObject(this);
            mParent.onDeath(gameEngine, mDirection);

            gameEngine.soundPlay(GameEngine.GameSound.PLAYER_DEATH);
        }
        else {
            mHurtOrDead = true;
            mHurtTimer = 1000;

            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(mHurtOrDead) {
            mHurtTimer -= elapsedMillis;
            if(mHurtTimer <= 0) {
                mHurtOrDead = false;
                mHurtTimer = 0;
            }
        }

        switch(mState) {
            case STATE_CLOSED:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 250) {
                    mStateTimer = 0;
                    mState = STATE_PARTIAL_OPEN;
                    if(mDirection == 1) mFrame = 1;
                    else mFrame = 3;
                }
                break;
            case STATE_PARTIAL_OPEN:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 250) {
                    mStateTimer = 0;
                    mState = STATE_OPEN;
                    if(mDirection == 1) mFrame = 2;
                    else mFrame = 4;
                }
                break;
            case STATE_OPEN:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 250) {
                    mStateTimer = 0;
                    mState = STATE_SHOOT;
                }
                break;
            case STATE_SHOOT:
                if(mShotReleased) {
                    mShotReleased = false;
                    mShot.init(mBoundingBox.centerX(), mBoundingBox.centerY(), mDirection, gameEngine);
                    gameEngine.addGameObject(mShot);
                }
                mState = STATE_WAIT_TO_CLOSE;
                break;
            case STATE_WAIT_TO_CLOSE:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 250) {
                    mStateTimer = 0;
                    mState = STATE_PARTIAL_CLOSE;
                    if(mDirection == 1) mFrame = 1;
                    else mFrame = 3;
                }
                break;
            case STATE_PARTIAL_CLOSE:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 250) {
                    mStateTimer = 0;
                    mState = STATE_CLOSE_REMOVE;
                    mFrame = 0;
                }
                break;
            case STATE_CLOSE_REMOVE:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 250) {
                    mStateTimer = 0;
                    gameEngine.removeGameObject(this);
                    mParent.releaseEye();
                }
                break;
        }
    }

    void releaseShot() {
        mShotReleased = true;
    }
}
