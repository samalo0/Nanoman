package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteStatic;
import com.stephenmaloney.www.nanoman.R;

public class EnemyBubbleRobotShot extends SpriteStatic {
    private final static float SHOT_VELOCITY = .1f;
    private final Rect mPlayerLocation;
    private final EnemyBubbleRobotDrone mParent;

    EnemyBubbleRobotShot(Resources resources, Rect playerLocation, EnemyBubbleRobotDrone parent) {
        super(resources, R.drawable.gameobject_enemy_bubble_robot_shot, 0, 0, 8, 8);

        mPlayerDamage = 12;

        mPlayerLocation = playerLocation;
        mParent = parent;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    void init(int x, int y, GameEngine gameEngine) {
        mX = x;
        mY = y;
        mXFractional = 0;
        mYFractional = 0;
        updateBoundingBox();

        final double dx = mPlayerLocation.centerX() - mBoundingBox.centerX();
        final double dy = mBoundingBox.centerY() - mPlayerLocation.centerY();
        double angle = Math.atan2(dy, dx);
        if(angle < 0) angle = Math.abs(angle);
        else angle = 2 * Math.PI - angle;

        mVelocityX = SHOT_VELOCITY * (float)Math.cos(angle);
        mVelocityY = SHOT_VELOCITY * (float)Math.sin(angle);

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_SHOOT);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseShot(this);
            return;
        }

        double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY= mVelocityY * elapsedMillis + mYFractional;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;

        updateBoundingBox();
    }
}
