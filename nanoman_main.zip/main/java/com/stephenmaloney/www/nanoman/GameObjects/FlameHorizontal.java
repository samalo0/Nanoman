package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public class FlameHorizontal extends SpriteAnimatedMirrored {
    public final static String TYPE = "FlameHorizontal";

    private final static int ANIMATION_START = 0;
    private final static int ANIMATION_ON = 1;

    private final static int STATE_OFF = 0;
    private final static int STATE_START = 1;
    private final static int STATE_ON = 2;
    private int mState = STATE_OFF;
    private int mStateTimer;

    private int mOffTime;
    private int mOnTime;

    FlameHorizontal(Resources resources, HashMap<String, String> properties) {
        super(0, 2, 16, 16);

        mDirection = Integer.parseInt(properties.get("Direction"));

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2);
        updateBoundingBox();

        // mX and mY are static location for the clip bitmap
        if(mDirection == -1) mX -= 48;

        mSpriteAnimation.addState(ANIMATION_START, (AnimationDrawable) resources.getDrawable(R.drawable.animation_flame_horizontal_start, null));
        mSpriteAnimation.addState(ANIMATION_ON, (AnimationDrawable) resources.getDrawable(R.drawable.animation_flame_horizontal_on, null));

        mPlayerDamage = Integer.parseInt(properties.get("Damage"));

        mOffTime = Integer.parseInt(properties.get("OffTime"));
        mOnTime = Integer.parseInt(properties.get("OnTime"));

        mStateTimer = mOffTime;

        mFacingLeftAdjustmentX = 64;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mState != STATE_OFF) super.onDraw(canvas);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        mSpriteAnimation.onUpdate(elapsedMillis);

        switch(mState) {
            case STATE_OFF:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= mOffTime) {
                    mStateTimer = 0;
                    mState = STATE_START;
                    mSpriteAnimation.setState(ANIMATION_START, true);
                }
                break;
            case STATE_START:
                if(mSpriteAnimation.mOneShotFired) {
                    mState = STATE_ON;
                    mSpriteAnimation.setState(ANIMATION_ON, true);
                    mBoundingBox.set(mX, mY, mX + 64, mY + 13);
                    updateBoundingBox();
                }
                break;
            case STATE_ON:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= mOnTime) {
                    mStateTimer = 0;
                    mState = STATE_OFF;

                    if(mDirection == 1) mBoundingBox.set(mX - 14, mY + 8, mX - 4, mY + 14);
                    else mBoundingBox.set(mX + 66, mY + 8, mX + 78, mY + 12);
                }
                break;
        }
    }
}
