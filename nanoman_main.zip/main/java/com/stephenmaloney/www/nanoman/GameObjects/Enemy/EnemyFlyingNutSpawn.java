package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;

import java.util.HashMap;

public class EnemyFlyingNutSpawn extends GameObject {
    public final static String TYPE = "EnemyFlyingNut";

    private final EnemyFlyingNut mNut;
    private boolean mNutReleased = true;
    private int mDelay = 0;

    private final Rect mBoundingBox;

    public EnemyFlyingNutSpawn(Resources resources, HashMap<String, String> properties) {
        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;

        final int direction  = Integer.parseInt(properties.get("Direction"));

        mNut = new EnemyFlyingNut(resources, direction, y, this);
        mBoundingBox = new Rect(x, y, x + Tile.SIZE, y + Tile.SIZE);
    }

    @Override
    public void onDraw(Canvas canvas) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(GameEngine.isObjectVisible(mBoundingBox)) {
            mDelay += elapsedMillis;
            if(!mNutReleased) mDelay = 0;
            else if(mDelay >= 1000) {
                mNutReleased = false;
                mNut.init();
                gameEngine.addGameObject(mNut);
            }
        }
    }

    void releaseNut() {
        mNutReleased = true;
    }

    @Override
    public void startGame(GameEngine gameEngine) {
    }
}
