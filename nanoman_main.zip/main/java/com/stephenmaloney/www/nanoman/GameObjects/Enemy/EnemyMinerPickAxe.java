package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirrored;
import com.stephenmaloney.www.nanoman.R;

public class EnemyMinerPickAxe extends SpriteAnimatedMirrored {
    private final static float VELOCITY_X = .06f;
    private final static float VELOCITY_Y = -.3f;

    private final EnemyMiner mParent;

    EnemyMinerPickAxe(Resources resources, EnemyMiner parent) {
        super(0, 0, 12, 12);

        mParent = parent;

        mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_miner_pickaxe, null));
        mFacingLeftAdjustmentX = 12;

        mPlayerDamage = 16;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    void init(int x, int y, int direction, int distance) {
        mX = x;
        mY = y;
        updateBoundingBox();

        mDirection = direction;

        if(distance > 64) mVelocityX = VELOCITY_X * mDirection * 3;
        else if(distance > 32) mVelocityX = VELOCITY_X * mDirection * 2;
        else mVelocityX = VELOCITY_X * mDirection;

        mVelocityY = VELOCITY_Y;
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releasePickaxe();
            return;
        }

        mSpriteAnimation.onUpdate(elapsedMillis);

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;

        final double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY= mVelocityY * elapsedMillis + mYFractional;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;
        updateBoundingBox();
    }
}
