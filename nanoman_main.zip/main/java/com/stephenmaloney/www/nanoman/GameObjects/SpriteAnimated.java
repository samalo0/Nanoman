package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Canvas;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public abstract class SpriteAnimated extends Sprite {
    protected final SpriteAnimationDrawable mSpriteAnimation = new SpriteAnimationDrawable();

    public SpriteAnimated(int boundingBoxOffsetX, int boundingBoxOffSetY, int boundingBoxSizeX, int boundingBoxSizeY) {
        super(boundingBoxOffsetX, boundingBoxOffSetY, boundingBoxSizeX, boundingBoxSizeY);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        mMatrix.reset();
        mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);

        canvas.drawBitmap(mSpriteAnimation.getBitmap(), mMatrix, GameView.mPaint);
    }
}
