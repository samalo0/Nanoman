package com.stephenmaloney.www.nanoman.GameObjects.PowerUps;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteStatic;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class OneUp extends SpriteStatic {
    public final static String TYPE = "OneUp";

    private final boolean mRandomSpawn;
    private int mTimeoutTimer = 0;

    public OneUp(Resources resources, HashMap<String, String> properties) {
        super(resources, R.drawable.gameobject_one_up, 0, 0, 16, 16);

        // get starting x, y position (adjust x by one since the large health is 14 pixels wide, centering it)
        mX = (Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2);
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2);
        updateBoundingBox();

        mRandomSpawn = false;
    }

    public OneUp(Resources resources, int centerX, int centerY) {
        super(resources, R.drawable.gameobject_one_up, 0, 0, 16, 16);

        mX = centerX - 8;
        mY = centerY - 8;
        updateBoundingBox();

        mVelocityY = -.2f;
        mRandomSpawn = true;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        // check in player object
        return false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!mRandomSpawn) return;

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        if(mVelocityY > GameEngine.TERMINAL_VELOCITY) mVelocityY = GameEngine.TERMINAL_VELOCITY;
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

        mTimeoutTimer += elapsedMillis;
        if(mTimeoutTimer >= GameEngine.RANDOM_SPAWN_TIMEOUT) {
            gameEngine.removeGameObject(this);
        }
    }
}
