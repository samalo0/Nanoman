package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class EnemyEyePatrol extends SpriteFrameAnimation {
    public final static String TYPE = "EnemyEyePatrol";
    private final static float VELOCITY = .1f;

    private final static int STATE_START_DELAY = 0;
    private final static int STATE_OPEN_PARTIAL = 1;
    private final static int STATE_MOVE = 2;
    private final static int STATE_CLOSE_PARTIAL = 3;
    private final static int STATE_SLEEP = 4;
    private final static int STATE_STUNNED = 5;
    private int mState = STATE_START_DELAY;
    private int mStateTimer = 0;

    private int mStunnedTimer = 0;
    private int mOldState;

    private final int mStartDelay;

    private int mHealth = 15;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    public EnemyEyePatrol(Resources resources, HashMap<String, String> properties) {
        super(0, 0, 16, 16, 3);

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;
        updateBoundingBox();

        mDirection = Integer.parseInt(properties.get("Direction"));
        mStartDelay = Integer.parseInt(properties.get("StartDelay"));

        final String color = properties.get("Color");
        switch(color) {
            case "Red":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_eye_patrol_red1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_eye_patrol_red2);
                mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_eye_patrol_red3);
                break;
            case "Blue":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_eye_patrol_blue1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_eye_patrol_blue2);
                mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_eye_patrol_blue3);
                break;
            case "Orange":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_eye_patrol_orange1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_eye_patrol_orange2);
                mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_eye_patrol_orange3);
                break;
        }

        final String orientation = properties.get("Orientation");
        if(orientation.equals("Vertical")) {
            mVelocityX = 0;
            mVelocityY = VELOCITY * mDirection;
        }
        else {
            mVelocityX = VELOCITY * mDirection;
            mVelocityY = 0;
        }

        mPlayerDamage = 22;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponIce) {
            if (mState != STATE_STUNNED) {
                mOldState = mState;
                mState = STATE_STUNNED;
            }
            mStunnedTimer = 0;
        }
        else if(otherObject instanceof WeaponPShot) {
            mHealth--;
            if(mHealth <= 0) onDeath(gameEngine);
            else gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
        else if(otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner) {

            onDeath(gameEngine);
        }
    }

    private void onDeath(GameEngine gameEngine) {
        mHurtOrDead = true;

        mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
        gameEngine.addGameObject(mExplosion);

        // spawn object?
        gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

        gameEngine.removeGameObject(this);

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        switch(mState) {
            case STATE_START_DELAY:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= mStartDelay) {
                    mStateTimer = 0;
                    mState = STATE_OPEN_PARTIAL;
                    mFrame = 1;
                }
                break;
            case STATE_OPEN_PARTIAL:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 100) {
                    mStateTimer = 0;
                    mState = STATE_MOVE;
                    mFrame = 2;
                }
                break;
            case STATE_MOVE:
                final float oldVelocityX = mVelocityX;
                final float oldVelocityY = mVelocityY;

                gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);
                gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

                if((oldVelocityX != 0 && mVelocityX == 0) || (oldVelocityY != 0 && mVelocityY == 0) || (oldVelocityY != 0 && mVelocityY == -.25f * oldVelocityY)) {
                    mVelocityX = oldVelocityX * -1;
                    mVelocityY = oldVelocityY * -1;
                    mState = STATE_CLOSE_PARTIAL;
                    mFrame = 1;
                    mDirection *= -1;
                }
                break;
            case STATE_CLOSE_PARTIAL:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 100) {
                    mStateTimer = 0;
                    mState = STATE_SLEEP;
                    mFrame = 0;
                }
                break;
            case STATE_SLEEP:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 2000) {
                    mStateTimer = 0;
                    mState = STATE_OPEN_PARTIAL;
                    mFrame = 1;
                }
                break;
            case STATE_STUNNED:
                mStunnedTimer += elapsedMillis;
                if(mStunnedTimer >= 2000) {
                    mStunnedTimer = 0;
                    mState = mOldState;
                }
                break;
        }
    }
}
