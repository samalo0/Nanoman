package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public abstract class SpriteStatic extends Sprite {
    private final Bitmap mBitmap;

    public SpriteStatic(Resources resources, int resource_id, int boundingBoxOffsetX, int boundingBoxOffsetY, int boundingBoxSizeX, int boundingBoxSizeY) {
        super(boundingBoxOffsetX, boundingBoxOffsetY, boundingBoxSizeX, boundingBoxSizeY);

        mBitmap = BitmapFactory.decodeResource(resources, resource_id);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        mMatrix.reset();
        mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);
        canvas.drawBitmap(mBitmap, mMatrix, GameView.mPaint);
    }
}
