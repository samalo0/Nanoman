package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.DeathExplosion;
import com.stephenmaloney.www.nanoman.GameObjects.Dust;
import com.stephenmaloney.www.nanoman.GameObjects.Gate;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.WeaponPickup;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFire;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EnemyFireman extends SpriteAnimatedMirroredWeapons {
    public final static String TYPE = "EnemyFireman";

    private final static float VELOCITY_X = .1f;
    private final static float JUMP_VELOCITY = -.35f;

    private final static int ANIMATION_STAND = 0;
    private final static int ANIMATION_PUNCH = 1;
    private final static int ANIMATION_JUMP = 2;
    private final static int ANIMATION_WALK = 3;
    private final static int ANIMATION_SHOOT = 4;
    private final static int ANIMATION_HURT = 5;
    private int mOldAnimationState;

    private final static int STATE_SHOWBOAT = 0;
    private final static int STATE_REDIRECT = 1;
    private final static int STATE_WAIT_FOR_ONESHOT = 2;
    private final static int STATE_WAIT_FOR_LAND = 3;
    private final static int STATE_WAIT_FOR_TIME = 4;
    private int mState = STATE_SHOWBOAT;
    private int mStateNext;
    private int mStateTimer = 0;

    private final static int BOMB_DAMAGE = 8;
    private final static int ELECTRICITY_DAMAGE = 12;
    private final static int CUTTER_DAMAGE = 16;
    private final static int ICE_DAMAGE = 25;
    private final static int PSHOT_DAMAGE = 8;

    private final List<WeaponFire> mFire = new ArrayList<>();
    private final static int FIRE_LIMIT = 3;

    private final EnemyHealthBar mHealthBar;
    private boolean mHealthBarAdded = false;

    private final List<DeathExplosion> mDeathExplosions = new ArrayList<>();
    private final static int DEATH_EXPLOSION_LIMIT = 16;

    private final WeaponPickup mWeaponPickup;

    private boolean mHurtOrDead = false;
    private final static int HURT_MILLIS = 1500;
    private int mHurtTimer;
    private final static int HURT_BLINK_MILLIS = 40;
    private int mHurtBlinkTimer;
    private final static int HURT_EXPLOSION_MILLIS = 250;
    private int mHurtExplosionTimer;
    private boolean mVisible = true;

    private final boolean mDropsWeapon;
    private final Gate mGate;
    private boolean mGateVisible = false;

    public EnemyFireman(Context context, HashMap<String, String> properties) {
        super(context.getResources(), 6, 8, 11, 24);

        final Resources resources = context.getResources();

        // get position of enemy - must be placed next to a floor
        final int x = Integer.parseInt(properties.get("PositionX"));
        final int y = Integer.parseInt(properties.get("PositionY"));

        mX = x << Tile.SIZE_POW_2;
        mY = (y << Tile.SIZE_POW_2) - 16;
        mDirection = Integer.parseInt(properties.get("Direction"));
        updateBoundingBox();

        // check if enemy drops his weapon or removes a gate on death
        final String dropsWeapon = properties.get("DropsWeapon");
        mDropsWeapon = dropsWeapon == null || Boolean.parseBoolean(dropsWeapon);

        if(!mDropsWeapon) {
            HashMap<String, String> props = new HashMap<>();
            props.put("Orientation", "Horizontal");
            props.put("Width", "1");
            props.put("Length", "3");
            props.put("PassDirection", "-1");
            props.put("Drawable", "tile_wily2_gate_horiz");
            props.put("PositionX", Integer.toString(x - 1));
            props.put("PositionY", Integer.toString(y + 1));
            mGate = new Gate(context, props);
        }
        else mGate = null;

        mSpriteAnimation.addState(ANIMATION_STAND, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_fireman_stand, null));
        mSpriteAnimation.addState(ANIMATION_PUNCH, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_fireman_punch, null));
        mSpriteAnimation.addState(ANIMATION_JUMP, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_fireman_jump, null));
        mSpriteAnimation.addState(ANIMATION_WALK, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_fireman_walk, null));
        mSpriteAnimation.addState(ANIMATION_SHOOT, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_fireman_shoot, null));
        mSpriteAnimation.addState(ANIMATION_HURT, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_hurt, null));

        for(int i = 0; i < FIRE_LIMIT; i++) mFire.add(new WeaponFire(resources, this));

        mFacingLeftAdjustmentX = 23;

        mHealthBar = new EnemyHealthBar(resources);
        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) mDeathExplosions.add(new DeathExplosion(resources, R.drawable.animation_enemy_death, i));

        mWeaponPickup = new WeaponPickup(resources, Player.WEAPON_FIRE);

        mPlayerDamage = 20;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox)
                && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot) mHealthBar.remove(PSHOT_DAMAGE);
        else if(otherObject instanceof WeaponElectricityHorizontal || otherObject instanceof WeaponElectricityVertical) mHealthBar.remove(ELECTRICITY_DAMAGE);
        else if(otherObject instanceof WeaponIce) mHealthBar.remove(ICE_DAMAGE);
        else if(otherObject instanceof WeaponBomb) mHealthBar.remove(BOMB_DAMAGE);
        else if(otherObject instanceof WeaponCutter) mHealthBar.remove(CUTTER_DAMAGE);

        if(mHealthBar.isEmpty()) onDeath(gameEngine);
        else onHurt(gameEngine);
    }

    private void onDeath(GameEngine gameEngine) {
        mHurtOrDead = true;

        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) {
            DeathExplosion exp = mDeathExplosions.get(i);
            exp.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(exp);
        }

        if(mDropsWeapon) {
            mWeaponPickup.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mWeaponPickup);
        }
        else {
            mGate.unlock(gameEngine);
            gameEngine.removeGameObject(mGate);
        }

        gameEngine.removeGameObject(mHealthBar);
        gameEngine.removeGameObject(this);

        gameEngine.soundPlay(GameEngine.GameSound.PLAYER_DEATH);
        if(mDropsWeapon) gameEngine.musicPause();
        else gameEngine.musicPlayLooped(R.raw.music_wily_stage2);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mVisible) super.onDraw(canvas);
    }

    private void onHurt(GameEngine gameEngine) {
        mHurtOrDead = true;
        mHurtTimer = 0;
        mHurtBlinkTimer = 0;
        mState = STATE_WAIT_FOR_TIME;
        mStateNext = STATE_REDIRECT;
        mStateTimer = HURT_EXPLOSION_MILLIS;
        if(mVelocityY < 0) mVelocityY = 0;

        // create dust
        dustAdd(gameEngine);

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            if(mHealthBarAdded) {
                mHealthBarAdded = false;
                gameEngine.removeGameObject(mHealthBar);
            }
            return;
        }

        if(!mHealthBarAdded) {
            mHealthBarAdded = true;
            gameEngine.addGameObject(mHealthBar);
            gameEngine.musicPlayLooped(R.raw.music_boss_theme);
        }

        if(!mDropsWeapon && !mGateVisible) {
            mGateVisible = true;
            mGate.lock(gameEngine);
            gameEngine.addGameObject(mGate);
        }

        if(mHurtOrDead) {
            mHurtTimer += elapsedMillis;
            if(mHurtTimer >= HURT_MILLIS) {
                mHurtOrDead = false;
                mVisible = true;
                mHurtBlinkTimer = 0;
                mHurtExplosionTimer = 0;
                if(mSpriteAnimation.mState == ANIMATION_HURT) mSpriteAnimation.setState(mOldAnimationState, true);
            }
            else {
                mHurtBlinkTimer += elapsedMillis;
                if(mHurtBlinkTimer >= HURT_BLINK_MILLIS) {
                    mHurtBlinkTimer = 0;
                    mVisible = !mVisible;
                }
                mHurtExplosionTimer += elapsedMillis;
                if(mHurtExplosionTimer >= HURT_EXPLOSION_MILLIS) {
                    mHurtExplosionTimer = 0;
                    if(mSpriteAnimation.mState == ANIMATION_HURT) {
                        mSpriteAnimation.setState(mOldAnimationState, true);
                    }
                    else {
                        mOldAnimationState = mSpriteAnimation.mState;
                        mSpriteAnimation.setState(ANIMATION_HURT, true);
                    }
                }
            }
        }

        switch(mState) {
            case STATE_SHOWBOAT:
                mSpriteAnimation.setState(ANIMATION_PUNCH, true);
                mState = STATE_WAIT_FOR_ONESHOT;
                mStateNext = STATE_REDIRECT;
                break;
            case STATE_REDIRECT:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1: -1;
                final double random = Math.random();
                if(random <= .1) {
                    // jump toward
                    mVelocityX = VELOCITY_X * mDirection;
                    mVelocityY = JUMP_VELOCITY;
                    mSpriteAnimation.setState(ANIMATION_JUMP, true);
                    mState = STATE_WAIT_FOR_LAND;
                    mStateNext = STATE_REDIRECT;
                    mStateTimer = 200;
                }
                else if(random <= .2) {
                    // jump away
                    mVelocityX = -VELOCITY_X * mDirection;
                    mVelocityY = JUMP_VELOCITY;
                    mSpriteAnimation.setState(ANIMATION_JUMP, true);
                    mState = STATE_WAIT_FOR_LAND;
                    mStateNext = STATE_REDIRECT;
                    mStateTimer = 200;
                }
                else if(random <= .3) {
                    // walk toward
                    mState = STATE_WAIT_FOR_TIME;
                    mStateNext = STATE_REDIRECT;
                    mStateTimer = 1000;
                    mSpriteAnimation.setState(ANIMATION_WALK, true);
                    mVelocityY = 0;
                    mVelocityX = VELOCITY_X * mDirection;
                }
                else if(random <= .33) {
                    // walk away
                    mState = STATE_WAIT_FOR_TIME;
                    mStateNext = STATE_REDIRECT;
                    mStateTimer = 1000;
                    mSpriteAnimation.setState(ANIMATION_WALK, true);
                    mVelocityY = 0;
                    mVelocityX = -VELOCITY_X * mDirection;
                }
                else if(random <= .9 && !mFire.isEmpty()) {
                    // shoot
                    mState = STATE_WAIT_FOR_TIME;
                    mStateNext = STATE_REDIRECT;
                    mStateTimer = 400;
                    mSpriteAnimation.setState(ANIMATION_SHOOT, true);
                    mVelocityX = 0;
                    mVelocityY = 0;
                    if(!mFire.isEmpty()) {
                        final WeaponFire fire = mFire.remove(0);
                        if(mDirection == 1) fire.init(mBoundingBox.right + 10, mBoundingBox.top + 6, mDirection);
                        else fire.init(mBoundingBox.left - 24, mBoundingBox.top + 6, mDirection);
                        fire.addGameObjects(gameEngine);
                    }
                }
                else {
                    // stand
                    mState = STATE_WAIT_FOR_TIME;
                    mStateNext = STATE_REDIRECT;
                    mStateTimer = 400;
                    mSpriteAnimation.setState(ANIMATION_STAND, true);
                    mVelocityY = 0;
                    mVelocityX = 0;
                }
                break;
            case STATE_WAIT_FOR_ONESHOT:
                if(mSpriteAnimation.mOneShotFired) mState = mStateNext;
                break;
            case STATE_WAIT_FOR_LAND:
                if(mOnGround) {
                    mState = STATE_WAIT_FOR_TIME;
                    mSpriteAnimation.setState(ANIMATION_STAND, true);
                    mVelocityX = 0;
                }
                break;
            case STATE_WAIT_FOR_TIME:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    mState = mStateNext;
                }
                break;
        }

        gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

        mSpriteAnimation.onUpdate(elapsedMillis);
    }

    @Override
    public void weaponFireRelease(WeaponFire weaponFire) {
        mFire.add(weaponFire);
    }
}
