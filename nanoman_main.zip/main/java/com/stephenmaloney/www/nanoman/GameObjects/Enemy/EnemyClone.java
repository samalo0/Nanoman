package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.DeathExplosion;
import com.stephenmaloney.www.nanoman.GameObjects.Dust;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.Player.PlayerAnimationSet;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricity;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFire;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;
import static com.stephenmaloney.www.nanoman.GameObjects.Player.PlayerAnimationSet.COLOR_BOMB;

public class EnemyClone extends SpriteAnimatedMirroredWeapons{
    public final static String TYPE = "EnemyClone";

    private final static float WALK_VELOCITY = .08f;
    private final static float JUMP_VELOCITY = -.35f;

    private final static int ANIMATION_STAND = 0;
    private final static int ANIMATION_STAND_SHOOT = 3;
    private final static int ANIMATION_STAND_THROW = 4;
    private final static int ANIMATION_WALK = 5;
    private final static int ANIMATION_WALK_SHOOT = 7;
    private final static int ANIMATION_JUMP = 9;
    private final static int ANIMATION_JUMP_SHOOT = 11;
    private final static int ANIMATION_JUMP_THROW = 12;
    private final static int ANIMATION_HURT = 18;

    private final static int STATE_REDIRECT = 0;
    private final static int STATE_WALK_TOWARD = 1;
    private final static int STATE_WALK_AWAY = 2;
    private final static int STATE_JUMP_TOWARD = 3;
    private final static int STATE_JUMP_AWAY = 4;
    private final static int STATE_SHOOT = 5;
    private final static int STATE_WAIT_FOR_LANDING = 6;
    private final static int STATE_CONTINUE_FOR_TIME = 7;
    private int mState = STATE_REDIRECT;
    private int mStateTimer = 0;

    private int[][] mStateListPaths = {
            {STATE_WALK_TOWARD, STATE_SHOOT, STATE_WALK_AWAY, STATE_WALK_AWAY},
            {STATE_SHOOT, STATE_WALK_AWAY, STATE_JUMP_AWAY, STATE_SHOOT, STATE_WAIT_FOR_LANDING},
            {STATE_JUMP_TOWARD, STATE_SHOOT, STATE_WAIT_FOR_LANDING, STATE_WALK_TOWARD},
            {STATE_SHOOT, STATE_WALK_TOWARD, STATE_JUMP_TOWARD, STATE_SHOOT, STATE_WAIT_FOR_LANDING},
    };
    private int mStateListCurrentPath;
    private int mStateListCurrentIndex;

    private final static int PSHOT_DAMAGE = 8;
    private final static int BOMB_DAMAGE = 12;
    private final static int CUTTER_DAMAGE = 8;
    private final static int ELECTRICITY_DAMAGE = 8;
    private final static int FIRE_DAMAGE = 4;
    private final static int ICE_DAMAGE = 8;

    private final EnemyHealthBar mHealthBar;
    private boolean mHealthBarAdded = false;

    private final List<DeathExplosion> mDeathExplosions = new ArrayList<>();
    private final static int DEATH_EXPLOSION_LIMIT = 16;

    private boolean mHurtOrDead = false;
    private final static int HURT_MILLIS = 1500;
    private int mHurtTimer;
    private final static int HURT_BLINK_MILLIS = 40;
    private int mHurtBlinkTimer;
    private boolean mVisible = true;

    // weapons
    private final List<WeaponBomb> mWeaponBomb = new ArrayList<>();
    private final static int WEAPON_BOMB_LIMIT = 2;
    private final List<WeaponCutter> mWeaponCutter = new ArrayList<>();
    private final static int WEAPON_CUTTER_LIMIT = 1;
    private final List<WeaponElectricity> mWeaponElectricity = new ArrayList<>();
    private final static int WEAPON_ELECTRICITY_LIMIT = 1;
    private final List<WeaponFire> mWeaponFire = new ArrayList<>();
    private final static int WEAPON_FIRE_LIMIT = 1;
    private final List<WeaponIce> mWeaponIce = new ArrayList<>();
    private final static int WEAPON_ICE_LIMIT = 1;
    private final List<WeaponPShot> mWeaponPShots = new ArrayList<>();
    private final static int WEAPON_PSHOT_LIMIT = 2;

    private final PlayerAnimationSet mAnimations;

    public EnemyClone(Resources resources, HashMap<String, String> properties) {
        super(resources, 8, 0, 12, 24);
        mFacingLeftAdjustmentX = 28;
        mPlayerDamage = 20;

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) - 8;
        updateBoundingBox();

        mDirection = Integer.parseInt(properties.get("Direction"));

        mAnimations = new PlayerAnimationSet(resources);

        mHealthBar = new EnemyHealthBar(resources);

        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) mDeathExplosions.add(new DeathExplosion(resources, R.drawable.animation_enemy_death, i));
        for(int i = 0; i < WEAPON_BOMB_LIMIT; i++) mWeaponBomb.add(new WeaponBomb(resources, this, false));
        for(int i = 0; i < WEAPON_CUTTER_LIMIT; i++) mWeaponCutter.add(new WeaponCutter(resources, this));
        for(int i = 0; i < WEAPON_ELECTRICITY_LIMIT; i++) mWeaponElectricity.add(new WeaponElectricity(resources, this));
        for(int i = 0; i < WEAPON_FIRE_LIMIT; i++) mWeaponFire.add(new WeaponFire(resources, this));
        for(int i = 0; i < WEAPON_ICE_LIMIT; i++) mWeaponIce.add(new WeaponIce(resources, this));
        for(int i = 0; i < WEAPON_PSHOT_LIMIT; i++) mWeaponPShots.add(new WeaponPShot(resources, this));
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || (otherObject instanceof WeaponCutter && ((WeaponCutter) otherObject).mParent != this)
                || (otherObject instanceof WeaponElectricityHorizontal && ((WeaponElectricityHorizontal) otherObject).mParent != this)
                || (otherObject instanceof WeaponElectricityVertical && ((WeaponElectricityVertical) otherObject).mParent != this)
                || (otherObject instanceof WeaponFireHorizontal && ((WeaponFireHorizontal) otherObject).mParent != this)
                || (otherObject instanceof WeaponFireSpinner && ((WeaponFireSpinner) otherObject).mParent != this)
                || otherObject instanceof WeaponIce
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot) mHealthBar.remove(PSHOT_DAMAGE);
        else if(otherObject instanceof WeaponElectricityHorizontal || otherObject instanceof WeaponElectricityVertical) mHealthBar.remove(ELECTRICITY_DAMAGE);
        else if(otherObject instanceof WeaponFireHorizontal || otherObject instanceof WeaponFireSpinner) mHealthBar.remove(FIRE_DAMAGE);
        else if(otherObject instanceof WeaponBomb) mHealthBar.remove(BOMB_DAMAGE);
        else if(otherObject instanceof WeaponCutter) mHealthBar.remove(CUTTER_DAMAGE);
        else if(otherObject instanceof WeaponIce) mHealthBar.remove(ICE_DAMAGE);

        if(mHealthBar.isEmpty()) onDeath(gameEngine);
        else onHurt(gameEngine);
    }

    private void onDeath(GameEngine gameEngine) {
        mHurtOrDead = true;

        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) {
            DeathExplosion exp = mDeathExplosions.get(i);
            exp.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(exp);
        }

        gameEngine.removeGameObject(mHealthBar);
        gameEngine.removeGameObject(this);

        gameEngine.mPlayer.warpOut(Player.WARP_DESTINATION_WILY3);

        gameEngine.soundPlay(GameEngine.GameSound.PLAYER_DEATH);
        gameEngine.musicPlayOnce(R.raw.music_victory);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mVisible) {
            if(!GameEngine.isObjectVisible(mBoundingBox)) return;

            mMatrix.reset();
            if (mDirection == -1) {
                mMatrix.postScale(-1, 1);
                mMatrix.postTranslate(mFacingLeftAdjustmentX, 0);
            }
            mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);

            canvas.drawBitmap(mAnimations.getBitmap(), mMatrix, GameView.mPaint);
        }
    }

    private void onHurt(GameEngine gameEngine) {
        mHurtOrDead = true;
        mHurtTimer = 0;
        mHurtBlinkTimer = 0;

        // create dust
        dustAdd(gameEngine);

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            if (mHealthBarAdded) {
                mHealthBarAdded = false;
                gameEngine.removeGameObject(mHealthBar);
            }
            return;
        }

        if (!mHealthBarAdded) {
            mHealthBarAdded = true;
            gameEngine.addGameObject(mHealthBar);
            gameEngine.musicPlayLooped(R.raw.music_wily_boss_theme);
        }

        if(mHurtOrDead) {
            mHurtTimer += elapsedMillis;
            if(mHurtTimer >= HURT_MILLIS) {
                mHurtOrDead = false;
                mVisible = true;
                mHurtBlinkTimer = 0;
            }
            else {
                mHurtBlinkTimer += elapsedMillis;
                if(mHurtBlinkTimer >= HURT_BLINK_MILLIS) {
                    mHurtBlinkTimer = 0;
                    mVisible = !mVisible;
                }
            }
        }

        switch(mState) {
            case STATE_REDIRECT:
                final int enemyQuadrant = (mBoundingBox.centerX() - GameView.mViewPort.left) / (GameView.VIEW_WIDTH >> 2);
                final int playerQuadrant = (gameEngine.mPlayer.mBoundingBox.centerX() - GameView.mViewPort.left) / (GameView.VIEW_WIDTH >> 2);

                mStateListCurrentPath = Math.abs(enemyQuadrant - playerQuadrant);
                mStateListCurrentIndex = 0;
                mState = mStateListPaths[mStateListCurrentPath][mStateListCurrentIndex];
                break;
            case STATE_WALK_TOWARD:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;
                mAnimations.setState(ANIMATION_WALK, true);
                mVelocityX = mDirection * WALK_VELOCITY;
                mState = STATE_CONTINUE_FOR_TIME;
                mStateTimer = 300;
                break;
            case STATE_WALK_AWAY:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? -1 : 1;
                mAnimations.setState(ANIMATION_WALK, true);
                mVelocityX = mDirection * WALK_VELOCITY;
                mState = STATE_CONTINUE_FOR_TIME;
                mStateTimer = 300;
                break;
            case STATE_JUMP_TOWARD:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;
                mAnimations.setState(ANIMATION_JUMP, true);
                mVelocityX = mDirection * WALK_VELOCITY;
                mVelocityY = JUMP_VELOCITY;
                mState = STATE_CONTINUE_FOR_TIME;
                mStateTimer = 200;
                mJustLanded = false;
                break;
            case STATE_JUMP_AWAY:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? -1 : 1;
                mAnimations.setState(ANIMATION_JUMP, true);
                mVelocityX = mDirection * WALK_VELOCITY;
                mVelocityY = JUMP_VELOCITY;
                mState = STATE_CONTINUE_FOR_TIME;
                mStateTimer = 200;
                mJustLanded = false;
                break;
            case STATE_SHOOT:
                mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;

                switch(gameEngine.mPlayer.mWeaponSelected) {
                    case Player.WEAPON_BOMB:
                        mAnimations.setColor(PlayerAnimationSet.COLOR_BOMB);
                        if (!mWeaponBomb.isEmpty()) {
                            final WeaponBomb bomb = mWeaponBomb.remove(0);
                            if (mDirection == 1)
                                bomb.init(mBoundingBox.right + 8, mBoundingBox.top + 6, mDirection, mVelocityX * .7f, mVelocityY * .7f);
                            else
                                bomb.init(mBoundingBox.left - 22, mBoundingBox.top + 6, mDirection, mVelocityX * .7f, mVelocityY * .7f);
                            gameEngine.addGameObject(bomb);

                            if(mOnGround) mVelocityX = 0;
                        }
                        break;
                    case Player.WEAPON_CUTTER:
                        mAnimations.setColor(PlayerAnimationSet.COLOR_CUT);
                        if (!mWeaponCutter.isEmpty()) {
                            final WeaponCutter cutter = mWeaponCutter.remove(0);
                            if (mDirection == 1)
                                cutter.init(mBoundingBox.right + 8, mBoundingBox.centerY(), mDirection, gameEngine);
                            else cutter.init(mBoundingBox.left - 22, mBoundingBox.centerY(), mDirection, gameEngine);
                            gameEngine.addGameObject(cutter);

                            if(mOnGround) mVelocityX = 0;
                        }
                        break;
                    case Player.WEAPON_ELECTRICITY:
                        mAnimations.setColor(PlayerAnimationSet.COLOR_ELEC);
                        if (!mWeaponElectricity.isEmpty()) {
                            final WeaponElectricity electricity = mWeaponElectricity.remove(0);
                            if (mDirection == 1)
                                electricity.init(mBoundingBox.right + 14, mBoundingBox.top - 9, mDirection);
                            else electricity.init(mBoundingBox.left - 47, mBoundingBox.top - 9, mDirection);
                            electricity.addGameObjects(gameEngine);
                        }
                        break;
                    case Player.WEAPON_FIRE:
                        mAnimations.setColor(PlayerAnimationSet.COLOR_FIRE);
                        if (!mWeaponFire.isEmpty()) {
                            final WeaponFire fire = mWeaponFire.remove(0);
                            if (mDirection == 1) fire.init(mX + 35, mY + 3, mDirection);
                            else fire.init(mX - 20, mY + 3, mDirection);
                            fire.addGameObjects(gameEngine);
                        }
                        break;
                    case Player.WEAPON_ICE:
                        mAnimations.setColor(PlayerAnimationSet.COLOR_ICE);
                        if (!mWeaponIce.isEmpty()) {
                            final WeaponIce ice = mWeaponIce.remove(0);
                            if (mDirection == 1) ice.init(mX + 35, mY + 3, mDirection, gameEngine);
                            else ice.init(mX - 20, mY + 3, mDirection, gameEngine);
                            gameEngine.addGameObject(ice);
                        }
                        break;
                    case Player.WEAPON_PSHOT:
                    case Player.WEAPON_MAGNET:
                    case Player.WEAPON_GUTS:
                        mAnimations.setColor(PlayerAnimationSet.COLOR_PSHOT);
                        if (!mWeaponPShots.isEmpty()) {
                            final WeaponPShot pShot = mWeaponPShots.remove(0);
                            pShot.init(mX + 30, mY + 8, mDirection, gameEngine);
                            gameEngine.addGameObject(pShot);
                        }
                        break;
                }

                // update animation
                switch(gameEngine.mPlayer.mWeaponSelected) {
                    case Player.WEAPON_PSHOT:
                    case Player.WEAPON_ICE:
                    case Player.WEAPON_FIRE:
                    case Player.WEAPON_ELECTRICITY:
                        if(!mOnGround) mAnimations.setState(ANIMATION_JUMP_SHOOT, true);
                        else {
                            if(mVelocityX == 0) mAnimations.setState(ANIMATION_STAND_SHOOT, true);
                            else mAnimations.setState(ANIMATION_WALK_SHOOT, true);
                        }
                        break;
                    case Player.WEAPON_CUTTER:
                    case Player.WEAPON_BOMB:
                        if(!mOnGround) mAnimations.setState(ANIMATION_JUMP_THROW, true);
                        else mAnimations.setState(ANIMATION_STAND_THROW, true);
                        break;
                }

                mState = STATE_CONTINUE_FOR_TIME;
                mStateTimer = 200;
                break;
            case STATE_WAIT_FOR_LANDING:
                if(mOnGround) {
                    mState = STATE_CONTINUE_FOR_TIME;
                    mStateTimer = 200;
                    gameEngine.soundPlay(GameEngine.GameSound.PLAYER_LAND);
                }
                break;
            case STATE_CONTINUE_FOR_TIME:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    if(mStateListCurrentIndex < (mStateListPaths[mStateListCurrentPath].length - 1)) {
                        mStateListCurrentIndex++;
                        mState = mStateListPaths[mStateListCurrentPath][mStateListCurrentIndex];
                    }
                    else mState = STATE_REDIRECT;
                }
                break;
        }

        mAnimations.onUpdate(elapsedMillis);
        gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);
        if(mJustLanded) {
            if(mVelocityX != 0) mAnimations.setState(ANIMATION_WALK, true);
            else mAnimations.setState(ANIMATION_STAND, true);
            mJustLanded = false;
        }
    }

    @Override
    public void weaponBombRelease(WeaponBomb weaponBomb) {
        mWeaponBomb.add(weaponBomb);
    }

    @Override
    public void weaponCutterRelease(WeaponCutter weaponCutter) {
        mWeaponCutter.add(weaponCutter);
    }

    @Override
    public void weaponElectricityRelease(WeaponElectricity weaponElectricity) {
        mWeaponElectricity.add(weaponElectricity);
    }

    @Override
    public void weaponFireRelease(WeaponFire weaponFire) {
        mWeaponFire.add(weaponFire);
    }

    @Override
    public void weaponIceRelease(WeaponIce weaponIce) {
        mWeaponIce.add(weaponIce);
    }

    @Override
    public void weaponPShotRelease(WeaponPShot weaponPShot) {
        mWeaponPShots.add(weaponPShot);
    }
}
