package com.stephenmaloney.www.nanoman.GameObjects.PowerUps;

import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;

import java.util.HashMap;

public class CheckPoint extends GameObject {
    public final static String TYPE = "CheckPoint";

    private final Rect mBoundingBox;
    private final int mDirection;

    public CheckPoint(HashMap<String, String> properties) {
        // get starting x, y position
        final int absolutePositionX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int absolutePositionY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) - 8;
        mDirection = Integer.parseInt(properties.get("Direction"));

        mBoundingBox = new Rect(absolutePositionX, absolutePositionY, absolutePositionX + Tile.SIZE, absolutePositionY + Tile.SIZE);
    }

    @Override
    public void onDraw(Canvas canvas) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(GameEngine.isObjectVisible(mBoundingBox)) {
            // check point reached
            gameEngine.mPlayer.setCheckPoint(mBoundingBox.left, mBoundingBox.top, mDirection);
            gameEngine.removeGameObject(this);
        }
    }

    @Override
    public void startGame(GameEngine gameEngine) {
    }
}
