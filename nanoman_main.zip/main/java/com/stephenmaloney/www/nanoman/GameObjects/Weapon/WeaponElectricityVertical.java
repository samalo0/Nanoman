package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimated;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.R;

public class WeaponElectricityVertical extends SpriteAnimated {
    public final SpriteAnimatedMirroredWeapons mParent;

    private final static int BOUNDING_BOX_OFFSET_X = 0;
    private final static int BOUNDING_BOX_OFFSET_Y = 0;
    private final static int BOUNDING_BOX_SIZE_X = 11;
    private final static int BOUNDING_BOX_SIZE_Y = 32;

    private final static float VELOCITY_Y = .15f;

    private final WeaponElectricity mWeaponElectricityParent;

    private final int mIndex;

    WeaponElectricityVertical(Resources resources, WeaponElectricity weaponElectricityParent, int index, SpriteAnimatedMirroredWeapons parent) {
        super(BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        mParent = parent;

        mWeaponElectricityParent = weaponElectricityParent;
        mIndex = index;

        mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(R.drawable.animation_weapon_electricity_vertical, null));

        mPlayerDamage = 25;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject != mParent);
    }

    public void init(int x, int y, int direction) {
        mXFractional = 0;
        mYFractional = 0;
        mX = x;
        mY = y;
        mDirection = direction;
        updateBoundingBox();

        mVelocityY = mDirection * VELOCITY_Y;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mWeaponElectricityParent.releaseVertical(mIndex);
        }

        mSpriteAnimation.onUpdate(elapsedMillis);

        final double dY = mVelocityY * elapsedMillis + mYFractional;
        mY += (int) dY;
        mYFractional = dY % 1;
        updateBoundingBox();
    }
}
