package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public abstract class SpriteFrameAnimationMirrored extends Sprite {
    protected final Bitmap[] mFrames;
    public int mFrame = 0;
    private final int mFacingLeftAdjustment;

    public SpriteFrameAnimationMirrored(int boundingBoxOffsetX, int boundingBoxOffsetY, int boundingBoxSizeX, int boundingBoxSizeY, int numberOfFrames, int facingLeftAdjustment) {
        super(boundingBoxOffsetX, boundingBoxOffsetY, boundingBoxSizeX, boundingBoxSizeY);
        mFrames = new Bitmap[numberOfFrames];
        mFacingLeftAdjustment = facingLeftAdjustment;
    }

    @Override
    public void onDraw(Canvas canvas) {
        if (!GameEngine.isObjectVisible(mBoundingBox)) return;

        mMatrix.reset();
        if (mDirection == -1) {
            mMatrix.postScale(-1, 1);
            mMatrix.postTranslate(mFacingLeftAdjustment, 0);
        }
        GameView.mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);

        canvas.drawBitmap(mFrames[mFrame], GameView.mMatrix, GameView.mPaint);
    }
}
