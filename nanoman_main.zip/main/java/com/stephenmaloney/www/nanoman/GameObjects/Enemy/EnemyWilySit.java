package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimated;
import com.stephenmaloney.www.nanoman.R;

class EnemyWilySit extends SpriteAnimated {
    private final static int WILY_OFFSET_X = 34;
    private final static int WILY_OFFSET_Y = 39;

    EnemyWilySit(Resources resources) {
        super(0, 0, 23, 21);

        mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_wily_sit, null));
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) { return false; }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {}

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mSpriteAnimation.onUpdate(elapsedMillis);
    }

    void updateLocation(int x, int y) {
        mX = x + WILY_OFFSET_X;
        mY = y + WILY_OFFSET_Y;
        updateBoundingBox();
    }
}
