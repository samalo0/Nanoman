package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

class EnemyFlyingNutShot extends EnemyShot {
    private final EnemyFlyingNut mParent;
    private final int mIndex;

    private final static float VELOCITY = .2f;

    private final int OFFSET_X;
    private final int OFFSET_Y;
    private final static int RADIUS = 14;

    EnemyFlyingNutShot(Resources resources, int resource_id, int index, EnemyFlyingNut parent) {
        super(resources, resource_id);
        mParent = parent;

        mIndex = index;

        switch (mIndex) {
            case 0:
                mDirection = -1;
                mVelocityX = VELOCITY * -1;
                mVelocityY = 0;
                OFFSET_X = -RADIUS;
                OFFSET_Y = 0;
                break;
            case 1:
                mDirection = -1;
                mVelocityX = VELOCITY * (float)Math.cos(135 * Math.PI / 180);
                mVelocityY = VELOCITY * (float)Math.sin(135 * Math.PI / 180);
                OFFSET_X = (int)(RADIUS * (float)Math.cos(135 * Math.PI / 180));
                OFFSET_Y = (int)(RADIUS * (float)Math.sin(135 * Math.PI / 180));
                break;
            case 2:
                mDirection = -1;
                mVelocityX = 0;
                mVelocityY = -1 * VELOCITY;
                OFFSET_X = 0;
                OFFSET_Y = -RADIUS;
                break;
            case 3:
                mDirection = 1;
                mVelocityX = VELOCITY * (float)Math.cos(45 * Math.PI / 180);
                mVelocityY = VELOCITY * (float)Math.sin(45 * Math.PI / 180);
                OFFSET_X = (int)(RADIUS * (float)Math.cos(45 * Math.PI / 180));
                OFFSET_Y = (int)(RADIUS * (float)Math.sin(45 * Math.PI / 180));
                break;
            case 4:
                mDirection = 1;
                mVelocityX = VELOCITY;
                mVelocityY = 0;
                OFFSET_X = RADIUS;
                OFFSET_Y = 0;
                break;
            case 5:
                mDirection = 1;
                mVelocityX = VELOCITY * (float)Math.cos(-45 * Math.PI / 180);
                mVelocityY = VELOCITY * (float)Math.sin(-45 * Math.PI / 180);
                OFFSET_X = (int)(RADIUS * (float)Math.cos(-45 * Math.PI / 180));
                OFFSET_Y = (int)(RADIUS * (float)Math.sin(-45 * Math.PI / 180));
                break;
            case 6:
                mDirection = -1;
                mVelocityX = 0;
                mVelocityY = VELOCITY;
                OFFSET_X = 0;
                OFFSET_Y = RADIUS;
                break;
            case 7:
                mDirection = 1;
                mVelocityX = VELOCITY * (float)Math.cos(-135 * Math.PI / 180);
                mVelocityY = VELOCITY * (float)Math.sin(-135 * Math.PI / 180);
                OFFSET_X = (int)(RADIUS * (float)Math.cos(-135 * Math.PI / 180));
                OFFSET_Y = (int)(RADIUS * (float)Math.sin(-135 * Math.PI / 180));
                break;
            default:
                OFFSET_X = 0;
                OFFSET_Y = 0;
                break;

        }
    }

    @Override
    void init(int x, int y, GameEngine gameEngine) {
        mX = x + OFFSET_X;
        mY = y + OFFSET_Y;
        updateBoundingBox();

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_SHOOT);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            mParent.releaseShot(mIndex);
            gameEngine.removeGameObject(this);
        }

        super.onUpdate(elapsedMillis, gameEngine);
    }
}
