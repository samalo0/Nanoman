package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

public class EnemyFlyingNut extends SpriteFrameAnimation {
    private final static float VELOCITY = .08f;

    private final EnemyFlyingNutSpawn mParent;

    private final static int STATE_DEFENSE = 0;
    private final static int STATE_OPEN_UP = 1;
    private final static int STATE_SHOOT = 2;
    private final static int STATE_CLOSE = 3;
    private final static int STATE_STUNNED = 4;
    private int mState = STATE_DEFENSE;
    private int mOldState;
    private int mStateTimer = 0;
    private int mStunnedTimer = 0;

    private final Rect boundingBoxClosed = new Rect(0, 0, 16, 16);
    private final Rect boundingBoxOpened = new Rect(0, 0, 17, 21);

    private final EnemyFlyingNutShot mShots[] = new EnemyFlyingNutShot[SHOT_LIMIT];
    private boolean mShotReleased[] = new boolean[SHOT_LIMIT];
    private final static int SHOT_LIMIT = 8;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    EnemyFlyingNut(Resources resources, int direction, int startY, EnemyFlyingNutSpawn parent) {
        super(0, 0, 16, 16, 2);

        mParent = parent;
        mDirection = direction;

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_flying_nut_closed);

        if(mDirection == -1) {
            final Bitmap bitmap = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_flying_nut_open);
            final Matrix mMatrix = new Matrix();
            mMatrix.preScale(-1, 1);
            mFrames[1] = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), mMatrix, false);
        }
        else mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_flying_nut_open);

        mVelocityX = mDirection * VELOCITY;
        mY = startY;

        for(int i = 0; i < SHOT_LIMIT; i++) {
            mShots[i] = new EnemyFlyingNutShot(resources, R.drawable.gameobject_enemy_shot_orange, i, this);
            mShotReleased[i] = true;
        }

        mPlayerDamage = 8;

        mExplosion = new Explosion(resources);
    }

    void init() {
        mHurtOrDead = false;

        if(mDirection == 1) mX = GameView.mViewPort.left;
        else mX = GameView.mViewPort.right - 1;

        mStateTimer = 0;
        mState = STATE_DEFENSE;
        mFrame = 0;
        mBoundingBox.set(boundingBoxClosed);
        updateBoundingBox();

        mVelocityX = mDirection * VELOCITY;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(mState == STATE_DEFENSE) {
            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DINK);
            return;
        }

        if(otherObject instanceof WeaponIce) {
            if(mState != STATE_STUNNED) {
                mOldState = mState;
                mState = STATE_STUNNED;
            }
            mStunnedTimer = 0;
        }
        else if(otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts
                || otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner) {

            mHurtOrDead = true;

            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

            gameEngine.removeGameObject(this);
            mParent.releaseNut();

            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseNut();
            return;
        }

        switch(mState) {
            case STATE_DEFENSE:
                mStateTimer += elapsedMillis;
                if(mStateTimer > 1250) {
                    mStateTimer = 0;
                    mFrame = 1;
                    mState = STATE_OPEN_UP;
                    mBoundingBox.set(boundingBoxOpened);
                    updateBoundingBox();
                }
                else {
                    double distanceX = mVelocityX * elapsedMillis + mXFractional;
                    mX += (int) distanceX;
                    mXFractional = distanceX % 1;
                    updateBoundingBox();
                }
                break;
            case STATE_OPEN_UP:
                mStateTimer += elapsedMillis;
                if(mStateTimer > 200) {
                    mStateTimer = 0;
                    mState = STATE_SHOOT;
                }
                break;
            case STATE_SHOOT:
                for(int i = 0; i < SHOT_LIMIT; i++) {
                    if(mShotReleased[i]) {
                        mShotReleased[i] = false;
                        mShots[i].init(mBoundingBox.centerX() - 3, mBoundingBox.centerY() - 3, gameEngine);
                        gameEngine.addGameObject(mShots[i]);
                    }
                }
                mState = STATE_CLOSE;
                break;
            case STATE_CLOSE:
                mStateTimer += elapsedMillis;
                if(mStateTimer > 200) {
                    mStateTimer = 0;
                    mState = STATE_DEFENSE;
                    mFrame = 0;
                    mBoundingBox.set(boundingBoxClosed);
                    updateBoundingBox();
                }
                break;
            case STATE_STUNNED:
                mStunnedTimer += elapsedMillis;
                if(mStunnedTimer >= 2000) {
                    mStunnedTimer = 0;
                    mState = mOldState;
                }
                break;
        }
    }

    void releaseShot(int index) {
        mShotReleased[index] = true;
    }
}
