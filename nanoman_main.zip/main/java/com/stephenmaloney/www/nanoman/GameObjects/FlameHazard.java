package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class FlameHazard extends SpriteFrameAnimation {
    public final static String TYPE = "FlameHazard";

    private final static float VELOCITY = .8f;

    private final Rect[] mBoundingBoxes = new Rect[4];

    private final static int STATE_START = 0;
    private final static int STATE_DOWN1 = 1;
    private final static int STATE_LEFT1 = 2;
    private final static int STATE_DOWN2 = 3;
    private final static int STATE_RIGHT1 = 4;
    private final static int STATE_DOWN3 = 5;
    private int mState = STATE_START;

    FlameHazard(Resources resources) {
        super(0, 0, 16, 32, 4);

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_flame_hazard_left);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_flame_hazard_up);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_flame_hazard_right);
        mFrames[3] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_flame_hazard_down);

        mBoundingBoxes[0] = new Rect(0, 0, 16, 32);
        mBoundingBoxes[1] = new Rect(0, 0, 32, 16);
        mBoundingBoxes[2] = new Rect(0, 0, 16, 32);
        mBoundingBoxes[3] = new Rect(0, 0, 32, 16);

        mPlayerDamage = 25;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {}

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        switch(mState) {
            case STATE_START:
                // start from the top of the lava pour
                mX = 155 << Tile.SIZE_POW_2;
                mY = 30 << Tile.SIZE_POW_2;
                mVelocityX = 0;
                mVelocityY = VELOCITY;
                mState = STATE_DOWN1;
                mFrame = 3;
                mBoundingBox.set(mBoundingBoxes[3]);
                updateBoundingBox();
                break;
            case STATE_DOWN1:
                if(mY >= (35 << Tile.SIZE_POW_2)) {
                    mState = STATE_LEFT1;
                    mX = 156 << Tile.SIZE_POW_2;
                    mY = 34 << Tile.SIZE_POW_2;
                    mVelocityX = -VELOCITY;
                    mVelocityY = 0f;
                    mFrame = 0;
                    mBoundingBox.set(mBoundingBoxes[0]);
                    updateBoundingBox();
                }
                break;
            case STATE_LEFT1:
                if(mX <= (147 << Tile.SIZE_POW_2)) {
                    mState = STATE_DOWN2;
                    mX = 147 << Tile.SIZE_POW_2;
                    mY = 34 << Tile.SIZE_POW_2;
                    mVelocityX = 0f;
                    mVelocityY = VELOCITY;
                    mFrame = 3;
                    mBoundingBox.set(mBoundingBoxes[3]);
                    updateBoundingBox();
                }
                break;
            case STATE_DOWN2:
                if(mY >= (40 << Tile.SIZE_POW_2)) {
                    mState = STATE_RIGHT1;
                    mX = 147 << Tile.SIZE_POW_2;
                    mY = 39 << Tile.SIZE_POW_2;
                    mVelocityX = VELOCITY;
                    mVelocityY = 0f;
                    mFrame = 2;
                    mBoundingBox.set(mBoundingBoxes[2]);
                    updateBoundingBox();
                }
                break;
            case STATE_RIGHT1:
                if(mX >= (157 << Tile.SIZE_POW_2)) {
                    mState = STATE_DOWN3;
                    mX = 156 << Tile.SIZE_POW_2;
                    mY = 39 << Tile.SIZE_POW_2;
                    mVelocityX = 0f;
                    mVelocityY = VELOCITY;
                    mFrame = 3;
                    mBoundingBox.set(mBoundingBoxes[3]);
                    updateBoundingBox();
                }
                break;
            case STATE_DOWN3:
                if(mY >= (58 << Tile.SIZE_POW_2)) mState = STATE_START;
                break;
        }

        final double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY= mVelocityY * elapsedMillis + mYFractional;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;

        updateBoundingBox();
    }
}
