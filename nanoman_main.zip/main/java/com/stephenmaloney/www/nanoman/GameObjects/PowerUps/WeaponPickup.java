package com.stephenmaloney.www.nanoman.GameObjects.PowerUps;

import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimated;
import com.stephenmaloney.www.nanoman.R;

public class WeaponPickup extends SpriteAnimated {
    private final static int BOUNDING_BOX_SIZE_X = 16;
    private final static int BOUNDING_BOX_SIZE_Y = 16;
    private final static int BOUNDING_BOX_OFFSET_X = 0;
    private final static int BOUNDING_BOX_OFFSET_Y = 0;

    public final int mType;

    public WeaponPickup(Resources resources, int type) {
        super(BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(R.drawable.animation_weapon_pickup, null));

        mType = type;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    public void init(int x, int y) {
        mX = x - 8;
        mY = y - 8;
        mVelocityY = -.2f;
        updateBoundingBox();
    }
    
    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mSpriteAnimation.onUpdate(elapsedMillis);

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);
    }
}
