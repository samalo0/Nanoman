package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;

import java.util.HashMap;

public class EnemyHelicopterSpawn extends GameObject {
    public final static String TYPE = "EnemyHelicopter";

    private final Rect mBoundingBox;

    private final EnemyHelicopter mHelicopter;
    private boolean mHelicopterReleased = true;
    private int mDelay = 0;


    public EnemyHelicopterSpawn(GameEngine gameEngine, HashMap<String, String> properties) {
        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;

        mBoundingBox = new Rect(x, y, x + Tile.SIZE, y + Tile.SIZE);

        final int direction = Integer.parseInt(properties.get("Direction"));
        final String color = properties.get("Color");
        mHelicopter = new EnemyHelicopter(gameEngine.getResources(), color, direction, gameEngine.mPlayer.mBoundingBox, this);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(GameEngine.isObjectVisible(mBoundingBox)) {
            mDelay += elapsedMillis;
            if(!mHelicopterReleased) mDelay = 0;
            else if(mDelay >= 1000) {
                mHelicopterReleased = false;
                mHelicopter.init();
                gameEngine.addGameObject(mHelicopter);
            }
        }
    }

    void releaseHelicopter(){
        mHelicopterReleased = true;
    }
}
