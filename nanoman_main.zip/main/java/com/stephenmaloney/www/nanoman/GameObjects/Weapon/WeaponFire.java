package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.R;

public class WeaponFire {
    private WeaponFireHorizontal mHorizontal;
    private final WeaponFireSpinner[] mSpinner = new WeaponFireSpinner[3];

    private final SpriteAnimatedMirroredWeapons mParent;

    private boolean mHorizontalReleased = true;
    private boolean[] mSpinnerReleased = {true, true, true};

    public WeaponFire(Resources resources, SpriteAnimatedMirroredWeapons parent) {
        mParent = parent;

        mHorizontal = new WeaponFireHorizontal(resources, this, parent);

        mSpinner[0] = new WeaponFireSpinner(resources, R.drawable.weapon_fire_spinner1, 0, 0, 16, 16, 0, parent.mBoundingBox, this, parent);
        mSpinner[1] = new WeaponFireSpinner(resources, R.drawable.weapon_fire_spinner2, 2, 2, 12, 12, 1, parent.mBoundingBox, this, parent);
        mSpinner[2] = new WeaponFireSpinner(resources, R.drawable.weapon_fire_spinner3, 5, 5, 6, 6, 2, parent.mBoundingBox, this, parent);
    }

    public void addGameObjects(GameEngine gameEngine) {
        mHorizontalReleased = false;
        for(int i = 0; i < 3; i++) mSpinnerReleased[i] = false;

        gameEngine.addGameObject(mHorizontal);

        gameEngine.addGameObject(mSpinner[0]);
        gameEngine.addGameObject(mSpinner[1]);
        gameEngine.addGameObject(mSpinner[2]);

        gameEngine.soundPlay(GameEngine.GameSound.WEAPON_FIRE);
    }

    public void init(int x, int y, int direction) {
        mHorizontal.init(x, y, direction);

        mSpinner[0].init(direction);
        mSpinner[1].init(direction);
        mSpinner[2].init(direction);
    }

    void releaseHorizontal() {
        mHorizontalReleased = true;
        if(mSpinnerReleased[0] && mSpinnerReleased[1] && mSpinnerReleased[2]) mParent.weaponFireRelease(this);
    }

    void releaseSpinner(int index) {
        mSpinnerReleased[index] = true;
        if(mHorizontalReleased && mSpinnerReleased[0] && mSpinnerReleased[1] && mSpinnerReleased[2]) mParent.weaponFireRelease(this);
    }
}
