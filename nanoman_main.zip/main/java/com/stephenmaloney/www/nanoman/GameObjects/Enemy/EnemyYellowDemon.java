package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public class EnemyYellowDemon extends GameObject {
    public final static String TYPE = "EnemyYellowDemon";

    private final static int LOCATION_RIGHT_X = 3478;
    private final static int LOCATION_RIGHT_Y = 590;
    private final static int LOCATION_LEFT_X = 3344;
    private final static int LOCATION_LEFT_Y = 590;

    private final static int HEIGHT_DIVISION = 5;
    private final static int WIDTH_DIVISION = 4;
    private final static int WIDTH = 90;
    private final static int HEIGHT = 82;

    final static int SEGMENT_WIDTH = (int)Math.ceil((float)WIDTH / WIDTH_DIVISION);
    final static int SEGMENT_HEIGHT = (int)Math.ceil((float)HEIGHT / HEIGHT_DIVISION);

    private final static int NUMBER_OF_PARTICLES = HEIGHT_DIVISION * WIDTH_DIVISION;
    private final EnemyYellowDemonParticle[] mParticles = new EnemyYellowDemonParticle[NUMBER_OF_PARTICLES];
    private int mParticleCounter = 0;

    private final EnemyYellowDemonEye mEye;
    private boolean mEyeReleased = true;

    private final static int STATE_WAIT_FOR_VISIBLE = 0;
    private final static int STATE_INITIAL_FLY_IN_FROM_RIGHT = 1;
    private final static int STATE_SHOW_EYE_LEFT = 2;
    private final static int STATE_FLY_RIGHT = 3;
    private final static int STATE_SHOW_EYE_RIGHT = 4;
    private final static int STATE_FLY_LEFT = 5;
    private final static int STATE_WAIT = 6;
    private final static int STATE_DEATH = 7;
    private int mState = STATE_WAIT_FOR_VISIBLE;
    private int mStateTimer = 0;
    private int mStateNext;

    private final Rect mVisibleBox;

    private final int[] mParticleOrder = {3, 2, 4, 1, 0, 8, 7, 9, 6, 5, 13, 12, 14, 11, 10, 18, 17, 19, 16, 15};

    private final Bitmap[] mBitmapDemonDeath = new Bitmap[2];
    private int mDeathFrame = 0;
    private int mX, mY;

    public EnemyYellowDemon(Resources resources, HashMap<String, String> properties) {
        // get visible position
        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;
        mVisibleBox = new Rect(x, y, x + Tile.SIZE, y + Tile.SIZE);

        final Bitmap bitmapDemon = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_yellow_demon);

        // create particles
        mParticleCounter = 0;
        for(int column = 0; column < WIDTH_DIVISION; column++) {
            for(int row = 0; row < HEIGHT_DIVISION; row++) {
                final Rect rectSegmentLeft = new Rect(column * SEGMENT_WIDTH, row * SEGMENT_HEIGHT, (column + 1) * SEGMENT_WIDTH, (row + 1) * SEGMENT_HEIGHT);

                final Rect rectLeft = new Rect(rectSegmentLeft);
                rectLeft.offset(LOCATION_LEFT_X, LOCATION_LEFT_Y);

                final Rect rectRight = new Rect(rectSegmentLeft);
                rectRight.offset(LOCATION_RIGHT_X, LOCATION_RIGHT_Y);

                final Rect rectSegmentRight = new Rect((WIDTH_DIVISION - 1 - column) * SEGMENT_WIDTH, row * SEGMENT_HEIGHT, (WIDTH_DIVISION - column) * SEGMENT_WIDTH, (row + 1) * SEGMENT_HEIGHT);
                mParticles[mParticleCounter] = new EnemyYellowDemonParticle(resources, rectLeft, rectRight, bitmapDemon, rectSegmentLeft, rectSegmentRight);
                mParticleCounter++;
            }
        }

        // create eye
        mEye = new EnemyYellowDemonEye(resources, this);

        // reset counter
        mParticleCounter = 0;

        // get left/right demon death images
        mBitmapDemonDeath[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_yellow_demon_death);
        mMatrix.reset();
        mMatrix.preScale(-1, 1);
        mBitmapDemonDeath[1] = Bitmap.createBitmap(mBitmapDemonDeath[0], 0, 0, mBitmapDemonDeath[0].getWidth(), mBitmapDemonDeath[0].getHeight(), mMatrix, false);
    }

    void onDeath(GameEngine gameEngine, int direction) {
        for(int i = 0; i < NUMBER_OF_PARTICLES; i++) gameEngine.removeGameObject(mParticles[i]);
        mState = STATE_DEATH;
        if(direction == 1) {
            mDeathFrame = 0;
            mX = LOCATION_LEFT_X;
            mY = LOCATION_LEFT_Y;
        }
        else {
            mDeathFrame = 1;
            mX = LOCATION_RIGHT_X;
            mY = LOCATION_RIGHT_Y;
        }

        gameEngine.mPlayer.warpOut(Player.WARP_DESTINATION_WILY2);
        gameEngine.musicPlayOnce(R.raw.music_victory);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mState == STATE_DEATH) {
            mMatrix.reset();
            mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);
            canvas.drawBitmap(mBitmapDemonDeath[mDeathFrame], mMatrix, GameView.mPaint);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        switch(mState) {
            case STATE_WAIT_FOR_VISIBLE:
                if(GameEngine.isObjectVisible(mVisibleBox)) {
                    mState = STATE_INITIAL_FLY_IN_FROM_RIGHT;
                    mEye.addHealthBar(gameEngine);
                    for(int i = 0; i < NUMBER_OF_PARTICLES; i++) gameEngine.addGameObject(mParticles[i]);
                    mStateTimer = 500;
                    gameEngine.musicPlayLooped(R.raw.music_wily_boss_theme);
                }
                break;
            case STATE_INITIAL_FLY_IN_FROM_RIGHT:
                mStateTimer += elapsedMillis;
                if(mStateTimer > 500) {
                    mStateTimer = 0;
                    mParticles[mParticleOrder[mParticleCounter]].flyInFromRight();
                    if(mParticleCounter < (NUMBER_OF_PARTICLES - 1)) mParticleCounter++;
                    else {
                        mState = STATE_WAIT;
                        mStateTimer = 1000;
                        mStateNext = STATE_SHOW_EYE_LEFT;
                    }
                }
                break;
            case STATE_SHOW_EYE_LEFT:
                if(mEyeReleased) {
                    mEye.init(LOCATION_LEFT_X + 40, LOCATION_LEFT_Y + 10, 10, 15, 1);
                    gameEngine.addGameObject(mEye);
                }
                mStateTimer = 2500;
                mState = STATE_WAIT;
                mStateNext = STATE_FLY_RIGHT;
                break;
            case STATE_FLY_RIGHT:
                mStateTimer += elapsedMillis;
                if(mStateTimer > 500) {
                    mStateTimer = 0;
                    mParticles[mParticleOrder[mParticleCounter]].flyToRightFromLeft();
                    if(mParticleCounter > 0) mParticleCounter--;
                    else {
                        mState = STATE_WAIT;
                        mStateTimer = 1000;
                        mStateNext = STATE_SHOW_EYE_RIGHT;
                    }
                }
                break;
            case STATE_SHOW_EYE_RIGHT:
                if(mEyeReleased) {
                    mEye.init(LOCATION_RIGHT_X + 30, LOCATION_RIGHT_Y + 10, 10, 15, -1);
                    gameEngine.addGameObject(mEye);
                }
                mStateTimer = 2500;
                mState = STATE_WAIT;
                mStateNext = STATE_FLY_LEFT;
                break;
            case STATE_FLY_LEFT:
                mStateTimer += elapsedMillis;
                if(mStateTimer > 500) {
                    mStateTimer = 0;
                    mParticles[mParticleOrder[mParticleCounter]].flyToLeftFromRight();
                    if(mParticleCounter < (NUMBER_OF_PARTICLES - 1)) mParticleCounter++;
                    else {
                        mState = STATE_WAIT;
                        mStateTimer = 1000;
                        mStateNext = STATE_SHOW_EYE_LEFT;
                    }
                }
                break;
            case STATE_WAIT:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    mState = mStateNext;
                }
                break;
        }
    }

    void releaseEye() {
        mEyeReleased = true;
    }
}
