package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteStatic;

public class WeaponFireSpinner extends SpriteStatic {
    private final static int CIRCLE_RADIUS = 28;

    private double mStartingAngle;
    private double mFinalAngle;
    private double mCurrentAngle;

    private final Rect mCenteringObject;
    private final WeaponFire mWeaponFireParent;
    private final int mIndex;

    public final SpriteAnimatedMirroredWeapons mParent;

    WeaponFireSpinner(Resources resources, int resource_id, int boundingBoxOffsetX, int boundingBoxOffsetY, int boundingBoxSizeX, int boundingBoxSizeY, int index, Rect centeringObject, WeaponFire weaponFireParent, SpriteAnimatedMirroredWeapons parent) {
        super(resources, resource_id, boundingBoxOffsetX, boundingBoxOffsetY, boundingBoxSizeX, boundingBoxSizeY);

        mParent = parent;

        mCenteringObject = centeringObject;
        mWeaponFireParent = weaponFireParent;
        mIndex = index;

        mPlayerDamage = 20;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject != mParent);
    }

    void init(int rotationDirection) {
        switch(mIndex) {
            case 0:
                if(rotationDirection == 1) mStartingAngle = 0;
                else mStartingAngle = Math.PI;
                break;
            case 1:
                if(rotationDirection == 1) mStartingAngle = -Math.PI / 4;
                else mStartingAngle = -Math.PI * 3 / 4;
                break;
            case 2:
                mStartingAngle = -Math.PI / 2;
                break;
        }

        mCurrentAngle = mStartingAngle;
        mDirection = rotationDirection;
        mFinalAngle = mStartingAngle + (2 * Math.PI * mDirection);
        mX = mCenteringObject.centerX() + (int)(CIRCLE_RADIUS * Math.cos(mStartingAngle) - 8);
        mY = mCenteringObject.centerY() + (int)(CIRCLE_RADIUS * Math.sin(mStartingAngle) - 8);
        updateBoundingBox();
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mCurrentAngle += elapsedMillis / 50.0f * mDirection;
        mX = mCenteringObject.centerX() + (int)(CIRCLE_RADIUS * (float)Math.cos(mCurrentAngle) - 8);
        mY = mCenteringObject.centerY() + (int)(CIRCLE_RADIUS * (float)Math.sin(mCurrentAngle) - 8);
        updateBoundingBox();

        if((mDirection == 1 && mCurrentAngle >= mFinalAngle) || (mDirection == -1 && mCurrentAngle <= mFinalAngle)) {
            gameEngine.removeGameObject(this);
            mWeaponFireParent.releaseSpinner(mIndex);
        }
    }
}
