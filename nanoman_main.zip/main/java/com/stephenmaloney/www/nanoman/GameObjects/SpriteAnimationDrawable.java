package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Bitmap;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;

import java.util.ArrayList;
import java.util.List;

public class SpriteAnimationDrawable {
    private final List<AnimationDrawable> mDrawables = new ArrayList<>();
    public int mState = 0;
    private int mFrame = 0;
    private int mFrameTime = 0;
    public boolean mOneShotFired = false;

    public void addState(int state, AnimationDrawable animationDrawable) {
        mDrawables.add(state, animationDrawable);
    }

    public synchronized Bitmap getBitmap() {
        return ((BitmapDrawable) mDrawables.get(mState).getFrame(mFrame)).getBitmap();
    }

    public synchronized void setState(int state, boolean reset) {
        mState = state;
        mOneShotFired = false;

        if (reset) {
            mFrame = 0;
            mFrameTime = 0;
        }
    }

    public synchronized void onUpdate(long elapsedMillis) {
        if(mOneShotFired) return;

        mFrameTime += elapsedMillis;
        final AnimationDrawable drawable = mDrawables.get(mState);

        if (mFrameTime > drawable.getDuration(mFrame)) {
            mFrameTime = 0;
            if (mFrame == (drawable.getNumberOfFrames() - 1)) {
                if (drawable.isOneShot()) mOneShotFired = true;
                else mFrame = 0;
            }
            else mFrame++;
        }
    }
}
