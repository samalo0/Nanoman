package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.R;

public class Explosion extends GameObject {
    private final SpriteAnimationDrawable mSpriteAnimation = new SpriteAnimationDrawable();
    private final Matrix mMatrix = new Matrix();
    private final Rect mBoundingBox = new Rect();
    private int mX, mY;

    public Explosion(Resources resources) {
        mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_explosion, null));
    }

    public void init(int centerX, int centerY) {
        mX = centerX - 8;
        mY = centerY - 8;
        mBoundingBox.set(mX, mY, mX + 16, mY + 16);
        mSpriteAnimation.setState(0, true);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        mMatrix.reset();
        mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);
        canvas.drawBitmap(mSpriteAnimation.getBitmap(), mMatrix, GameView.mPaint);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mSpriteAnimation.onUpdate(elapsedMillis);
        if(mSpriteAnimation.mOneShotFired) {
            gameEngine.removeGameObject(this);
        }
    }
}
