package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EnemyScissorsSpawn extends GameObject{
    public final static String TYPE = "EnemyScissors";

    private final List<EnemyScissors> mScissors = new ArrayList<>();
    private final static int SCISSORS_LIMIT = 1;

    private final Rect mBoundingBox;

    private int mDelay = 0;

    public EnemyScissorsSpawn(Resources resources, HashMap<String, String> properties) {
        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;

        mBoundingBox = new Rect(x, y, x + Tile.SIZE, y + Tile.SIZE);

        for(int i = 0; i < SCISSORS_LIMIT; i++) mScissors.add(new EnemyScissors(resources, this));
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        final int distance = Math.abs(gameEngine.mPlayer.mBoundingBox.centerX() - mBoundingBox.centerX());
        if(!GameEngine.isObjectVisible(mBoundingBox) || distance > 5 * Tile.SIZE) return;

        mDelay += elapsedMillis;
        if(mDelay >= 750 && !mScissors.isEmpty()) {
            mDelay = 0;
            final EnemyScissors scissors = mScissors.remove(0);
            final int direction = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX() ? 1 : -1;
            final boolean far = distance > 32;
            if(direction == 1) scissors.init(mBoundingBox.right, mBoundingBox.top, direction, far, gameEngine);
            else scissors.init(mBoundingBox.left, mBoundingBox.top, direction, far, gameEngine);
            gameEngine.addGameObject(scissors);
        }
    }

    void releaseScissors(EnemyScissors scissors) {
        mScissors.add(scissors);
    }
}
