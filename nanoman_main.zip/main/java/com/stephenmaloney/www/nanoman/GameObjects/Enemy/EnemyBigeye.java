package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.BoundingBox;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimationMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class EnemyBigeye extends SpriteFrameAnimationMirrored {
    public final static String TYPE = "EnemyBigeye";

    private final static float VELOCITY_X = .08f;
    private final static float VELOCITY_Y = -.17f;

    private final BoundingBox[] mBoundingBoxes = new BoundingBox[2];

    private final static int STATE_LANDED = 0;
    private final static int STATE_JUMP = 1;
    private int mState = STATE_LANDED;
    private int mStateTimer = 0;

    private int mHealth = 25;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    public EnemyBigeye(Resources resources, HashMap<String, String> properties) {
        super(10, 0, 20, 40, 2, 40);

        mBoundingBoxes[0] = new BoundingBox(10, 0, 20, 40);
        mBoundingBoxes[1] = new BoundingBox(10, 0, 20, 48);

        final String color = properties.get("Color");
        switch(color) {
            case "Red":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bigeye_red1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bigeye_red2);
                break;
            case "Blue":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bigeye_blue1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bigeye_blue2);
                break;
            case "Orange":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bigeye_orange1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_bigeye_orange2);
                break;
        }

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) - 24;
        updateBoundingBox();

        mDirection = Integer.parseInt(properties.get("Direction"));

        mPlayerDamage = 34;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead &&
                (otherObject instanceof WeaponPShot || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot) {
            mHealth--;
            if(mHealth == 0) onDeath(gameEngine);
            else gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
        else if(otherObject instanceof WeaponBomb) onDeath(gameEngine);
    }

    private void onDeath(GameEngine gameEngine) {
        mHurtOrDead = true;

        mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
        gameEngine.addGameObject(mExplosion);

        // spawn object?
        gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

        gameEngine.removeGameObject(this);

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        switch(mState) {
            case STATE_LANDED:
                // delay to jump
                mStateTimer += elapsedMillis;
                if (mStateTimer >= 600) {
                    mStateTimer = 0;
                    mState = STATE_JUMP;
                    mFrame = 1;

                    mBoundingBox.set(mBoundingBoxes[mFrame].mRect);
                    mY -= 8;
                    updateBoundingBox();

                    // jump towards player
                    mDirection = (gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX())? 1 : -1;
                    mVelocityX = mDirection * VELOCITY_X;
                    if(Math.random() > .5) mVelocityY = VELOCITY_Y;
                    else mVelocityY = VELOCITY_Y * 2;

                    mJustLanded = false;
                }
                break;
            case STATE_JUMP:
                mVelocityX = mDirection * VELOCITY_X;

                mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
                if (mVelocityY > GameEngine.TERMINAL_VELOCITY)
                    mVelocityY = GameEngine.TERMINAL_VELOCITY;

                gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);
                gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

                if (mJustLanded) {
                    mState = STATE_LANDED;
                    mFrame = 0;
                    mVelocityY = 0;
                    mVelocityX = 0;
                    mBoundingBox.set(mBoundingBoxes[mFrame].mRect);
                    mY += 8;
                    updateBoundingBox();

                    gameEngine.soundPlay(GameEngine.GameSound.BIG_EYE_JUMP);
                }
                break;
        }
    }
}
