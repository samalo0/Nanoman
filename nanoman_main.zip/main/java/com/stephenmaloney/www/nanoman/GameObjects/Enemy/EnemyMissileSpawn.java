package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class EnemyMissileSpawn extends GameObject {
    public final static String TYPE = "EnemyMissile";

    private final Rect mBoundingBox;
    private final int mDirection;

    private final EnemyMissile mMissile;
    private boolean mMissileReleased = true;

    private int mDelay = 3000;

    public EnemyMissileSpawn(Resources resources, HashMap<String, String> properties) {
        // read missile properties
        mDirection = Integer.parseInt(properties.get("Direction"));
        final String color = properties.get("Color");

        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;

        int id;
        switch(color) {
            case "Blue":
                id = R.drawable.gameobject_enemy_missile_blue;
                break;
            case "Orange":
                id = R.drawable.gameobject_enemy_missile_orange;
                break;
            default:
                id = R.drawable.gameobject_enemy_missile_red;
                break;
        }

        mMissile = new EnemyMissile(resources, id, mDirection, this);

        mBoundingBox = new Rect(x, y, x + Tile.SIZE, y + Tile.SIZE);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(GameEngine.isObjectVisible(mBoundingBox)) {
            mDelay += elapsedMillis;
            if(mDelay >= 3000 && mMissileReleased) {
                mMissileReleased = false;
                if (mDirection == 1)
                    mMissile.init(GameView.mViewPort.left, gameEngine.mPlayer.mBoundingBox.centerY());
                else
                    mMissile.init(GameView.mViewPort.right - 1, gameEngine.mPlayer.mBoundingBox.centerY());
                gameEngine.addGameObject(mMissile);

                mDelay = 0;
            }
        }
    }

    void releaseMissile() {
        mMissileReleased = true;
    }

    @Override
    public void startGame(GameEngine gameEngine) {
    }
}
