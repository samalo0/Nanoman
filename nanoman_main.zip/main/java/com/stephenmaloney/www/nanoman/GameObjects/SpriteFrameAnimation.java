package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Bitmap;
import android.graphics.Canvas;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;

public abstract class SpriteFrameAnimation extends Sprite {
    protected final Bitmap[] mFrames;
    public int mFrame = 0;

    public SpriteFrameAnimation(int boundingBoxOffsetX, int boundingBoxOffsetY, int boundingBoxSizeX, int boundingBoxSizeY, int numberOfFrames) {
        super(boundingBoxOffsetX, boundingBoxOffsetY, boundingBoxSizeX, boundingBoxSizeY);
        mFrames = new Bitmap[numberOfFrames];
    }

    @Override
    public void onDraw(Canvas canvas) {
        if (!GameEngine.isObjectVisible(mBoundingBox)) return;

        GameView.mMatrix.reset();
        GameView.mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);

        canvas.drawBitmap(mFrames[mFrame], GameView.mMatrix, GameView.mPaint);
    }
}
