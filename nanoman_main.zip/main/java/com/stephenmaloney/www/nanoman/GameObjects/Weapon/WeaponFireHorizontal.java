package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.R;

public class WeaponFireHorizontal extends SpriteAnimatedMirrored {
    private final static int BOUNDING_BOX_OFFSET_X = 1;
    private final static int BOUNDING_BOX_OFFSET_Y = 2;
    private final static int BOUNDING_BOX_SIZE_X = 14;
    private final static int BOUNDING_BOX_SIZE_Y = 10;

    private final WeaponFire mWeaponFireParent;
    public final SpriteAnimatedMirroredWeapons mParent;

    private final static float VELOCITY_X = .3f;

    WeaponFireHorizontal(Resources resources, WeaponFire weaponFireParent, SpriteAnimatedMirroredWeapons parent) {
        super(BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        mParent = parent;

        mFacingLeftAdjustmentX = 16;
        mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(R.drawable.animation_weapon_fire, null));
        mWeaponFireParent = weaponFireParent;

        mPlayerDamage = 12;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject != mParent);
    }

    public void init(int x, int y, int direction) {
        mXFractional = 0;
        mYFractional = 0;
        mX = x;
        mY = y;
        updateBoundingBox();

        mDirection = direction;
        mVelocityX = VELOCITY_X * mDirection;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mSpriteAnimation.onUpdate(elapsedMillis);

        final double dX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) dX;
        mXFractional = dX % 1;
        updateBoundingBox();

        if(mX < GameView.mViewPort.left || mBoundingBox.right > GameView.mViewPort.right) {
            gameEngine.removeGameObject(this);
            mWeaponFireParent.releaseHorizontal();
        }
    }
}
