package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

class EnemyAngleShooterShot extends EnemyShot {
    private final EnemyAngleShooter mParent;
    private final int mIndex;

    private final static float VELOCITY = .2f;

    EnemyAngleShooterShot(Resources resources, int resource_id, int index, int direction, EnemyAngleShooter parent) {
        super(resources, resource_id);
        mParent = parent;
        mIndex = index;
        mDirection = direction;

        switch(index) {
            case 0:
                mVelocityX = VELOCITY * mDirection * (float)Math.cos(-45 * Math.PI / 180);
                mVelocityY = VELOCITY * (float)Math.sin(-45 * Math.PI / 180);
                break;
            case 1:
                mVelocityX = VELOCITY * mDirection * (float)Math.cos(-20 * Math.PI / 180);
                mVelocityY = VELOCITY * (float)Math.sin(-20 * Math.PI / 180);
                break;
            case 2:
                mVelocityX = VELOCITY * mDirection * (float)Math.cos(20 * Math.PI / 180);
                mVelocityY = VELOCITY * (float)Math.sin(20 * Math.PI / 180);
                break;
            case 3:
                mVelocityX = VELOCITY * mDirection * (float)Math.cos(45 * Math.PI / 180);
                mVelocityY = VELOCITY * (float)Math.sin(45 * Math.PI / 180);
                break;
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            mParent.releaseShot(mIndex);
            gameEngine.removeGameObject(this);
        }

        super.onUpdate(elapsedMillis, gameEngine);
    }
}
