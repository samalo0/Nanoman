package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

class EnemyShieldSoldierShot extends EnemyShot {
    private final EnemyShieldSoldier mParent;

    EnemyShieldSoldierShot(Resources resources, int resource_id, int direction, EnemyShieldSoldier parent) {
        super(resources, resource_id);

        mDirection = direction;
        mVelocityX = .2f * direction;
        mParent = parent;
    }

    void init(int x, int y, GameEngine gameEngine) {
        mXFractional = 0;
        mYFractional = 0;
        if(mDirection == 1) {
            mX = x + 30;
            mY = y + 10;
        }
        else {
            mX = x + 3;
            mY = y + 10;
        }
        updateBoundingBox();

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_SHOOT);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            mParent.releaseShot();
            gameEngine.removeGameObject(this);
        }

        super.onUpdate(elapsedMillis, gameEngine);
    }
}
