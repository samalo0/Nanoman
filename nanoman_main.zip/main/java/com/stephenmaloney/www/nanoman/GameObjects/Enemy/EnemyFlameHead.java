package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;


public class EnemyFlameHead extends SpriteAnimatedMirrored {
    private final EnemyFlameHeadSpawn mParent;

    private final static float RISE_VELOCITY = -.25f;
    private final static float FALL_VELOCITY = .05f;
    private final static float VELOCITY_X = .1f;

    private final static int STATE_WAIT = 0;
    private final static int STATE_RISE = 1;
    private final static int STATE_FALL = 2;
    private int mState = STATE_RISE;
    private int mStateTimer;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    EnemyFlameHead(Resources resources, EnemyFlameHeadSpawn parent) {
        super(0, 0, 16, 16);

        mParent = parent;
        mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_flame_head, null));

        mFacingLeftAdjustmentX = 16;
        mPlayerDamage = 16;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    void init() {
        mHurtOrDead = false;
        mX = GameView.mViewPort.centerX();
        mY = GameView.mViewPort.bottom;
        mXFractional = 0;
        mYFractional = 0;
        updateBoundingBox();

        mVelocityX = 0;
        mVelocityY = RISE_VELOCITY;

        mState = STATE_WAIT;
        mStateTimer = (int)(1000 * Math.random());
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts) {

            mHurtOrDead = true;

            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

            gameEngine.removeGameObject(this);
            mParent.releaseHead();

            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mSpriteAnimation.onUpdate(elapsedMillis);

        switch(mState) {
            case STATE_WAIT:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mState = STATE_RISE;
                }
                break;
            case STATE_RISE:
                mY += mVelocityY * elapsedMillis;
                updateBoundingBox();

                if(mY < (GameView.mViewPort.top - 64)) {
                    mState = STATE_FALL;
                    mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;
                    mVelocityY = FALL_VELOCITY;
                    mVelocityX = VELOCITY_X * mDirection * (float)Math.random();
                }
                break;
            case STATE_FALL:
                double distanceX = mVelocityX * elapsedMillis + mXFractional;
                mX += (int) distanceX;
                mXFractional = distanceX % 1;

                final double distanceY= mVelocityY * elapsedMillis + mYFractional;
                mY += (int) distanceY;
                mYFractional = distanceY % 1;
                updateBoundingBox();

                if(mY > GameView.mViewPort.bottom) {
                    gameEngine.removeGameObject(this);
                    mParent.releaseHead();
                }
                break;
        }
    }
}
