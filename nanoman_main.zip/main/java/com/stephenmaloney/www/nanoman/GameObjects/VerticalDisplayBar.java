package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;

public class VerticalDisplayBar extends GameObject {
    private final static int TRANSITION_MILLIS = 75;

    private final int mMaximumValue;
    private final int mValuePerSegment;

    private final int mLeft;
    private final int mTop;
    private final int mWidth;
    private final int mHeight;

    private int mDisplayValue;
    private int mTransitionToValue;
    private int mTransitionTimer = 0;

    private int mAddSoundTimer = 0;
    private final static int SOUND_TIME = 233;

    private final Bitmap mBitmapSegment;

    private final Paint mPaint = new Paint();
    private final Canvas mCanvas;
    private final Bitmap mBitmap;

    public VerticalDisplayBar(Resources resources, int resourceId, int maximum_value, int segments, int x, int y) {
        mMaximumValue = maximum_value;
        mValuePerSegment = mMaximumValue / segments;

        mLeft = x;
        mTop = y;
        mWidth = 8;
        mHeight = (segments << 1) + 1;

        mBitmapSegment = BitmapFactory.decodeResource(resources, resourceId);

        mPaint.setColor(Color.BLACK);

        mBitmap = Bitmap.createBitmap(mWidth, mHeight, Bitmap.Config.ARGB_8888);
        mCanvas = new Canvas(mBitmap);

        mDisplayValue = mMaximumValue;
        mTransitionToValue = mMaximumValue;
        redraw();
    }

    public void add(int value) {
        mTransitionToValue += value;
        if(mTransitionToValue > mMaximumValue) mTransitionToValue = mMaximumValue;
        mAddSoundTimer = SOUND_TIME;
    }

    public void addInstant(int value) {
        mTransitionToValue += value;
        if(mTransitionToValue > mMaximumValue) mTransitionToValue = mMaximumValue;
        mDisplayValue = mTransitionToValue;
        redraw();
    }

    public boolean isEmpty() {
        return mTransitionToValue == 0;
    }

    public boolean isFull() { return mDisplayValue == mMaximumValue; }

    @Override
    public void onDraw(Canvas canvas) {
        canvas.drawBitmap(mBitmap, mLeft, mTop, GameView.mPaint);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(mTransitionToValue != mDisplayValue) {
            mTransitionTimer += elapsedMillis;
            if(mTransitionTimer >= TRANSITION_MILLIS) {
                mTransitionTimer = 0;
                if(mTransitionToValue > mDisplayValue) {
                    mDisplayValue += mValuePerSegment;
                    if(mDisplayValue > mTransitionToValue) mDisplayValue = mTransitionToValue;
                }
                else {
                    mDisplayValue -= mValuePerSegment;
                    if(mDisplayValue < mTransitionToValue) mDisplayValue = mTransitionToValue;
                }
                redraw();
            }

            mAddSoundTimer += elapsedMillis;
            if(mAddSoundTimer >= SOUND_TIME && mTransitionToValue > mDisplayValue) {
                mAddSoundTimer = 0;
                gameEngine.soundPlay(GameEngine.GameSound.METER_ADD);
            }
        }
    }

    private void redraw() {
        mCanvas.drawRect(0, 0, mWidth, mHeight, mPaint);

        int stopRow = ((mMaximumValue - mDisplayValue) / mValuePerSegment) << 1;
        for(int pixelRow = mHeight; pixelRow > stopRow; pixelRow -= 2) {
            mCanvas.drawBitmap(mBitmapSegment, 0, pixelRow, null);
        }
    }

    public void remove(int value) {
        mTransitionToValue -= value;
        if(mTransitionToValue < 0) mTransitionToValue = 0;
    }

    @Override
    public void startGame(GameEngine gameEngine) {
        mDisplayValue = mMaximumValue;
        mTransitionToValue = mMaximumValue;
        redraw();
    }
}
