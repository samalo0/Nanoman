package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.BoundingBox;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public class EnemyHelmet extends SpriteFrameAnimation {
    public final static String TYPE = "EnemyHelmet";

    private final static int STATE_CLOSED = 0;
    private final static int STATE_SHOOT = 1;
    private final static int STATE_CLOSING = 2;
    private final static int STATE_WAIT = 3;
    private int mState = STATE_CLOSED;
    private int mStateNext;
    private int mStateTimer = 1000;

    private final BoundingBox[] mBoundingBoxes = new BoundingBox[2];

    private final List<EnemyHelmetShot> mShots = new ArrayList<>();
    private final static int SHOT_LIMIT = 3;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    public EnemyHelmet(Resources resources, HashMap<String, String> properties) {
        super(0, 4, 18, 11, 2);

        mPlayerDamage = 4;

        mX = (Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2);
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) + 1;
        mDirection = Integer.parseInt(properties.get("Direction"));

        mBoundingBoxes[0] = new BoundingBox(0, 4, 18, 11);
        mBoundingBoxes[1] = new BoundingBox(0, 0, 18, 15);
        mBoundingBox.set(mBoundingBoxes[0].mRect);
        updateBoundingBox();

        if(mDirection == 1) {
            mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_helmet_closed);
            mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_helmet_opened);
        }
        else {
            Bitmap bitmap = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_helmet_closed);
            mMatrix.reset();
            mMatrix.preScale(-1, 1);
            mFrames[0] = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), mMatrix, false);

            bitmap = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_helmet_opened);
            mFrames[1] = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), mMatrix, false);
        }

        if(mDirection == 1) for(int i = 0; i < SHOT_LIMIT; i++) mShots.add(new EnemyHelmetShot(resources, mDirection, mBoundingBox.right, mBoundingBox.centerY(), i, this));
        else for(int i = 0; i < SHOT_LIMIT; i++) mShots.add(new EnemyHelmetShot(resources, mDirection, mBoundingBox.left - 6, mBoundingBox.centerY(), i, this));

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding) ||
                (mFrame != 0 && (otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage))));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(mFrame == 0) {
            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DINK);
            return;
        }

        if(otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts){

            mHurtOrDead = true;

            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

            gameEngine.removeGameObject(this);

            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        switch(mState) {
            case STATE_CLOSED:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    int distance;
                    if(mDirection == 1) distance = gameEngine.mPlayer.mBoundingBox.centerX() - mBoundingBox.centerX();
                    else distance = mBoundingBox.centerX() - gameEngine.mPlayer.mBoundingBox.centerX();
                    if(distance < 80 && distance > 0) {
                        mState = STATE_WAIT;
                        mStateNext = STATE_SHOOT;
                        mStateTimer = 100;
                        mFrame = 1;
                        mBoundingBox.set(mBoundingBoxes[1].mRect);
                        updateBoundingBox();
                    }
                }
                break;
            case STATE_SHOOT:
                while(!mShots.isEmpty()) {
                    EnemyHelmetShot shot = mShots.remove(0);
                    shot.init(gameEngine);
                    gameEngine.addGameObject(shot);
                }
                mState = STATE_WAIT;
                mStateNext = STATE_CLOSING;
                mStateTimer = 500;
                break;
            case STATE_CLOSING:
                mState = STATE_CLOSED;
                mStateTimer = (int)(Math.random() * 4000);
                mFrame = 0;
                mBoundingBox.set(mBoundingBoxes[0].mRect);
                updateBoundingBox();
                break;
            case STATE_WAIT:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    mState = mStateNext;
                }
                break;
        }
    }

    void releaseShot(EnemyHelmetShot shot) {
        mShots.add(shot);
    }

    @Override
    public void updateBoundingBox() {
        mBoundingBox.offsetTo(Math.round(mX) + mBoundingBoxes[mFrame].mOffsetX, Math.round(mY) + mBoundingBoxes[mFrame].mOffsetY);
    }
}
