package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.DeathExplosionSet;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.List;

import static com.stephenmaloney.www.nanoman.GameEngine.GameView.mMatrix;

public class EnemyWilyWeakness extends SpriteFrameAnimation {
    private final static int WEAKNESS_OFFSET_X = 13;
    private final static int WEAKNESS_OFFSET_Y = 49;

    private final EnemyWily mParent;
    private final EnemyHealthBar mHealthBar;
    private boolean mHurtOrDead = false;
    private final DeathExplosionSet mDeathExplosionSet;
    private int mHurtTimer = 0;

    private final List<EnemyWilyShot2> mShots = new ArrayList<>();
    private final static int SHOT_LIMIT = 1;

    private int mShotTimer = 0;

    EnemyWilyWeakness(Resources resources, EnemyWily parent) {
        super(0, 0, 8, 14, 2);

        mParent = parent;
        mPlayerDamage = 25;
        mHealthBar = new EnemyHealthBar(resources);
        mDeathExplosionSet = new DeathExplosionSet(resources);

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_wily_weakness);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_wily_weakness_explosion);

        for(int i = 0; i < SHOT_LIMIT; i++) mShots.add(new EnemyWilyShot2(resources, this));
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && otherObject instanceof WeaponPShot;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot) {
            mHealthBar.remove(4);
            if(mHealthBar.isEmpty()) {
                mHurtOrDead = true;
                mParent.weaknessDestroyed();
                gameEngine.removeGameObject(this);
                mDeathExplosionSet.addGameObjects(mBoundingBox.centerX(), mBoundingBox.centerY(), gameEngine);
            }
            else {
                gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
                mParent.onHurt();
                mHurtTimer = 100;
            }
        }
    }

    @Override
    public void onDraw(Canvas canvas) {
        mHealthBar.onDraw(canvas);

        mMatrix.reset();
        if(mHurtTimer > 0) {
            mMatrix.postTranslate(mX - 2 - GameView.mViewPort.left, mY - 2 - GameView.mViewPort.top);
            canvas.drawBitmap(mFrames[1], mMatrix, GameView.mPaint);
        }
        else {
            mMatrix.postTranslate(mX - GameView.mViewPort.left, mY - GameView.mViewPort.top);
            canvas.drawBitmap(mFrames[0], mMatrix, GameView.mPaint);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mHealthBar.onUpdate(elapsedMillis, gameEngine);

        if(mHurtTimer > 0) mHurtTimer -= elapsedMillis;

        mShotTimer += elapsedMillis;
        if(mShotTimer >= 1500 && !mShots.isEmpty()) {
            mShotTimer = 0;
            final EnemyWilyShot2 shot = mShots.remove(0);
            shot.init(mX - 9, mY + 19);
            gameEngine.addGameObject(shot);
        }
    }

    void releaseShot(EnemyWilyShot2 shot) {
        mShots.add(shot);
    }

    void updateLocation(int x, int y) {
        mX = x + WEAKNESS_OFFSET_X;
        mY = y + WEAKNESS_OFFSET_Y;
        updateBoundingBox();
    }
}
