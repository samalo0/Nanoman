package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.DeathExplosion;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.HealthLarge;
import com.stephenmaloney.www.nanoman.GameObjects.PowerUps.WeaponPickup;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.Teleport;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class EnemyCutman extends SpriteAnimatedMirroredWeapons {
    public final static String TYPE = "EnemyCutman";

    private final static float HURT_VELOCITY = .1f;
    private final static float VELOCITY_X = .08f;
    private final static float JUMP_VELOCITY = -.4f;

    private final static int BOMB_DAMAGE = 16;
    private final static int ELECTRICITY_DAMAGE = 8;
    private final static int FIRE_DAMAGE = 8;
    private final static int GUTS_DAMAGE = 50;
    private final static int PSHOT_DAMAGE = 8;

    private final static int ANIMATION_SHOWBOAT = 0;
    private final static int ANIMATION_STAND1 = 1;
    private final static int ANIMATION_STAND2 = 2;
    private final static int ANIMATION_WALK1 = 3;
    private final static int ANIMATION_WALK2 = 4;
    private final static int ANIMATION_JUMP1 = 5;
    private final static int ANIMATION_JUMP2 = 6;
    private final static int ANIMATION_THROW = 7;
    private final static int ANIMATION_HURT = 8;
    private int mOldAnimationState;

    private final static int STATE_SHOWBOAT = 0;
    private final static int STATE_REDIRECT = 1;
    private final static int STATE_WAIT_TO_LAND = 2;
    private final static int STATE_THROW = 3;
    private final static int STATE_CONTINUE_FOR_TIME = 4;
    private final static int STATE_STUNNED = 5;
    private int mState = STATE_SHOWBOAT;
    private int mStateTimer = 0;
    private int mStateNext;

    private final EnemyHealthBar mHealthBar;
    private boolean mHealthBarAdded = false;

    private final List<DeathExplosion> mDeathExplosions = new ArrayList<>();
    private final static int DEATH_EXPLOSION_LIMIT = 16;

    private final WeaponPickup mWeaponPickup;

    private final List<WeaponCutter> mCutter = new ArrayList<>();
    private final static int WEAPON_CUTTER_LIMIT = 1;

    private boolean mHurtOrDead = false;
    private final static int HURT_MILLIS = 1500;
    private int mHurtTimer;
    private final static int HURT_BLINK_MILLIS = 40;
    private int mHurtBlinkTimer;
    private final static int HURT_EXPLOSION_MILLIS = 250;
    private int mHurtExplosionTimer;
    private boolean mVisible = true;

    private final boolean mDropsWeapon;
    private final Teleport mTeleport;

    public EnemyCutman(Resources resources, HashMap<String, String> properties) {
        super(resources, 7, 8, 16, 24);

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) - 16;
        updateBoundingBox();

        mDirection = Integer.parseInt(properties.get("Direction"));

        // check if enemy drops his weapon or adds teleport on death
        final String dropsWeapon = properties.get("DropsWeapon");
        mDropsWeapon = dropsWeapon == null || Boolean.parseBoolean(dropsWeapon);
        if(mDropsWeapon) mTeleport = null;
        else {
            HashMap<String, String> teleportProperties = new HashMap<>();
            teleportProperties.put("PositionX", "80");
            teleportProperties.put("PositionY", "71");
            teleportProperties.put("DestinationX", "80");
            teleportProperties.put("DestinationY", "56");
            mTeleport = new Teleport(teleportProperties);
        }

        mSpriteAnimation.addState(ANIMATION_SHOWBOAT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_cutman_showboat, null));
        mSpriteAnimation.addState(ANIMATION_STAND1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_cutman_stand1, null));
        mSpriteAnimation.addState(ANIMATION_STAND2, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_cutman_stand2, null));
        mSpriteAnimation.addState(ANIMATION_WALK1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_cutman_walk1, null));
        mSpriteAnimation.addState(ANIMATION_WALK2, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_cutman_walk2, null));
        mSpriteAnimation.addState(ANIMATION_JUMP1, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_cutman_jump1, null));
        mSpriteAnimation.addState(ANIMATION_JUMP2, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_cutman_jump2, null));
        mSpriteAnimation.addState(ANIMATION_THROW, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_cutman_throw, null));
        mSpriteAnimation.addState(ANIMATION_HURT, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_cutman_hurt, null));

        mFacingLeftAdjustmentX = 30;

        mHealthBar = new EnemyHealthBar(resources);

        // set up death explosions
        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) mDeathExplosions.add(new DeathExplosion(resources, R.drawable.animation_enemy_death, i));

        for(int i = 0; i < WEAPON_CUTTER_LIMIT; i++) mCutter.add(new WeaponCutter(resources, this));

        mWeaponPickup = new WeaponPickup(resources, Player.WEAPON_CUTTER);

        mPlayerDamage = 16;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox)
                && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage)
                || (otherObject instanceof WeaponGutsFragment));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot) mHealthBar.remove(PSHOT_DAMAGE);
        else if(otherObject instanceof WeaponElectricityHorizontal || otherObject instanceof WeaponElectricityVertical) mHealthBar.remove(ELECTRICITY_DAMAGE);
        else if(otherObject instanceof WeaponFireHorizontal || otherObject instanceof WeaponFireSpinner) mHealthBar.remove(FIRE_DAMAGE);
        else if(otherObject instanceof WeaponBomb) mHealthBar.remove(BOMB_DAMAGE);
        else if(otherObject instanceof WeaponGuts || otherObject instanceof WeaponGutsFragment) mHealthBar.remove(GUTS_DAMAGE);
        else if(otherObject instanceof WeaponIce) {
            mState = STATE_STUNNED;
            mVelocityX = ((WeaponIce) otherObject).mDirection * HURT_VELOCITY;
        }

        if(mHealthBar.isEmpty()) onDeath(gameEngine);
        else onHurt(otherObject.mDirection, gameEngine);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mVisible) super.onDraw(canvas);
    }

    private void onDeath(GameEngine gameEngine) {
        mHurtOrDead = true;

        for(int i = 0; i < DEATH_EXPLOSION_LIMIT; i++) {
            DeathExplosion exp = mDeathExplosions.get(i);
            exp.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(exp);
        }

        if(mDropsWeapon) {
            mWeaponPickup.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mWeaponPickup);
        }
        else {
            gameEngine.addGameObject(mTeleport);
            gameEngine.addGameObject(new HealthLarge(gameEngine.getResources(), mBoundingBox.centerX(), mBoundingBox.centerY()));
        }

        gameEngine.removeGameObject(mHealthBar);
        gameEngine.removeGameObject(this);

        gameEngine.soundPlay(GameEngine.GameSound.PLAYER_DEATH);
        gameEngine.musicPause();
    }

    private void onHurt(int direction, GameEngine gameEngine) {
        mVelocityX = direction * HURT_VELOCITY;
        mHurtOrDead = true;
        mHurtTimer = 0;
        mHurtBlinkTimer = 0;
        mState = STATE_CONTINUE_FOR_TIME;
        mStateTimer = HURT_EXPLOSION_MILLIS;
        if(mVelocityY < 0) mVelocityY = 0;

        // create dust
        dustAdd(gameEngine);

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            if (mHealthBarAdded) {
                mHealthBarAdded = false;
                gameEngine.removeGameObject(mHealthBar);
            }
            return;
        }

        if (!mHealthBarAdded) {
            mHealthBarAdded = true;
            gameEngine.addGameObject(mHealthBar);
            gameEngine.musicPlayLooped(R.raw.music_boss_theme);
        }

        if(mHurtOrDead) {
            mHurtTimer += elapsedMillis;
            if(mHurtTimer >= HURT_MILLIS) {
                mHurtOrDead = false;
                mVisible = true;
                mHurtBlinkTimer = 0;
                mHurtExplosionTimer = 0;
                if(mSpriteAnimation.mState == ANIMATION_HURT) mSpriteAnimation.setState(mOldAnimationState, true);
            }
            else {
                mHurtBlinkTimer += elapsedMillis;
                if(mHurtBlinkTimer >= HURT_BLINK_MILLIS) {
                    mHurtBlinkTimer = 0;
                    mVisible = !mVisible;
                }
                mHurtExplosionTimer += elapsedMillis;
                if(mHurtExplosionTimer >= HURT_EXPLOSION_MILLIS) {
                    mHurtExplosionTimer = 0;
                    if(mSpriteAnimation.mState == ANIMATION_HURT) {
                        mSpriteAnimation.setState(mOldAnimationState, true);
                    }
                    else {
                        mOldAnimationState = mSpriteAnimation.mState;
                        mSpriteAnimation.setState(ANIMATION_HURT, true);
                    }
                }
            }
        }

        switch(mState) {
            case STATE_SHOWBOAT:
                mStateTimer += elapsedMillis;
                if(mStateTimer > 500) {
                    mStateTimer = 0;
                    mState = STATE_REDIRECT;
                    mSpriteAnimation.setState(ANIMATION_STAND1, true);
                }
                break;
            case STATE_REDIRECT:
                if(!mCutter.isEmpty()) {
                    mState = STATE_CONTINUE_FOR_TIME;
                    mStateTimer = 150;
                    mStateNext = STATE_THROW;
                    mSpriteAnimation.setState(ANIMATION_THROW, true);
                }
                else {
                    mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX()? 1 : -1;
                    final int distanceX = Math.abs(gameEngine.mPlayer.mBoundingBox.centerX() - mBoundingBox.centerX());
                    final int distanceY = Math.abs(gameEngine.mPlayer.mBoundingBox.centerY() - mBoundingBox.centerY());
                    if(distanceY > 24 && mOnGround) {
                        mState = STATE_WAIT_TO_LAND;
                        mVelocityX = mDirection * VELOCITY_X;
                        mVelocityY = JUMP_VELOCITY;
                        if(mCutter.isEmpty()) mSpriteAnimation.setState(ANIMATION_JUMP2, true);
                        else mSpriteAnimation.setState(ANIMATION_JUMP1, true);
                        mJustLanded = false;
                    }
                    else if(distanceX > 64) {
                        mState = STATE_CONTINUE_FOR_TIME;
                        mStateNext = STATE_REDIRECT;
                        mStateTimer = 300;
                        if(mCutter.isEmpty()) mSpriteAnimation.setState(ANIMATION_WALK2, true);
                        else mSpriteAnimation.setState(ANIMATION_WALK1, true);
                        mVelocityX = mDirection * VELOCITY_X;
                        mVelocityY = 0;
                    }
                    else {
                        mState = STATE_CONTINUE_FOR_TIME;
                        mStateNext = STATE_REDIRECT;
                        mStateTimer = 300;
                        if(mCutter.isEmpty()) mSpriteAnimation.setState(ANIMATION_WALK2, true);
                        else mSpriteAnimation.setState(ANIMATION_WALK1, true);
                        mVelocityX = mDirection * VELOCITY_X * -1;
                        mVelocityY = 0;
                    }
                }
                break;
            case STATE_WAIT_TO_LAND:
                if(mJustLanded) {
                    mState = STATE_CONTINUE_FOR_TIME;
                    mStateNext = STATE_REDIRECT;
                    mStateTimer = 100;
                    mVelocityX = 0;
                    if(mCutter.isEmpty()) mSpriteAnimation.setState(ANIMATION_STAND2, true);
                    else mSpriteAnimation.setState(ANIMATION_STAND1, true);
                }
                else {
                    mVelocityX = mDirection * VELOCITY_X;
                    if(mCutter.isEmpty()) mSpriteAnimation.setState(ANIMATION_JUMP2, true);
                    else mSpriteAnimation.setState(ANIMATION_JUMP1, true);
                }
                break;
            case STATE_THROW:
                if(!mCutter.isEmpty()) {
                    final WeaponCutter cutter = mCutter.remove(0);
                    if (mDirection == 1)
                        cutter.init(mBoundingBox.right, mBoundingBox.centerY(), mDirection, gameEngine);
                    else cutter.init(mBoundingBox.left - 20, mBoundingBox.centerY(), mDirection, gameEngine);
                    gameEngine.addGameObject(cutter);
                }
                mState = STATE_REDIRECT;
                break;
            case STATE_CONTINUE_FOR_TIME:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    mState = mStateNext;
                }
                break;
            case STATE_STUNNED:
                mVelocityX = 0;
                if(mCutter.isEmpty()) mSpriteAnimation.setState(ANIMATION_STAND2, true);
                else mSpriteAnimation.setState(ANIMATION_STAND1, true);
                mState = STATE_CONTINUE_FOR_TIME;
                mStateNext = STATE_REDIRECT;
                mStateTimer = 1500;
                break;
        }

        gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

        mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
        gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

        mSpriteAnimation.onUpdate(elapsedMillis);
    }

    @Override
    public void weaponCutterRelease(WeaponCutter weaponCutter) {
        mCutter.add(weaponCutter);
    }
}
