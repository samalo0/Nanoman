package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;

import com.stephenmaloney.www.nanoman.GameObjects.VerticalDisplayBar;
import com.stephenmaloney.www.nanoman.R;

class EnemyHealthBar extends VerticalDisplayBar {
    private final static int HEALTH_MAX = 100;
    private final static int SEGMENTS = 25;
    private final static int BAR_LEFT = 40;
    private final static int BAR_TOP = 24;

    EnemyHealthBar(Resources resources) {
        super(resources, R.drawable.gameobject_vertical_display_bar_orange_segment, HEALTH_MAX, SEGMENTS, BAR_LEFT, BAR_TOP);
    }

    @Override
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
    }
}
