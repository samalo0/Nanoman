package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyAlien;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyAngleShooter;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBigeye;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBombman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyBubbleRobotDrone;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyClone;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyCutman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyElecman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyEyePatrol;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFireman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFlameHead;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyFlyingNut;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyGutsman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyHelicopter;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyHelmet;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyIceman;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyJumper;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyMiner;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyMissile;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyPenguin;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyRobotHead;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyRobotLegs;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyShieldSoldier;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemySlider;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemySpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyWilyGun;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyWilyWeakness;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyYellowDemonEye;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteStatic;
import com.stephenmaloney.www.nanoman.R;

public class WeaponPShot extends SpriteStatic {
    private final static float PSHOT_VELOCITY = .25f;
    private final static int FACING_LEFT_ADJUSTMENT_X = -40;

    private final SpriteAnimatedMirroredWeapons mParent;

    public WeaponPShot(Resources resources, SpriteAnimatedMirroredWeapons parent) {
        super(resources, R.drawable.weapon_pshot, 0, 0, 8, 6);
        mParent = parent;

        mPlayerDamage = 12;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject != mParent) &&
                (otherObject instanceof EnemyAlien
                        || otherObject instanceof EnemyAngleShooter
                        || otherObject instanceof EnemyBigeye
                        || otherObject instanceof EnemyBombman
                        || otherObject instanceof EnemyBubbleRobotDrone
                        || otherObject instanceof EnemyClone
                        || otherObject instanceof EnemyCutman
                        || otherObject instanceof EnemyElecman
                        || otherObject instanceof EnemyEyePatrol
                        || otherObject instanceof EnemyFireman
                        || otherObject instanceof EnemyFlameHead
                        || otherObject instanceof EnemyFlyingNut
                        || otherObject instanceof EnemyGutsman
                        || otherObject instanceof EnemyHelicopter
                        || otherObject instanceof EnemyHelmet
                        || otherObject instanceof EnemyIceman
                        || otherObject instanceof EnemyJumper
                        || otherObject instanceof EnemyMiner
                        || otherObject instanceof EnemyMissile
                        || otherObject instanceof EnemyPenguin
                        || otherObject instanceof EnemyRobotHead
                        || otherObject instanceof EnemyRobotLegs
                        || otherObject instanceof EnemyShieldSoldier
                        || otherObject instanceof EnemySlider
                        || otherObject instanceof EnemySpinner
                        || otherObject instanceof EnemyYellowDemonEye
                        || otherObject instanceof EnemyWilyGun
                        || otherObject instanceof EnemyWilyWeakness);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(otherObject instanceof EnemyAlien
                || otherObject instanceof EnemyAngleShooter
                || otherObject instanceof EnemyBigeye
                || otherObject instanceof EnemyBombman
                || otherObject instanceof EnemyBubbleRobotDrone
                || otherObject instanceof EnemyClone
                || otherObject instanceof EnemyCutman
                || otherObject instanceof EnemyElecman
                || otherObject instanceof EnemyEyePatrol
                || otherObject instanceof EnemyFireman
                || otherObject instanceof EnemyFlameHead
                || otherObject instanceof EnemyFlyingNut
                || otherObject instanceof EnemyGutsman
                || otherObject instanceof EnemyHelicopter
                || otherObject instanceof EnemyHelmet
                || otherObject instanceof EnemyIceman
                || otherObject instanceof EnemyJumper
                || otherObject instanceof EnemyMiner
                || otherObject instanceof EnemyMissile
                || otherObject instanceof EnemyPenguin
                || otherObject instanceof EnemyRobotHead
                || otherObject instanceof EnemyRobotLegs
                || otherObject instanceof EnemyShieldSoldier
                || otherObject instanceof EnemySlider
                || otherObject instanceof EnemySpinner
                || otherObject instanceof EnemyYellowDemonEye
                || otherObject instanceof EnemyWilyGun
                || otherObject instanceof EnemyWilyWeakness) {

            gameEngine.removeGameObject(this);
            mParent.weaponPShotRelease(this);
        }
    }

    public void init(int x, int y, int direction, GameEngine gameEngine) {
        mY = y;
        mYFractional = 0;
        mDirection = direction;
        mVelocityX = PSHOT_VELOCITY * mDirection;
        if(mDirection == 1) mX = x;
        else mX = x + FACING_LEFT_ADJUSTMENT_X;
        mXFractional = 0;
        updateBoundingBox();

        gameEngine.soundPlay(GameEngine.GameSound.WEAPON_PSHOT);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.weaponPShotRelease(this);
            return;
        }

        final double distance = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distance;
        mXFractional = distance % 1;
        updateBoundingBox();
    }

    @Override
    public void startGame(GameEngine gameEngine) {
    }
}
