package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class EnemyMiner extends SpriteFrameAnimation {

    public final static String TYPE = "EnemyMiner";

    private final static float VELOCITY_X = .08f;
    private final static float VELOCITY_Y = -.2f;

    private final EnemyMinerPickAxe mPickAxe;
    private boolean mPickAxeReleased = true;

    private final static int STATE_JUMP_IN = 0;
    private final static int STATE_WAIT_TO_LAND = 1;
    private final static int STATE_DEFENSE = 2;
    private final static int STATE_LIFT = 3;
    private final static int STATE_THROW = 4;
    private final static int STATE_STUNNED = 5;
    private int mState = STATE_JUMP_IN;
    private int mStateTimer;
    private int mOldState;
    private int mStunnedTimer;

    private int mHealth = 10;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    public EnemyMiner(Resources resources, HashMap<String, String> properties) {
        super(10, 0, 18, 24, 3);

        mDirection = Integer.parseInt(properties.get("Direction"));

        if(mDirection == 1) {
            mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_miner_stand);
            mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_miner_lift);
            mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_miner_throw);
        }
        else {
            mBoundingBoxOffsetX = 4;
            mBoundingBoxOffsetY = 0;

            final Matrix matrix = new Matrix();
            matrix.preScale(-1, 1);
            Bitmap bitmap;
            bitmap = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_miner_stand);
            mFrames[0] = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
            bitmap = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_miner_lift);
            mFrames[1] = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
            bitmap = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_miner_throw);
            mFrames[2] = Bitmap.createBitmap(bitmap, 0, 0, bitmap.getWidth(), bitmap.getHeight(), matrix, false);
        }

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) - 8;
        updateBoundingBox();

        mPickAxe = new EnemyMinerPickAxe(resources, this);

        mExplosion = new Explosion(resources);

        mPlayerDamage = 20;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(mState == STATE_DEFENSE) {
            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DINK);
            return;
        }

        if(otherObject instanceof WeaponPShot) {
            mHealth--;
            if(mHealth == 0) onDeath(gameEngine);
            else gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
        else if(otherObject instanceof WeaponIce) {
            if(mState != STATE_STUNNED) mOldState = mState;
            mState = STATE_STUNNED;
            mStunnedTimer = 0;
        }
        else if(otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGutsFragment
                || otherObject instanceof WeaponGuts) {
            onDeath(gameEngine);
        }
    }

    private void onDeath(GameEngine gameEngine) {
        mHurtOrDead = true;

        mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
        gameEngine.addGameObject(mExplosion);

        // spawn object?
        gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());

        gameEngine.removeGameObject(this);

        gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mState != STATE_JUMP_IN) super.onDraw(canvas);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        switch(mState) {
            case STATE_JUMP_IN:
                mVelocityX = VELOCITY_X * mDirection;
                mVelocityY = VELOCITY_Y;
                mState = STATE_WAIT_TO_LAND;
                break;
            case STATE_WAIT_TO_LAND:
                gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

                mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
                gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);

                if(mOnGround) {
                    mState = STATE_DEFENSE;
                    mVelocityX = 0;
                    mVelocityY = 0;
                    mStateTimer = (int)(Math.random() * 2000);
                }
                break;
            case STATE_DEFENSE:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) {
                    mStateTimer = 0;
                    mState = STATE_LIFT;
                    mFrame = 1;
                }
                break;
            case STATE_LIFT:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 200) {
                    mStateTimer = 0;
                    mState = STATE_THROW;
                    mFrame = 2;
                }
                break;
            case STATE_THROW:
                if(mPickAxeReleased) {
                    mPickAxeReleased = false;
                    final int distance = Math.abs(gameEngine.mPlayer.mBoundingBox.centerX() - mBoundingBox.centerX());
                    if(mDirection == 1) mPickAxe.init(mBoundingBox.left - 12, mBoundingBox.centerY(), mDirection, distance);
                    else mPickAxe.init(mBoundingBox.right, mBoundingBox.centerY(), mDirection, distance);
                    gameEngine.addGameObject(mPickAxe);
                }
                else {
                    mStateTimer += elapsedMillis;
                    if(mStateTimer > 300) {
                        mStateTimer = (int)(Math.random() * 2000);
                        mState = STATE_DEFENSE;
                        mFrame = 0;
                    }
                }
                break;
            case STATE_STUNNED:
                mStunnedTimer += elapsedMillis;
                if(mStunnedTimer >= 2000) {
                    mStunnedTimer = 0;
                    mState = mOldState;
                }
                break;
        }
    }

    void releasePickaxe() {
        mPickAxeReleased = true;
    }
}
