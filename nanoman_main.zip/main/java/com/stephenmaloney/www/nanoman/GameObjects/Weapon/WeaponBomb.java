package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.BoundingBox;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.R;

public class WeaponBomb extends SpriteFrameAnimation {
    private final static float THROW_VELOCITY_X = .08f;
    private final static float THROW_VELOCITY_Y = -.15f;
    private final static float BOUNCE_VELOCITY = .03f;
    private final static float FRICTION_AIR_ACCELERATION = .00007f;
    private final static float FRICTION_GROUND_ACCELERATION = .0005f;

    private final static int STATE_WAIT_TO_BLOW = 0;
    private final static int STATE_BLOW_UP = 1;
    private final static int STATE_CARRY = 2;
    public int mState;
    private int mStateTimer = 0;

    private final static int BLOW_UP_MILLIS = 1500;
    private final static int EXPLOSION_FRAME_MILLIS = 25;
    private final static int FRAMES = 20;

    private final BoundingBox[] mBoundingBoxes = new BoundingBox[FRAMES];

    private final SpriteAnimatedMirroredWeapons mParent;

    public boolean mExploding = false;

    private boolean mCanCarry = false;

    public WeaponBomb(Resources resources, SpriteAnimatedMirroredWeapons parent, boolean canCarry) {
        super(0, 0, 14, 14, 20);

        // save parent for weapon release
        mParent = parent;

        // get bitmaps for each frame of animation
        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb);

        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion1);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion2);
        mFrames[3] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion3);
        mFrames[4] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion4);
        mFrames[5] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion5);
        mFrames[6] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion6);
        mFrames[7] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion7);
        mFrames[8] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion8);
        mFrames[9] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion9);
        mFrames[10] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion10);
        mFrames[11] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion11);
        mFrames[12] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion12);
        mFrames[13] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion13);
        mFrames[14] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion14);
        mFrames[15] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion15);
        mFrames[16] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion16);
        mFrames[17] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion17);
        mFrames[18] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion18);
        mFrames[19] = BitmapFactory.decodeResource(resources, R.drawable.weapon_bomb_explosion19);

        // create bounding boxes for each animation frame
        for(int frame = 0; frame < FRAMES; frame++) mBoundingBoxes[frame] = new BoundingBox(0, 0, mFrames[frame].getWidth(), mFrames[frame].getHeight());

        mCanCarry = canCarry;

        mPlayerDamage = 25;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && mExploding && !(otherObject instanceof WeaponPShot);
    }

    public void init(int x, int y, int direction, float velocityX, float velocityY) {
        mX = x;
        mY = y;
        mXFractional = 0;
        mYFractional = 0;
        mDirection = direction;

        mVelocityX = THROW_VELOCITY_X * mDirection + velocityX;
        mVelocityY = THROW_VELOCITY_Y + velocityY;
        if(mCanCarry) mState = STATE_CARRY;
        else mState = STATE_WAIT_TO_BLOW;
        mStateTimer = 0;

        mFrame = 0;
        mBoundingBox.set(mBoundingBoxes[mFrame].mRect);
        updateBoundingBox();

        mExploding = false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        switch(mState) {
            case STATE_WAIT_TO_BLOW:
                // incorporate friction, but stop it from accelerating the wrong way
                if(mOnGround) {
                    if (mVelocityX > 0) {
                        mVelocityX += -1 * FRICTION_GROUND_ACCELERATION * elapsedMillis;
                        if (mVelocityX < 0) mVelocityX = 0;
                    } else if (mVelocityX < 0) {
                        mVelocityX += FRICTION_GROUND_ACCELERATION * elapsedMillis;
                        if (mVelocityX > 0) mVelocityX = 0;
                    }
                }
                else {
                    if (mVelocityX > 0) {
                        mVelocityX += -1 * FRICTION_AIR_ACCELERATION * elapsedMillis;
                        if (mVelocityX < 0) mVelocityX = 0;
                    } else if (mVelocityX < 0) {
                        mVelocityX += FRICTION_AIR_ACCELERATION * elapsedMillis;
                        if (mVelocityX > 0) mVelocityX = 0;
                    }
                }

                // add gravity
                mVelocityY += GameEngine.GRAVITY_ACCELERATION * elapsedMillis;
                if(mVelocityY > GameEngine.TERMINAL_VELOCITY) mVelocityY = GameEngine.TERMINAL_VELOCITY;

                // update x position
                final float oldVelocityX = mVelocityX;
                gameEngine.mStage.onUpdateCollisionX(elapsedMillis, this);

                // update y position
                final float oldVelocityY = mVelocityY;
                gameEngine.mStage.onUpdateCollisionY(elapsedMillis, this, gameEngine);
                updateBoundingBox();

                // check for bouncing off walls and floors
                if(mVelocityX == 0 && Math.abs(oldVelocityX) > BOUNCE_VELOCITY) mVelocityX = oldVelocityX * -1 * .5f;

                if(mVelocityY == 0 && oldVelocityY > BOUNCE_VELOCITY) mVelocityY = oldVelocityY * -1 * .5f;

                mStateTimer += elapsedMillis;
                if(mStateTimer >= BLOW_UP_MILLIS) {
                    mState = STATE_BLOW_UP;
                    mStateTimer = 0;
                    incrementFrame();
                    mExploding = true;
                    gameEngine.soundPlay(GameEngine.GameSound.EXPLOSION);
                }
                break;
            case STATE_BLOW_UP:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= EXPLOSION_FRAME_MILLIS) {
                    mStateTimer = 0;
                    if(mFrame == (FRAMES - 1)) {
                        // bomb destroyed
                        gameEngine.removeGameObject(this);
                        mParent.weaponBombRelease(this);
                    }
                    else incrementFrame();
                }
                break;
            case STATE_CARRY:
                // do nothing - just draw
                break;
        }
    }

    private void incrementFrame() {
        mX = mBoundingBox.centerX() - mBoundingBoxes[mFrame + 1].mSizeX / 2;
        mY = mBoundingBox.centerY() - mBoundingBoxes[mFrame + 1].mSizeY / 2;

        mBoundingBox.set(mBoundingBoxes[mFrame + 1].mRect);
        updateBoundingBox();

        mFrame++;
    }

    public boolean isCarried() {
        return mState == STATE_CARRY;
    }

    public void triggerWaitToBlow() {
        mState = STATE_WAIT_TO_BLOW;
    }
}
