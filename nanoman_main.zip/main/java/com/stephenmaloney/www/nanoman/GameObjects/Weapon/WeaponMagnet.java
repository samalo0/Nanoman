package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Canvas;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteStatic;
import com.stephenmaloney.www.nanoman.R;

public class WeaponMagnet extends SpriteStatic {
    private final Player mParent;

    private final static int EXISTENCE_MILLIS = 5000;
    private int mTimer = 0;

    private final static int BLINK_MILLIS = 20;
    private int mBlinkTimer = 0;
    private boolean mVisible = true;

    public WeaponMagnet(Resources resources, Player parent) {
        super(resources, R.drawable.weapon_magnet, 0, 0, 16, 6);
        mParent = parent;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    public void init(int x, int y, GameEngine gameEngine) {
        mX = x;
        mXFractional = 0;
        mY = y;
        mYFractional = 0;
        updateBoundingBox();

        mTimer = 0;
        mBlinkTimer = 0;
        mVisible = true;

        gameEngine.soundPlay(GameEngine.GameSound.WEAPON_MAGNET);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mVisible) super.onDraw(canvas);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mTimer += elapsedMillis;
        if(mTimer >= EXISTENCE_MILLIS) {
            gameEngine.removeGameObject(this);
            mParent.weaponMagnetRelease(this);
        }

        mBlinkTimer += elapsedMillis;
        if(mBlinkTimer >= BLINK_MILLIS) {
            mBlinkTimer = 0;
            mVisible = !mVisible;
        }
    }
}

