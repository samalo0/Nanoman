package com.stephenmaloney.www.nanoman.GameObjects;

import android.graphics.Canvas;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;

public abstract class GameObject {
    public void onDraw(Canvas canvas) {}

    public abstract void onUpdate(long elapsedMillis, GameEngine gameEngine);

    public void startGame(GameEngine gameEngine) {}
}
