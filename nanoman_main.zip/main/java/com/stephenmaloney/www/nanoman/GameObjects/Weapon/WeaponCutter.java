package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirrored;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimatedMirroredWeapons;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.R;

public class WeaponCutter extends SpriteAnimatedMirrored {
    private final static int BOUNDING_BOX_OFFSET_X = 0;
    private final static int BOUNDING_BOX_OFFSET_Y = 0;
    private final static int BOUNDING_BOX_SIZE_X = 14;
    private final static int BOUNDING_BOX_SIZE_Y = 14;

    public final SpriteAnimatedMirroredWeapons mParent;

    private final static int STATE_ELLIPSE = 0;
    private final static int STATE_COMING_BACK = 1;
    private int mState;

    private final static int ELLIPSE_2A = 5 * Tile.SIZE;
    private final static int ELLIPSE_2B = 4 * Tile.SIZE;
    private final static int ELLIPSE_A = ELLIPSE_2A / 2;
    private final static int ELLIPSE_B = ELLIPSE_2B / 2;
    private double mAngle;
    private int mStartX;
    private int mStartY;

    private final static float RETURN_VELOCITY = .1f;

    public WeaponCutter(Resources resources, SpriteAnimatedMirroredWeapons parent) {
        super(BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        mFacingLeftAdjustmentX = BOUNDING_BOX_SIZE_X;
        mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(R.drawable.animation_weapon_cutter, null));
        mParent = parent;

        mPlayerDamage = 25;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject != mParent);
    }

    public void init(int x, int y, int direction, GameEngine gameEngine) {
        mStartX = x;
        mStartY = y;
        mX = mStartX;
        mXFractional = 0;
        mY = mStartY;
        mYFractional = 0;
        updateBoundingBox();

        mDirection = direction;
        mState = STATE_ELLIPSE;

        if(mDirection == 1) mAngle = Math.PI;
        else mAngle = 0;

        gameEngine.soundPlay(GameEngine.GameSound.WEAPON_CUTTER);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mSpriteAnimation.onUpdate(elapsedMillis);

        switch(mState) {
            case STATE_ELLIPSE:
                if(mDirection == 1) {
                    mAngle += elapsedMillis / 200.0f;
                    mX = (int)(ELLIPSE_A * Math.cos(mAngle) + ELLIPSE_A + mStartX);
                    mY = (int)(ELLIPSE_B * Math.sin(mAngle) + mStartY);
                }
                else {
                    mAngle -= elapsedMillis / 200.0f;
                    mX = (int)(ELLIPSE_A * Math.cos(mAngle) - ELLIPSE_A + mStartX);
                    mY = (int)(ELLIPSE_B * Math.sin(mAngle) + mStartY);
                }

                updateBoundingBox();

                if(mDirection == 1 && mAngle >= Math.PI * 5/2) mState = STATE_COMING_BACK;
                else if(mDirection == -1 && mAngle <= (Math.PI * -3/2)) mState = STATE_COMING_BACK;
                break;
            case STATE_COMING_BACK:
                mDirection = mParent.mBoundingBox.centerX() > mX? 1 : -1;
                final double dX = RETURN_VELOCITY * mDirection * elapsedMillis + mXFractional;
                mX += (int) dX;
                mXFractional = dX % 1;

                final int mDirectionY = mParent.mBoundingBox.centerY() > mY? 1 : -1;
                final double dY = RETURN_VELOCITY * mDirectionY * elapsedMillis + mYFractional;
                mY += (int) dY;
                mYFractional = dY % 1;
                updateBoundingBox();

                if(Rect.intersects(mBoundingBox, mParent.mBoundingBox)) {
                    // weapon caught
                    gameEngine.removeGameObject(this);
                    mParent.weaponCutterRelease(this);
                }
                break;
        }
    }
}
