package com.stephenmaloney.www.nanoman.GameObjects.Player;

import android.content.res.Resources;
import android.graphics.Canvas;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.VerticalDisplayBar;
import com.stephenmaloney.www.nanoman.R;

public class PlayerAmmoBars extends GameObject {
    public final static int AMMO_MAX = 100;
    private final static int SEGMENTS = 25;
    private final static int BAR_LEFT = 16;
    private final static int BAR_TOP = 24;

    private final VerticalDisplayBar[] mBars = new VerticalDisplayBar[7];

    int mSelected = 0;

    PlayerAmmoBars(Resources resources) {
        mBars[0] = new VerticalDisplayBar(resources, R.drawable.gameobject_vertical_display_bar_green_segment, AMMO_MAX, SEGMENTS, BAR_LEFT, BAR_TOP);
        mBars[1] = new VerticalDisplayBar(resources, R.drawable.gameobject_vertical_display_bar_gray_segment, AMMO_MAX, SEGMENTS, BAR_LEFT, BAR_TOP);
        mBars[2] = new VerticalDisplayBar(resources, R.drawable.gameobject_vertical_display_bar_grayyellow_segment, AMMO_MAX, SEGMENTS, BAR_LEFT, BAR_TOP);
        mBars[3] = new VerticalDisplayBar(resources, R.drawable.gameobject_vertical_display_bar_red_segment, AMMO_MAX, SEGMENTS, BAR_LEFT, BAR_TOP);
        mBars[4] = new VerticalDisplayBar(resources, R.drawable.gameobject_vertical_display_bar_orange_segment, AMMO_MAX, SEGMENTS, BAR_LEFT, BAR_TOP);
        mBars[5] = new VerticalDisplayBar(resources, R.drawable.gameobject_vertical_display_bar_blue_segment, AMMO_MAX, SEGMENTS, BAR_LEFT, BAR_TOP);
        mBars[6] = new VerticalDisplayBar(resources, R.drawable.gameobject_vertical_display_bar_blueblue_segment, AMMO_MAX, SEGMENTS, BAR_LEFT, BAR_TOP);
    }

    void add(int value) {
        mBars[mSelected].add(value);
    }

    void addInstant(int value, int whichBar) {
        mBars[whichBar].addInstant(value);
    }

    public boolean isFull() { return mBars[mSelected].isFull(); }

    @Override
    public void onDraw(Canvas canvas) {
        mBars[mSelected].onDraw(canvas);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mBars[mSelected].onUpdate(elapsedMillis, gameEngine);
    }

    void refillAll() {
        final int size = mBars.length;
        for(int i = 0; i < size; i++) mBars[i].add(AMMO_MAX);
    }

    void remove(int value) {
        mBars[mSelected].remove(value);
    }

    @Override
    public void startGame(GameEngine gameEngine) {
    }
}
