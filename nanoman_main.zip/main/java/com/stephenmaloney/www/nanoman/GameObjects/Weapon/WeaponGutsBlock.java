package com.stephenmaloney.www.nanoman.GameObjects.Weapon;

import android.content.Context;
import android.graphics.BitmapFactory;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;

import java.util.HashMap;

public class WeaponGutsBlock extends SpriteFrameAnimation {
    public final static String TYPE = "BlockThrow";

    private final static int SIZE_X = 34;
    private final static int SIZE_Y = 32;

    private final int mTileX;
    private final int mTileY;
    private final int[] mOriginalTile = new int[4];
    public final int mType;

    public WeaponGutsBlock(Context context, HashMap<String, String> properties) {
        super(-1, 0, SIZE_X, SIZE_Y, 1);

        mTileX = Integer.parseInt(properties.get("PositionX"));
        mX = mTileX << Tile.SIZE_POW_2;
        mTileY = Integer.parseInt(properties.get("PositionY"));
        mY = mTileY << Tile.SIZE_POW_2;
        updateBoundingBox();

        final String drawable = properties.get("Drawable");
        mFrames[0] = BitmapFactory.decodeResource(context.getResources(), context.getResources().getIdentifier(drawable, "drawable", context.getPackageName()));

        switch(drawable) {
            case "gameobject_block_throw_cut":
                mType = WeaponGuts.BLOCK_TYPE_CUT;
                break;
            case "gameobject_block_throw_gut":
                mType = WeaponGuts.BLOCK_TYPE_GUT;
                break;
            case "gameobject_block_throw_wily1":
                mType = WeaponGuts.BLOCK_TYPE_WILY1;
                break;
            default: // elec
                mType = WeaponGuts.BLOCK_TYPE_ELEC;
                break;
        }
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) { return false; }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {}

    public void pickup(GameEngine gameEngine) {
        // block is being picked up - set the tiles back to original
        gameEngine.setTile(mTileX, mTileY, mOriginalTile[0]);
        gameEngine.setTile(mTileX + 1, mTileY, mOriginalTile[1]);
        gameEngine.setTile(mTileX, mTileY + 1, mOriginalTile[2]);
        gameEngine.setTile(mTileX + 1, mTileY + 1, mOriginalTile[3]);

        // remove the block
        gameEngine.removeGameObject(this);
    }

    @Override
    public void startGame(GameEngine gameEngine) {
        final int solidTile = gameEngine.getTileSolid();

        mOriginalTile[0] = gameEngine.getTile(mTileX, mTileY);
        mOriginalTile[1] = gameEngine.getTile(mTileX + 1, mTileY);
        mOriginalTile[2] = gameEngine.getTile(mTileX, mTileY + 1);
        mOriginalTile[3] = gameEngine.getTile(mTileX + 1, mTileY + 1);

        gameEngine.setTile(mTileX, mTileY, solidTile);
        gameEngine.setTile(mTileX + 1, mTileY, solidTile);
        gameEngine.setTile(mTileX, mTileY + 1, solidTile);
        gameEngine.setTile(mTileX + 1, mTileY + 1, solidTile);
    }
}
