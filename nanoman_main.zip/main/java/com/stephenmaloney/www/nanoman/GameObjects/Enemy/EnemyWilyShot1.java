package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteStatic;
import com.stephenmaloney.www.nanoman.R;

public class EnemyWilyShot1 extends SpriteStatic {
    private final EnemyWilyGun mParent;

    EnemyWilyShot1(Resources resources, EnemyWilyGun parent) {
        super(resources, R.drawable.gameobject_enemy_wily_shot, 0, 0, 10, 10);
        mParent = parent;
        mPlayerDamage = 25;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && (otherObject instanceof Player);
    }

    void init(int x, int y, int direction, int distance) {
        mX = x;
        mY = y;
        mXFractional = 0;
        mYFractional = 0;
        updateBoundingBox();
        mDirection = direction;

        mVelocityY = -.15f;
        mVelocityX = .001f * distance * mDirection;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.releaseShot(this);
        }

        mVelocityY += .0005f * elapsedMillis;

        final double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;

        final double distanceY= mVelocityY * elapsedMillis + mYFractional;
        mY += (int) distanceY;
        mYFractional = distanceY % 1;

        updateBoundingBox();
    }
}
