package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimated;
import com.stephenmaloney.www.nanoman.R;

public class EnemyWilyPropeller extends SpriteAnimated {
    private final static int PROPELLER_OFFSET_X = 94;
    private final static int PROPELLER_OFFSET_Y = 42;

    EnemyWilyPropeller(Resources resources) {
        super(0, 0, 8, 26);

        mSpriteAnimation.addState(0, (AnimationDrawable) resources.getDrawable(R.drawable.animation_enemy_wily_propeller, null));

        mPlayerDamage = 25;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mSpriteAnimation.onUpdate(elapsedMillis);
    }

    void updateLocation(int x, int y) {
        mX = x + PROPELLER_OFFSET_X;
        mY = y + PROPELLER_OFFSET_Y;
        updateBoundingBox();
    }
}