package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.GameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;

import java.util.HashMap;

public class EnemyRobotSpawn extends GameObject {
    public final static String TYPE = "EnemyRobot";

    private final Rect mBoundingBox;
    private final int mDirection;

    private final static int STATE_SPAWN_ON_SIGHT = 0;
    private final static int STATE_WAIT_FOR_SCROLL_AWAY = 1;
    private int mState = STATE_SPAWN_ON_SIGHT;

    private final EnemyRobotHead mHead;
    private boolean mHeadReleased = true;

    private final EnemyRobotLegs mLegs;
    private boolean mLegsReleased = true;

    public EnemyRobotSpawn(Resources resources, HashMap<String, String> properties) {
        final int x = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        final int y = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;
        mBoundingBox = new Rect(x, y, x + 11, y + Tile.SIZE);

        mDirection = Integer.parseInt(properties.get("Direction"));

        mLegs = new EnemyRobotLegs(resources, this);
        mHead = new EnemyRobotHead(resources, this, mLegs);
    }

    void detachHead() {
        if(!mHeadReleased) mHead.detach();
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) { //GameView.mViewPort.contains(mBoundingBox)) {
            if(mState == STATE_WAIT_FOR_SCROLL_AWAY && mHeadReleased && mLegsReleased) mState = STATE_SPAWN_ON_SIGHT;
            return;
        }

        switch(mState) {
            case STATE_SPAWN_ON_SIGHT:
                if(mHeadReleased && mLegsReleased) {
                    mHeadReleased = false;
                    mLegsReleased = false;
                    mLegs.init(mBoundingBox.left, mBoundingBox.top, mDirection);
                    mHead.init();
                    gameEngine.addGameObject(mLegs);
                    gameEngine.addGameObject(mHead);
                    mState = STATE_WAIT_FOR_SCROLL_AWAY;
                }
                break;
            case STATE_WAIT_FOR_SCROLL_AWAY:
                // do nothing
                break;
        }
    }

    void releaseHead() {
        mHeadReleased = true;
    }

    void releaseLegs() {
        mLegsReleased = true;
    }
}
