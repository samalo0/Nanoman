package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Player.Player;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class EnemyWily extends SpriteFrameAnimation {
    public final static String Type = "EnemyWily";

    private final static float VELOCITY = .02f;

    private int mFrameAdder = 0;

    private final int leftLimitX;
    private final int rightLimitX;

    private final static int STATE_WAIT_FOR_VISIBLE = 0;
    private final static int STATE_GO_RIGHT = 1;
    private final static int STATE_GO_LEFT = 2;
    private final static int STATE_TRANSITION_TO_UNSHIELDED = 3;
    private final static int STATE_TRANSITION_TO_DEATH = 4;
    private final static int STATE_DEATH = 5;
    private int mState = STATE_WAIT_FOR_VISIBLE;
    private int mStateTimer = 0;

    private final EnemyWilyPropeller mPropeller;

    private final EnemyWilyGun mGun;
    private boolean mGunReleased = true;

    private int mHurtTimer = 0;

    private final EnemyWilySit mWilySit;
    private boolean mWilySitReleased = true;

    private final EnemyWilyWeakness mWeakness;
    private boolean mWeaknessReleased = true;

    public EnemyWily(Resources resources, HashMap<String, String> properties) {
        super(25, 0, 56, 104, 5);

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2;
        updateBoundingBox();

        leftLimitX = (mX - (4 * Tile.SIZE));
        rightLimitX = (mX + (4 * Tile.SIZE));

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_wily_shielded);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_wily_shielded_hit);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_wily_open);
        mFrames[3] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_wily_open_hit);
        mFrames[4] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_wily_death);

        mPropeller = new EnemyWilyPropeller(resources);
        mPropeller.updateLocation(mX, mY);

        mGun = new EnemyWilyGun(resources, this);
        mGun.updateLocation(mX, mY);

        mWilySit = new EnemyWilySit(resources);

        mWeakness = new EnemyWilyWeakness(resources, this);

        mPlayerDamage = 25;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && otherObject instanceof WeaponPShot;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {}

    void onHurt() {
        mHurtTimer = 100;
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        switch(mState) {
            case STATE_WAIT_FOR_VISIBLE:
                gameEngine.musicPlayLooped(R.raw.music_wily_boss_theme);
                gameEngine.addGameObject(mPropeller);

                mGunReleased = false;
                gameEngine.addGameObject(mGun);

                mState = STATE_GO_RIGHT;
                break;
            case STATE_GO_RIGHT:
                final double dX = VELOCITY * elapsedMillis + mXFractional;
                mX += (int)dX;
                mXFractional = dX % 1;
                updateBoundingBox();

                mPropeller.updateLocation(mX, mY);
                if(!mGunReleased) mGun.updateLocation(mX, mY);
                if(!mWilySitReleased) mWilySit.updateLocation(mX, mY);
                if(!mWeaknessReleased) mWeakness.updateLocation(mX, mY);

                if(mHurtTimer > 0) {
                    mHurtTimer -= elapsedMillis;
                    mFrame = mHurtTimer > 0? 1 + mFrameAdder : mFrameAdder;
                }

                if(mX >= rightLimitX) mState = STATE_GO_LEFT;
                break;
            case STATE_GO_LEFT:
                final double dXLeft = VELOCITY * elapsedMillis + mXFractional;
                mX -= (int)dXLeft;
                mXFractional = dXLeft % 1;
                updateBoundingBox();

                mPropeller.updateLocation(mX, mY);
                if(!mGunReleased) mGun.updateLocation(mX, mY);
                if(!mWilySitReleased) mWilySit.updateLocation(mX, mY);
                if(!mWeaknessReleased) mWeakness.updateLocation(mX, mY);

                if(mHurtTimer > 0) {
                    mHurtTimer -= elapsedMillis;
                    mFrame = mHurtTimer > 0? 1 + mFrameAdder : mFrameAdder;
                }

                if(mX <= leftLimitX) mState = STATE_GO_RIGHT;
                break;
            case STATE_TRANSITION_TO_UNSHIELDED:
                mStateTimer += elapsedMillis;
                if(mStateTimer >= 500) {
                    mStateTimer = 0;
                    mState = STATE_GO_LEFT;

                    mWilySitReleased = false;
                    mWilySit.updateLocation(mX, mY);
                    gameEngine.addGameObject(mWilySit);

                    mWeaknessReleased = false;
                    mWeakness.updateLocation(mX, mY);
                    gameEngine.addGameObject(mWeakness);
                }
                break;
            case STATE_TRANSITION_TO_DEATH:
                gameEngine.removeGameObject(mPropeller);

                gameEngine.removeGameObject(mWilySit);
                mWilySitReleased = true;

                gameEngine.musicPlayOnce(R.raw.music_victory);

                gameEngine.mPlayer.warpOut(Player.WARP_DESTINATION_STAGE_SELECT);

                mState = STATE_DEATH;
                break;
        }
    }

    void gunDestroyed() {
        mState = STATE_TRANSITION_TO_UNSHIELDED;
        mFrame = 2;
        mFrameAdder = 2;
        mGunReleased = true;
    }

    void weaknessDestroyed() {
        mState = STATE_TRANSITION_TO_DEATH;
        mFrame = 4;
        mFrameAdder = 0;
        mWeaknessReleased = true;
    }
}
