package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.Enemy.EnemyAlien;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class ElectricityMini extends SpriteAnimated {
    private final static int BOUNDING_BOX_SIZE_X = 24;
    private final static int BOUNDING_BOX_SIZE_Y = 6;
    private final static int BOUNDING_BOX_OFFSET_X = 0;
    private final static int BOUNDING_BOX_OFFSET_Y = 0;

    private final static int POSITION_OFFSET_X = 8;
    private final static int POSITION_OFFSET_Y = 5;

    private final static float VELOCITY = .25f;

    public final static String TYPE = "ElectricityMini";

    private boolean mDecoration;
    private boolean mOn = false;
    private int mOnTimer = 0;
    private int mOnTime;
    private int mOffTime;

    final EnemyAlien mParent;

    public ElectricityMini(Resources resources, HashMap<String, String> properties) {
        // create mini electricity decoration
        super(BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);

        mDecoration = true;

        mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(R.drawable.animation_electricity_mini, null));

        // get starting x, y position (adjust x by one since the large health is 14 pixels wide, centering it)
        mX = (Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2) + POSITION_OFFSET_X;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) + POSITION_OFFSET_Y;
        updateBoundingBox();

        mOnTime = Integer.parseInt(properties.get("OnTime"));
        mOffTime = Integer.parseInt(properties.get("OffTime"));

        mParent = null;

        mPlayerDamage = 16;
    }

    public ElectricityMini(Resources resources, EnemyAlien parent) {
        // create mini electricity weapon
        super(BOUNDING_BOX_OFFSET_X, BOUNDING_BOX_OFFSET_Y, BOUNDING_BOX_SIZE_X, BOUNDING_BOX_SIZE_Y);
        mDecoration = false;
        mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(R.drawable.animation_electricity_mini, null));
        mParent = parent;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return false;
    }

    public void init(int x, int y, int direction, GameEngine gameEngine) {
        mX = x;
        mY = y;
        updateBoundingBox();
        mDirection = direction;
        mVelocityX = mDirection * VELOCITY;

        gameEngine.soundPlay(GameEngine.GameSound.WEAPON_MAGNET);
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onDraw(Canvas canvas) {
        if(mOn || !mDecoration) super.onDraw(canvas);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(mDecoration) {
            if(!GameEngine.isObjectVisible(mBoundingBox)) return;

            if (mOn) {
                mOnTimer += elapsedMillis;
                if (mOnTimer > mOnTime) {
                    mOn = false;
                    mOnTimer = 0;
                } else {
                    // on and not switching off
                    mSpriteAnimation.onUpdate(elapsedMillis);
                }
            } else {
                mOnTimer += elapsedMillis;
                if (mOnTimer > mOffTime) {
                    mOn = true;
                    mOnTimer = 0;
                }
            }

            return;
        }

        if(!GameEngine.isObjectVisible(mBoundingBox)) {
            gameEngine.removeGameObject(this);
            mParent.electricityMiniRelease(this);
        }

        final double distanceX = mVelocityX * elapsedMillis + mXFractional;
        mX += (int) distanceX;
        mXFractional = distanceX % 1;
        updateBoundingBox();

        mSpriteAnimation.onUpdate(elapsedMillis);
    }
}
