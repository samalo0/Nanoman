package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Rect;
import android.graphics.drawable.AnimationDrawable;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.Explosion;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteAnimated;
import com.stephenmaloney.www.nanoman.GameObjects.Tile;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponBomb;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponCutter;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponElectricityVertical;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireHorizontal;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponFireSpinner;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGuts;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponGutsFragment;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponIce;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class EnemySlider extends SpriteAnimated {
    public final static String TYPE = "EnemySlider";

    private final static float SLIDE_SLOW_VELOCITY = .02f;
    private final static float SLIDE_FAST_VELOCITY = .08f;

    private final static int STATE_NORMAL = 0;
    private final static int STATE_STUNNED = 1;
    private final static int STUN_MILLIS = 2500;

    private int mState = STATE_NORMAL;
    private int mStateTimer = 0;

    private final Explosion mExplosion;

    private boolean mHurtOrDead = false;

    public EnemySlider(Resources resources, HashMap<String, String> properties) {
        super(0, 0, 16, 8);

        final String color = properties.get("Color");
        if(color != null && color.equals("Blue")) mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_slider_blue, null));
        else mSpriteAnimation.addState(0, (AnimationDrawable)resources.getDrawable(R.drawable.animation_enemy_slider_orange, null));

        mX = (Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2);
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) + 8;
        updateBoundingBox();

        mDirection = Integer.parseInt(properties.get("Direction"));
        mVelocityX = SLIDE_SLOW_VELOCITY * mDirection;

        mPlayerDamage = 20;

        mExplosion = new Explosion(resources);
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(otherObject.mBoundingBox, mBoundingBox) && !mHurtOrDead
                && (otherObject instanceof WeaponPShot
                || otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponIce
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponGutsFragment
                || (otherObject instanceof WeaponBomb && ((WeaponBomb)otherObject).mExploding)
                || (otherObject instanceof WeaponGuts && ((WeaponGuts)otherObject).mCanDamage));
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot || otherObject instanceof WeaponIce) {
            mState = STATE_STUNNED;
            mStateTimer = 0;
        }
        else if(otherObject instanceof WeaponElectricityHorizontal
                || otherObject instanceof WeaponElectricityVertical
                || otherObject instanceof WeaponCutter
                || otherObject instanceof WeaponFireHorizontal
                || otherObject instanceof WeaponFireSpinner
                || otherObject instanceof WeaponBomb
                || otherObject instanceof WeaponGuts
                || otherObject instanceof WeaponGutsFragment) {

            mHurtOrDead = true;

            mExplosion.init(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.addGameObject(mExplosion);

            // spawn object?
            gameEngine.randomSpawn(mBoundingBox.centerX(), mBoundingBox.centerY());
            gameEngine.removeGameObject(this);

            gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
        }
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        if(!GameEngine.isObjectVisible(mBoundingBox)) return;

        switch(mState) {
            case STATE_NORMAL:
                // update blink
                mSpriteAnimation.onUpdate(elapsedMillis);

                // check for upping speed if it 'sees' the player
                if (mBoundingBox.top >= gameEngine.mPlayer.mBoundingBox.centerY() && mBoundingBox.bottom <= gameEngine.mPlayer.mBoundingBox.bottom) {
                    mVelocityX = SLIDE_FAST_VELOCITY * mDirection;
                }

                if (gameEngine.mStage.onUpdateCollisionXNoFall(elapsedMillis, this)) {
                    // ran into wall or almost fell off, change directions
                    mDirection *= -1;
                    mVelocityX = SLIDE_SLOW_VELOCITY * mDirection;
                }
                break;
            case STATE_STUNNED:
                mStateTimer += elapsedMillis;
                if (mStateTimer >= STUN_MILLIS) mState = STATE_NORMAL;
                break;
        }
    }
}
