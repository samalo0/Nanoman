package com.stephenmaloney.www.nanoman.GameObjects.Enemy;

import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Rect;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.GameEngine.GameView;
import com.stephenmaloney.www.nanoman.GameObjects.CollisionGameObject;
import com.stephenmaloney.www.nanoman.GameObjects.DeathExplosionSet;
import com.stephenmaloney.www.nanoman.GameObjects.Sprite;
import com.stephenmaloney.www.nanoman.GameObjects.SpriteFrameAnimation;
import com.stephenmaloney.www.nanoman.GameObjects.Weapon.WeaponPShot;
import com.stephenmaloney.www.nanoman.R;

import java.util.ArrayList;
import java.util.List;

public class EnemyWilyGun extends SpriteFrameAnimation {
    private final static int GUN_OFFSET_X = 0;
    private final static int GUN_OFFSET_Y = 59;

    private final EnemyHealthBar mHealthBar;
    private final EnemyWily mParent;

    private final List<EnemyWilyShot1> mShots = new ArrayList<>();
    private final static int SHOTS_LIMIT = 2;

    private boolean mHurtOrDead = false;
    private int mHurtTimer = 0;

    private int mShotTimer = 0;

    private final DeathExplosionSet mDeathExplosionSet;

    EnemyWilyGun(Resources resources, EnemyWily parent) {
        super(0, 0, 25, 26, 3);

        mParent = parent;

        mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_wily_gun_left);
        mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_wily_gun_right);
        mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_enemy_wily_gun_explosion);

        mHealthBar = new EnemyHealthBar(resources);

        for(int i = 0; i < SHOTS_LIMIT; i++) mShots.add(new EnemyWilyShot1(resources, this));

        mDeathExplosionSet = new DeathExplosionSet(resources);

        mPlayerDamage = 25;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) {
        return Rect.intersects(mBoundingBox, otherObject.mBoundingBox) && otherObject instanceof WeaponPShot;
    }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
        if(mHurtOrDead) return;

        if(otherObject instanceof WeaponPShot) {
            mHealthBar.remove(4);
            if(mHealthBar.isEmpty()) {
                mHurtOrDead = true;
                mParent.gunDestroyed();
                gameEngine.removeGameObject(this);
                mDeathExplosionSet.addGameObjects(mBoundingBox.centerX(), mBoundingBox.centerY(), gameEngine);
            }
            else {
                gameEngine.soundPlay(GameEngine.GameSound.ENEMY_DAMAGE);
                mParent.onHurt();
                mHurtTimer = 60;
            }
        }
    }

    @Override
    public void onDraw(Canvas canvas) {
        mHealthBar.onDraw(canvas);

        super.onDraw(canvas);
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        mHealthBar.onUpdate(elapsedMillis, gameEngine);

        mDirection = gameEngine.mPlayer.mBoundingBox.centerX() > mBoundingBox.centerX() ? 1 : -1;
        if(mDirection == 1) mFrame = 1;
        else mFrame = 0;

        if(mHurtTimer > 0) {
            mHurtTimer -= elapsedMillis;
            mFrame = 2;
        }

        mShotTimer += elapsedMillis;
        if(mShotTimer >= 500 && !mShots.isEmpty()) {
            mShotTimer = 0;
            final int distance = Math.abs(mBoundingBox.centerX() - gameEngine.mPlayer.mBoundingBox.centerX());
            final EnemyWilyShot1 shot = mShots.remove(0);
            if(mDirection == 1) shot.init(mX + 20, mY - 6, mDirection, distance);
            else shot.init(mX - 6, mY - 6, mDirection, distance);
            gameEngine.addGameObject(shot);
        }
    }

    void releaseShot(EnemyWilyShot1 shot) {
        mShots.add(shot);
    }

    void updateLocation(int x, int y) {
        mX = x + GUN_OFFSET_X;
        mY = y + GUN_OFFSET_Y;
        updateBoundingBox();
    }
}