package com.stephenmaloney.www.nanoman.GameObjects;

import android.content.res.Resources;
import android.graphics.BitmapFactory;

import com.stephenmaloney.www.nanoman.GameEngine.GameEngine;
import com.stephenmaloney.www.nanoman.R;

import java.util.HashMap;

public class Tram extends SpriteFrameAnimation {
    public final static String TYPE = "Tram";

    private final static float VELOCITY = .07f;

    final int mEndTileNumber;
    final int mDipTileNumber;

    public final static int STATE_SUPPORT = 0;
    private final static int STATE_TILT = 1;
    private final static int STATE_DOWN = 2;
    private int mStateNext;
    private int mStateTimer = 0;

    private final static int SOUND_MILLIS = 933;
    private int mSoundTimer = 0;
    private boolean mPlayingSound = false;

    Tram(Resources resources, HashMap<String, String> properties) {
        super(0, 0, 32, 8, 3);

        mX = Integer.parseInt(properties.get("PositionX")) << Tile.SIZE_POW_2;
        mY = (Integer.parseInt(properties.get("PositionY")) << Tile.SIZE_POW_2) - 4;
        updateBoundingBox();

        mEndTileNumber = Integer.parseInt(properties.get("EndTileNumber"));
        mDipTileNumber = Integer.parseInt(properties.get("DipTileNumber"));

        final String color = properties.get("Color");
        switch (color) {
            case "Green":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_tram_green1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_tram_green2);
                mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_tram_green3);
                break;
            case "Red":
                mFrames[0] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_tram_red1);
                mFrames[1] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_tram_red2);
                mFrames[2] = BitmapFactory.decodeResource(resources, R.drawable.gameobject_tram_red3);
                break;
        }

        mDirection = 1;
        mVelocityX = VELOCITY;
    }

    @Override
    public boolean checkCollision(CollisionGameObject otherObject) { return false; }

    @Override
    public void onCollision(GameEngine gameEngine, CollisionGameObject otherObject) {
    }

    @Override
    public void onUpdate(long elapsedMillis, GameEngine gameEngine) {
        gameEngine.mStage.onUpdateTram(elapsedMillis, this);

        switch(mFrame) {
            case STATE_TILT:
                mStateTimer -= elapsedMillis;
                if(mStateTimer <= 0) mFrame = mStateNext;
                break;
        }

        if(GameEngine.isObjectVisible(mBoundingBox)) {
            if(!mPlayingSound) {
                mPlayingSound = true;
                mSoundTimer = 0;
                gameEngine.soundPlay(GameEngine.GameSound.TRAM);
            }
            else {
                mSoundTimer += elapsedMillis;
                if(mSoundTimer >= SOUND_MILLIS) mPlayingSound = false;
            }
        }
    }

    void transitionToDown() {
        if(mFrame == STATE_SUPPORT) {
            mFrame = STATE_TILT;
            mStateNext = STATE_DOWN;
            mStateTimer = 75;
        }
    }

    void transitionToSupport() {
        if(mFrame == STATE_DOWN) {
            mFrame = STATE_TILT;
            mStateNext = STATE_SUPPORT;
            mStateTimer = 75;
        }
    }
}
